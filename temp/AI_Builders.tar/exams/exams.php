<?php
session_start();

// Session timeout (10 minutes)
$timeout = 600;

// Check if user is logged in
if (!isset($_SESSION['current_user'])) {
    header("Location: /AI_Builders/login.php");
    exit();
}
else{
    $stid = $_SESSION["current_user"];
}

// Check inactivity timeout
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: /AI_Builders/login.php");
    exit();
}

// Update last activity time
$_SESSION['LAST_ACTIVITY'] = time();


// Get course slug from URL
if(isset($_GET['course_id'])){
    $course_id = $_GET['course_id'];
} else {
    // Redirect to dashboard if no course specified
    header("Location: /AI_Builders/dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Result Portal - Dashboard</title>
        <!-- Favicons -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/favicon_io/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon_io/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon_io/favicon-16x16.png">
    <link rel="icon" href="assets/favicon_io/favicon.ico">
    <link rel="manifest" href="assets/favicon_io/site.webmanifest">
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">



    
    
    
    
    <link rel="stylesheet" href="/AI_Builders/assets/css/exams.css">
    <script src="/AI_Builders/assets/js/jquery.js"></script>  
    <script src="/AI_Builders/assets/js/exams.js"></script>  

    <!-- <link rel="stylesheet" href="/AI_Builders/assets/css/subjects.css"> -->

    <!-- <script src="assets/js/subjects.js"></script> -->
  
</head>
<body>
    <div class="container">
        <!-- Dashboard Header -->
        <div class="dashboard-header">
            <div class="subject-info">
                <span class="subject-label">Subject:</span>
                <h1 class="subject-name" id="subjectName">
                    <span class="loading-indicator" id="loadingIndicator"></span>
                </h1>
                <span class="subject-code" id="subjectCode"></span>
                <span class="dynamic-badge">
                    <span class="pulse-dot"></span>
                    Live Data
                </span>
            </div>
            <p class="semester-info" id="semesterInfo">Loading semester information...</p>
        </div>

        <!-- Results Container -->
        <div class="results-container">
            <h2 class="section-title">Assessment Results</h2>
            
            <div class="results-grid" id="resultsGrid">
                <!-- Cards will be populated by JavaScript -->
            </div>

            <!-- Summary Card -->
            <div class="summary-card">
                <h3 class="summary-title">Overall Performance</h3>
                <div class="summary-stats">
                    <div class="stat-item">
                        <div class="stat-value" id="totalScore">0</div>
                        <div class="stat-label">Total Score</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" id="averagePercent">0%</div>
                        <div class="stat-label">Average</div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <input type="hidden" name="hiddenStId" id="hiddenStId" value="<?php echo($stid);?>"> 

    <input type="hidden" name="hiddenCourseId" id = "hiddenCourseId" value= "<?php echo($course_id);?>">

    
</body>
</html>