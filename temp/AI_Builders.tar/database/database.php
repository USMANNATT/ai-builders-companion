<?php
// creating database class using SRB(single responsibilty principle) that only builds connnection b/w Database and any php file where object of this file is created
class Database{


    //making variables private for better security 
    private $servername = "localhost";
    private $username = "u725099291_lms_admin";
    private $password = "TQj+M2niQ5|u";
    private $dbname = "u725099291_lms_db";
    public $conn = null;

    // This function is executed automatically whenever an instance/object of the class "database"  is created
    public function __construct() {
        try {
            // Create connection using PDO (php  data objects)

            // $this is used in class scope to access properties and methods of this class.
            // $object is used Outside the the class scope to access properties and methods of this class
            $this->conn = new PDO("mysql:host=$this->servername;dbname=$this->dbname", $this->username,  $this->password);
    
            // Set error mode to exception
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
            /* Success message (for testing only) echo "<h1>Database Connected Successfully</h1>";*/
    
        }
        catch (PDOException $e) {
    
            // If connection fails, show error
            echo "Database Connection Failed: " . $e->getMessage();
        }
 
    }

} 
?>



