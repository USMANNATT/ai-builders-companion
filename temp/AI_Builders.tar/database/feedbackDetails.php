<?php
$path = $_SERVER['DOCUMENT_ROOT'];
require_once $path . "/AI_Builders/database/database.php";

class feedback_details {

    // =========================================
    // CHECK IF FEEDBACK EXISTS IN LAST 7 DAYS
    // =========================================
    public function hasRecentFeedback($dbo, $student_id, $course_id) {

        $cmd = "
            SELECT feedback_id
            FROM course_feedback
            WHERE student_id = :student_id
              AND course_id = :course_id
              AND created_at >= NOW() - INTERVAL 7 DAY
            LIMIT 1
        ";

        $stmt = $dbo->conn->prepare($cmd);
        $stmt->execute([
            ":student_id" => $student_id,
            ":course_id"  => $course_id
        ]);

        return $stmt->rowCount() > 0;
    }

    // ===============================
    // INSERT FEEDBACK
    // ===============================
    public function insertFeedback($dbo, $student_id, $course_id, $email, $rating, $message) {

        // ===============================
        // GET faculty_id FROM course_allotment
        // ===============================
        $cmd = "
            SELECT faculty_id
            FROM course_allotment
            WHERE course_id = :course_id
            LIMIT 1
        ";

        $stmt = $dbo->conn->prepare($cmd);
        $stmt->execute([":course_id" => $course_id]);
        $faculty = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$faculty) {
            return false;
        }

        $faculty_id = $faculty['faculty_id'];

        // ===============================
        // INSERT FEEDBACK
        // ===============================
        $cmd = "
            INSERT INTO course_feedback
            (student_id, course_id, faculty_id, email, rating, feedback_message)
            VALUES
            (:student_id, :course_id, :faculty_id, :email, :rating, :message)
        ";

        $stmt = $dbo->conn->prepare($cmd);

        return $stmt->execute([
            ":student_id" => $student_id,
            ":course_id"  => $course_id,
            ":faculty_id" => $faculty_id,
            ":email"      => $email,
            ":rating"     => $rating,
            ":message"    => $message
        ]);
    }







    // ===============================
    // GET ALL FEEDBACK BY FACULTY
    // ===============================
    public function getFeedbackByFaculty($dbo, $faculty_id) {

        $cmd = "SELECT 
                cf.feedback_id,
                cf.email,
                cf.rating,
                cf.feedback_message,
                DATE_FORMAT(cf.created_at, '%b %d, %Y') AS created_at,
                s.name,
                s.roll_no
            FROM course_feedback cf
            INNER JOIN student_details s ON cf.student_id = s.id
            WHERE cf.faculty_id = :faculty_id
            ORDER BY cf.created_at DESC;
        ";

        $stmt = $dbo->conn->prepare($cmd);
        $stmt->execute([
            ":faculty_id" => $faculty_id
        ]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

}
