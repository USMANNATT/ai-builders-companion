<?php
// Going to root directory
$path = $_SERVER['DOCUMENT_ROOT'];
 
// Getting inside or database file and loading it here 
require_once $path."/AI_Builders/database/database.php";


class SessionDetails {
    
    public function getSessions($dbo) {
        $rv = []; // Declaring an associative array to hold the results.
        $cmd = "select * from session_details"; // SQL command to select all session details.
        $st = $dbo->conn->prepare($cmd); // Preparing the SQL statement.
        
        try {
            $st->execute(); // Executing the prepared statement.
            $rv = $st->fetchAll(PDO::FETCH_ASSOC); // Fetching all results as an associative array.

        } catch (Exception $e) {
            error_log("Error fetching sessions: " . $e->getMessage()); // Logging any errors that occur during execution.
        }

        return $rv; // Returning the array of session details.
    }
}
?>