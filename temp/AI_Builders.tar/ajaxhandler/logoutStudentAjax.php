<?php
session_start();     // Start session

session_unset();     // Remove all session variables
session_destroy();   // Destroy session

// Redirect to login page
header("Location: /AI_Builders/login.php");
exit();
?>
