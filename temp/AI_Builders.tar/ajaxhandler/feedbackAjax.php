<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json'); // Always return JSON

require_once(__DIR__ . "/../database/database.php");
require_once(__DIR__ . "/../database/feedbackDetails.php");

$dbo = new Database();
$fbo = new feedback_details();

$response = [
    "status" => false,
    "message" => "Unknown error"
];

// ===============================
// GET ACTION
// ===============================
$action = $_REQUEST['action'] ?? '';

try {

    // ===============================
    // GET FEEDBACK FOR FACULTY
    // ===============================
    if ($action === "getFacultyFeedback") {
        if (!isset($_POST['faculty_id'])) {
            throw new Exception("Faculty ID is missing");
        }

        $faculty_id = $_POST['faculty_id'];
        $data = $fbo->getFeedbackByFaculty($dbo, $faculty_id);

        $response = [
            "status" => true,
            "data"   => $data
        ];
        echo json_encode($response);
        exit;
    }

    // ===============================
    // SUBMIT FEEDBACK
    // ===============================
    if ($action === "submitFeedback") {

        if (!isset($_SESSION['current_user'])) {
            throw new Exception("Unauthorized. Please log in.");
        }

        $student_id = $_SESSION['current_user'];
        $course_id  = $_POST['course_id'] ?? null;
        $email      = $_POST['email'] ?? null;
        $rating     = $_POST['rating'] ?? null;
        $message    = $_POST['message'] ?? null;

        if (!$course_id || !$email || !$rating || !$message) {
            throw new Exception("All fields are required");
        }

        // Weekly cooldown
        if ($fbo->hasRecentFeedback($dbo, $student_id, $course_id)) {
            $response = [
                "status" => false,
                "message" => "Cooldown period submit feedaback after 7 days"
            ];
            echo json_encode($response);
            exit;
        }

        // Insert feedback
        $success = $fbo->insertFeedback(
            $dbo,
            $student_id,
            $course_id,
            $email,
            $rating,
            $message
        );

        $response = [
            "status" => $success,
            "message" => $success ? "feedback submitted successfuly" : "Failed to submit feedback"
        ];

        echo json_encode($response);
        exit;
    }

    // ===============================
    // UNKNOWN ACTION
    // ===============================
    throw new Exception("Invalid action: $action");

} catch (Exception $e) {
    $response = [
        "status" => false,
        "message" => $e->getMessage()
    ];
    echo json_encode($response);
    exit;
}
