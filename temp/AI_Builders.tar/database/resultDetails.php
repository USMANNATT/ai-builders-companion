<?php
$path = $_SERVER['DOCUMENT_ROOT']; 
require_once $path . "/AI_Builders/database/database.php";

class result_details {

    public function insertResultsBulk($dbo, $rows, $faculty_id, $exam_type, $total_marks) {

        try {

            // ==================================================
            // START DATABASE TRANSACTION
            // ==================================================
            $dbo->conn->beginTransaction();

            // ==================================================
            // 1️⃣ GET COURSE ID FROM FACULTY TABLE
            // ==================================================
            $sqlCourse = "SELECT course_id
                          FROM course_allotment
                          WHERE faculty_id = :faculty_id
                          LIMIT 1";

            $stmtCourse = $dbo->conn->prepare($sqlCourse);
            $stmtCourse->execute([
                ":faculty_id" => $faculty_id
            ]);

            $course = $stmtCourse->fetch(PDO::FETCH_ASSOC);

            // If no course found → stop process
            if (!$course) {
                throw new Exception("Course not found for faculty");
            }

            $course_id = $course['course_id'];

            $totalClassMarks = 0;
            $studentCount = 0;

            // ==================================================
            // 2️⃣ LOOP THROUGH EACH EXCEL ROW
            // ==================================================
            foreach ($rows as $row) {

                // Safe reading from Excel columns
                $roll_no = isset($row['A']) ? strtoupper(trim((string)$row['A'])) : '';
                $marks   = isset($row['B']) ? trim((string)$row['B']) : '';

                // Skip completely empty rows
                if ($roll_no === '' && $marks === '') {
                    continue;
                }

                // Skip invalid rows
                if ($roll_no === '' || $marks === '' || !is_numeric($marks) || $marks > $total_marks) {
                    continue;
                }

                // ==================================================
                // 3️⃣ FIND STUDENT ID USING ROLL NUMBER
                // ==================================================
                $sqlStudent = "SELECT id
                               FROM student_details
                               WHERE UPPER(roll_no) = :roll_no";

                $stmtStudent = $dbo->conn->prepare($sqlStudent);
                $stmtStudent->execute([
                    ":roll_no" => $roll_no
                ]);

                $student = $stmtStudent->fetch(PDO::FETCH_ASSOC);

                // If student not found → skip
                if (!$student) {
                    continue;
                }

                $student_id = $student['id'];

                // ==================================================
                // 4️⃣ INSERT INTO result_details TABLE
                // ==================================================
                $sqlInsert = "INSERT INTO result_details
                              (student_id, course_id, exam_type, marks, total_marks)
                              VALUES
                              (:student_id, :course_id, :exam_type, :marks, :total_marks)";

                $stmtInsert = $dbo->conn->prepare($sqlInsert);
                $stmtInsert->execute([
                    ":student_id"  => $student_id,
                    ":course_id"   => $course_id,
                    ":exam_type"   => $exam_type,
                    ":marks"       => $marks,
                    ":total_marks" => $total_marks
                ]);

                // ==================================================
                // 5️⃣ CALCULATE STUDENT TOTAL (ALL EXAMS OF COURSE)
                // ==================================================
                $sqlTotal = "SELECT 
                                SUM(marks) AS total_obtained,
                                SUM(total_marks) AS total_marks
                             FROM result_details
                             WHERE student_id = :student_id
                             AND course_id = :course_id";

                $stmtTotal = $dbo->conn->prepare($sqlTotal);
                $stmtTotal->execute([
                    ":student_id" => $student_id,
                    ":course_id"  => $course_id
                ]);

                $totals = $stmtTotal->fetch(PDO::FETCH_ASSOC);

                $total_obtained = $totals['total_obtained'] ?? 0;
                $overall_total  = $totals['total_marks'] ?? 0;

                // Calculate percentage safely
                $percentage = 0;
                if ($overall_total > 0) {
                    $percentage = ($total_obtained / $overall_total) * 100;
                }

                // ==================================================
                // 6️⃣ INSERT OR UPDATE student_overall_results
                // ==================================================
                $sqlCheck = "SELECT id 
                             FROM student_overall_results
                             WHERE student_id = :student_id
                             AND course_id = :course_id";

                $stmtCheck = $dbo->conn->prepare($sqlCheck);
                $stmtCheck->execute([
                    ":student_id" => $student_id,
                    ":course_id"  => $course_id
                ]);

                $exists = $stmtCheck->fetch(PDO::FETCH_ASSOC);

                if ($exists) {

                    // 🔄 UPDATE if record already exists
                    $sqlUpdateOverall = "UPDATE student_overall_results
                                         SET total_obtained = :total_obtained,
                                             total_marks = :total_marks,
                                             percentage = :percentage,
                                             updated_at = NOW()
                                         WHERE student_id = :student_id
                                         AND course_id = :course_id";

                    $stmtUpdateOverall = $dbo->conn->prepare($sqlUpdateOverall);
                    $stmtUpdateOverall->execute([
                        ":total_obtained" => $total_obtained,
                        ":total_marks"    => $overall_total,
                        ":percentage"     => $percentage,
                        ":student_id"     => $student_id,
                        ":course_id"      => $course_id
                    ]);

                } else {

                    // ➕ INSERT if not exists
                    $sqlInsertOverall = "INSERT INTO student_overall_results
                                         (student_id, course_id, total_obtained, total_marks, percentage, updated_at)
                                         VALUES
                                         (:student_id, :course_id, :total_obtained, :total_marks, :percentage, NOW())";

                    $stmtInsertOverall = $dbo->conn->prepare($sqlInsertOverall);
                    $stmtInsertOverall->execute([
                        ":student_id"     => $student_id,
                        ":course_id"      => $course_id,
                        ":total_obtained" => $total_obtained,
                        ":total_marks"    => $overall_total,
                        ":percentage"     => $percentage
                    ]);
                }

                $totalClassMarks += (float)$marks;
                $studentCount++;
            }

            // ==================================================
            // 7️⃣ UPDATE CLASS AVERAGE
            // ==================================================
            if ($studentCount > 0) {

                $classAverage = $totalClassMarks / $studentCount;

                $sqlUpdateAvg = "UPDATE result_details
                                 SET average_marks = :average
                                 WHERE course_id = :course_id
                                 AND exam_type = :exam_type";

                $stmtUpdateAvg = $dbo->conn->prepare($sqlUpdateAvg);
                $stmtUpdateAvg->execute([
                    ":average"   => $classAverage,
                    ":course_id" => $course_id,
                    ":exam_type" => $exam_type
                ]);
            }

            // Commit all changes
            $dbo->conn->commit();

        } catch (Exception $e) {

            // Rollback if any error occurs
            $dbo->conn->rollBack();
            throw new Exception("Database Error: " . $e->getMessage());
        }
    }








    // ==========================================================
    // FUNCTION: GET FULL STUDENT RESULT DATA
    // ==========================================================
    public function getStudentFullResults($dbo, $student_id, $course_id){

        // =========================
        // 1️⃣ GET COURSE DETAILS
        // =========================
        $sqlCourse = "SELECT course_code AS code,
                            course_title AS title
                    FROM course_details
                    WHERE id = :course_id";

        $stmtCourse = $dbo->conn->prepare($sqlCourse);
        $stmtCourse->execute([":course_id"=>$course_id]);
        $course = $stmtCourse->fetch(PDO::FETCH_ASSOC);

        // =========================
        // 2️⃣ GET SESSION DETAILS
        // =========================
        $sqlSession = "SELECT s.term AS session_name
                        FROM session_details s
                        JOIN course_registration cr
                            ON cr.session_id = s.id
                        WHERE cr.student_id = :student_id
                        AND cr.course_id = :course_id
                        LIMIT 1";

        $stmtSession = $dbo->conn->prepare($sqlSession);
        $stmtSession->execute([
            ":student_id"=>$student_id,
            ":course_id"=>$course_id
        ]);
        $session = $stmtSession->fetch(PDO::FETCH_ASSOC);

        // =========================
        // 3️⃣ GET STUDENT RESULTS
        // =========================
        $sqlResults = "SELECT exam_type,
                            marks,
                            total_marks,
                            average_marks AS class_average
                    FROM result_details
                    WHERE student_id = :student_id
                    AND course_id = :course_id";

        $stmtResults = $dbo->conn->prepare($sqlResults);
        $stmtResults->execute([
            ":student_id"=>$student_id,
            ":course_id"=>$course_id
        ]);
        $results = $stmtResults->fetchAll(PDO::FETCH_ASSOC);

        // =========================
        // 4️⃣ GET OVERALL SUMMARY
        // =========================
        $sqlOverall = "SELECT total_obtained,
                            total_marks,
                            percentage
                    FROM student_overall_results
                    WHERE student_id = :student_id
                    AND course_id = :course_id";

        $stmtOverall = $dbo->conn->prepare($sqlOverall);
        $stmtOverall->execute([
            ":student_id"=>$student_id,
            ":course_id"=>$course_id
        ]);
        $overall = $stmtOverall->fetch(PDO::FETCH_ASSOC);

        return [
            "course"=>$course,
            "session"=>$session,
            "results"=>$results,
            "overall"=>[
                "total_score"=>$overall['total_obtained']."/".$overall['total_marks'],
                "percentage"=>$overall['percentage']
            ]
        ];
    }

}
