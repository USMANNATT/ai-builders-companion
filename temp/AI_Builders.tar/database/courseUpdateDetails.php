<?php
// Going to root directory
$path = $_SERVER['DOCUMENT_ROOT']; 
// Getting inside or database file and loading it here 
require_once $path."/AI_Builders/database/database.php";

class course_updates {

    public function insertUpdate($dbo, $course_id, $faculty_id, $type, $message, $date, $time) {

        $sql = "INSERT INTO course_updates
                (course_id, faculty_id, update_type, update_message, update_date, update_time)
                VALUES
                (:course_id, :faculty_id, :type, :message, :date, :time)";

        $stmt = $dbo->conn->prepare($sql);
        $stmt->execute([
            ":course_id"  => $course_id,
            ":faculty_id" => $faculty_id,
            ":type"       => $type,
            ":message"    => $message,
            ":date"       => $date,
            ":time"       => $time
        ]);
    }



    public function fetchUpdates($dbo, $course_id) {

        $sql = "
            SELECT 
                update_type,
                update_message,
                DATE_FORMAT(update_date, '%d %b %Y') AS update_date,
                update_time
            FROM course_updates
            WHERE course_id = :course_id
              AND status = 'active'
            ORDER BY created_at DESC
        ";
    
        $stmt = $dbo->conn->prepare($sql);
        $stmt->execute([
            ":course_id" => $course_id
        ]);
    
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
}
