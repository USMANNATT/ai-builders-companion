// =====================================================================
// ATTENDANCE.JS — with Section Selector (A–I)
// Changes from original:
//   1. After clicking a course card → show section buttons (A–I)
//   2. After clicking a section → fetch student list for that section
//   3. sectionid is passed to fetchStudentList, saveAttendance,
//      downloadCSVFile, downloadCurrentDateExcelFile, downloadLMSExcelReport
// =====================================================================


function logActivityJS(module, action, status, role) {
    $.ajax({
        url: '/AI_Builders/ajaxhandler/log_activity_ajax.php',
        type: 'POST',
        data: { module, action, status, role },
        success: function(res) { console.log('Activity Logged:', res); },
        error:   function(err) { console.error('Activity Logging Failed:', err); }
    });
}

// ── Session dropdown HTML ─────────────────────────────────────────────
function getSessionHTML(rv) {
    let x = `<option value=-1>Select One</option>`;
    for (let i = 0; i < rv.length; i++) {
        let cs = rv[i];
        x += `<option value=${cs['id']}>${cs['year'] + " " + cs['term']}</option>`;
    }
    return x;
}

function loadSessions() {
    $.ajax({
        url: "/AI_Builders/ajaxhandler/attendanceAJAX.php",
        type: "POST", dataType: "json",
        data: { action: "getSession" },
        success: function(rv) { $("#ddlclass").html(getSessionHTML(rv)); },
        error:   function()   { alert("OPPS SOMETHING WENT WRONG"); }
    });
}

// ── Course cards HTML ─────────────────────────────────────────────────
function getCoursesCardHTML(classlist) {
    let x = ``;
    for (let i = 0; i < classlist.length; i++) {
        let cc = classlist[i];
        x += `<div class="classcard" data-classobject='${JSON.stringify(cc)}'>${cc['course_code']}</div>`;
    }
    return x;
}

function fetchFacultyCourses(facid, sessionid) {
    $.ajax({
        url: "/AI_Builders/ajaxhandler/attendanceAJAX.php",
        type: "POST", dataType: "json",
        data: { facid, sessionid, action: "getFacultyCourses" },
        success: function(rv) { $("#classlistarea").html(getCoursesCardHTML(rv)); },
        error:   function()   { alert("OPPS SOMETHING WENT WRONG"); }
    });
}

// ── NEW: Section selector ─────────────────────────────────────────────
// Sections A–I map to section_details ids 1–9
// (A=1, B=2, C=3, D=4, E=5, F=6, G=7, H=8, I=9)
var sectionMap = {
    'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5,
    'F': 6, 'G': 7, 'H': 8, 'I': 9
};

function buildSectionButtons() {
    let html = ``;
    let letters = ['A','B','C','D','E','F','G','H','I'];
    letters.forEach(function(letter) {
        html += `<button class="btn-section" data-sectionletter="${letter}" data-sectionid="${sectionMap[letter]}">${letter}</button>`;
    });
    return html;
}

function showSectionSelector() {
    $("#sectionButtons").html(buildSectionButtons());
    $("#sectionSelectorArea").slideDown(200);
    // Reset previous section selection
    $("#hiddenSelectedSectionId").val(-1);
    // Clear student list and class details until section is chosen
    $("#studentlistarea").html(``);
}

function hideSectionSelector() {
    $("#sectionSelectorArea").slideUp(200);
}

// ── Class details area HTML ───────────────────────────────────────────
function getClassdetailsAreaHTML(classobject, sectionLetter) {
    let dobj   = new Date();
    let year   = dobj.getFullYear();
    let month  = dobj.getMonth() + 1;
    if (month < 10) month = "0" + month;
    let day    = dobj.getDate();
    if (day < 10)  day  = "0" + day;
    let ondate = year + "-" + month + "-" + day;

    // Show section badge if a section is selected
    let sectionBadge = sectionLetter
        ? `<div class="section-badge">SECTION ${sectionLetter}</div>`
        : ``;

    let x = `<div class="classdetails">
                <div class="code-area">${classobject['course_code']}</div>
                <div class="title-area">${classobject['course_title']}</div>
                ${sectionBadge}
                <div class="ondate-area"><input type="date" id="dtpondate" value='${ondate}'></div>
             </div>`;
    return x;
}

// ── Fetch student list (NOW includes sectionid) ───────────────────────
function fetchStudentList(sessionid, classid, facultyid, ondate, sectionid) {
    $.ajax({
        url: "/AI_Builders/ajaxhandler/attendanceAJAX.php",
        type: "POST", dataType: "json",
        data: {
            sessionid,
            classid,
            facultyid,
            ondate,
            sectionid,          // ← NEW
            action: "getStudentList"
        },
        success: function(rv) { $("#studentlistarea").html(getStudentListHTML(rv)); },
        error:   function()   { }
    });
}

// ── Student list HTML ─────────────────────────────────────────────────
function getStudentListHTML(studentList) {
    let x = `<div class="studenttlist" style="background-color:#001f3f;color:#ffffff;padding:12px 10px;border:2px solid #ffffff;border-radius:5px;font-size:22px;font-weight:bold;text-align:center;letter-spacing:1px;">
                STUDENT LIST
             </div>
             <div class="studentdetails" style="background-color:navy;color:white;">
                <div class="slno-area"    style="font-weight:bold;">Serial No</div>
                <div class="rollno-area"  style="background-color:transparent;color:white;font-weight:bold;">Roll number</div>
                <div class="name-area"    style="font-weight:bold;">Student Name</div>
                <div class="checkbox-area" style="font-weight:bold;">Status</div>
             </div>`;

    for (let i = 0; i < studentList.length; i++) {
        let cs = studentList[i];
        let checkedState = ``;
        let rowColor = 'absentColor';
        if (cs['status'] == "YES") { checkedState = "checked"; rowColor = 'presentColor'; }

        x += `<div class="studentdetails ${rowColor}" id="student${cs['id']}">
                <div class="slno-area">${i + 1}</div>
                <div class="rollno-area">${cs['roll_no']}</div>
                <div class="name-area">${cs['name']}</div>
                <div class="checkbox-area" data-studentid='${cs['id']}'>
                    <input type="checkbox" class="cbpresent" data-studentid='${cs['id']}' ${checkedState}>
                </div>
              </div>`;
    }

    x += `<div class="reportsection">
            <button id="btnReportInExcel">Report</button>
            <button id="btnReportInExcelLMS">Report for LMS</button>
            <button id="btnCurrentDateReportInExcel">Today's Report</button>
          </div>
          <div id="divReport"></div>`;

    return x;
}

// ── Save attendance (NOW includes sectionid) ──────────────────────────
function saveAttendance(studentid, courseid, facultyid, sessionid, ondate, ispresent, sectionid) {
    $.ajax({
        url: "/AI_Builders/ajaxhandler/attendanceAJAX.php",
        type: "POST", dataType: "json",
        data: {
            studentid, courseid, facultyid, sessionid, ondate, ispresent,
            sectionid,          // ← NEW
            action: "saveAttendance"
        },
        success: function(rv) {
            if (ispresent == "YES") {
                $("#student" + studentid).removeClass("absentColor").addClass("presentColor");
            } else if (ispresent == "NO") {
                $("#student" + studentid).removeClass("presentColor").addClass("absentColor");
            }
        },
        error: function() { alert("OPPS SOMETHING WENT WRONG"); }
    });
}

// ── CSV / Excel downloads (NOW include sectionid) ─────────────────────
function downloadCSVFile(sessionid, classid, facultyid, sectionid, newTab) {
    $.ajax({
        url: "/AI_Builders/ajaxhandler/attendanceAJAX.php",
        type: "POST", dataType: "json",
        data: { sessionid, classid, facultyid, sectionid, action: "downloadCSVFile" },
        success: function(rv) {
            let a = document.createElement("a");
            a.href = rv['filename']; a.download = "";
            document.body.appendChild(a); a.click(); document.body.removeChild(a);
            if (newTab) newTab.location.href = rv['filename'];
        },
        error: function(e) { alert(JSON.stringify(e)); }
    });
}

function downloadCurrentDateExcelFile(sessionid, classid, facultyid, ondate, sectionid) {
    $.ajax({
        url: "/AI_Builders/ajaxhandler/attendanceAJAX.php",
        type: "POST", dataType: "json",
        data: { sessionid, classid, facultyid, ondate, sectionid, action: "downloadCurrentDateExcelFile" },
        success: function(rv) {
            let a = document.createElement("a");
            a.href = rv.filename; a.download = "";
            document.body.appendChild(a); a.click(); document.body.removeChild(a);
        },
        error: function() { alert("Error generating today's report."); }
    });
}

function downloadLMSExcelReport(sessionid, classid, facultyid, sectionid) {
    $.ajax({
        url: "/AI_Builders/ajaxhandler/attendanceAJAX.php",
        type: "POST", dataType: "json",
        data: { sessionid, classid, facultyid, sectionid, action: "downloadLMSExcelReport" },
        success: function(rv) {
            if (typeof rv === "string") {
                try { rv = JSON.parse(rv); } catch(e) { alert("Invalid JSON response from server:\n\n" + rv); return; }
            }
            if (rv.status === "success") {
                if (!rv.filename) { alert("Filename missing from server response."); return; }
                let a = document.createElement("a");
                a.href = rv.filename; a.download = "";
                document.body.appendChild(a); a.click(); document.body.removeChild(a);
            } else {
                alert("Server Error:\n\n" + (rv.message || "Unknown error occurred."));
            }
        },
        error: function(xhr, status, error) {
            alert("AJAX Error:\n\nStatus: " + status + "\nError: " + error + "\n\nServer Response:\n" + xhr.responseText);
        }
    });
}

// ── MAIN jQuery ───────────────────────────────────────────────────────
$(function () {

    // 1. LOGOUT
    $(document).on("click", "#btnLogout", function () {
        $.ajax({
            url: "/AI_Builders/ajaxhandler/logout_ajax.php",
            type: "POST", dataType: "json", data: { id: 1 },
            success: function () {
                logActivityJS('Attendance Page', 'Logged Out', 'Completed', 'Faculty');
                window.location.href = "/AI_Builders/login.php";
            },
            error: function () { alert("ERROR: SOMETHING WENT WRONG"); }
        });
    });

    // 2. LOAD SESSIONS
    loadSessions();

    // 3. SESSION CHANGED
    $(document).on("change", "#ddlclass", function () {
        let sessionid = $("#ddlclass").val();
        if (sessionid != -1) {
            let facid = $("#hiddenFacId").val();
            fetchFacultyCourses(facid, sessionid);
            // Reset section & student panels
            hideSectionSelector();
            $("#classdetailsarea").html(``);
            $("#studentlistarea").html(``);
            $("#hiddenSelectedCourseId").val(-1);
            $("#hiddenSelectedSectionId").val(-1);
            logActivityJS('Attendance Page', `Selected Session ID: ${sessionid}`, 'Completed', 'Faculty');
        }
    });

    // 4. COURSE CARD CLICKED → show section selector
    $(document).on("click", ".classcard", function () {
        let classobject = $(this).data('classobject');

        // Highlight active card
        $(".classcard").removeClass("active");
        $(this).addClass("active");

        // Store course id
        $("#hiddenSelectedCourseId").val(classobject['id']);

        // Reset section selection and student list
        $("#hiddenSelectedSectionId").val(-1);
        $("#studentlistarea").html(``);
        $("#classdetailsarea").html(``);

        // Show section buttons
        showSectionSelector();

        logActivityJS('Attendance Page', `Clicked Course Card ID: ${classobject['id']}`, 'Completed', 'Faculty');
    });

    // 5. SECTION BUTTON CLICKED → fetch students for course+section
    $(document).on("click", ".btn-section", function () {
        let sectionid     = $(this).data('sectionid');
        let sectionletter = $(this).data('sectionletter');

        // Highlight active section button
        $(".btn-section").removeClass("section-active");
        $(this).addClass("section-active");

        // Store section id
        $("#hiddenSelectedSectionId").val(sectionid);

        let classobject = $(".classcard.active").data('classobject');
        if (!classobject) return;

        let sessionid  = $("#ddlclass").val();
        let classid    = classobject['id'];
        let facultyid  = $("#hiddenFacId").val();

        // Update class details area (shows section badge)
        $('#classdetailsarea').html(getClassdetailsAreaHTML(classobject, sectionletter));

        let ondate = $("#dtpondate").val();
        if (!ondate) {
            let d = new Date();
            let m = String(d.getMonth()+1).padStart(2,'0');
            let day = String(d.getDate()).padStart(2,'0');
            ondate = `${d.getFullYear()}-${m}-${day}`;
        }

        if (sessionid != -1) {
            fetchStudentList(sessionid, classid, facultyid, ondate, sectionid);
        }

        logActivityJS('Attendance Page', `Selected Section ${sectionletter} (ID: ${sectionid})`, 'Completed', 'Faculty');
    });

    // 6. DATE CHANGED → refetch with same section
    $(document).on("change", "#dtpondate", function () {
        let sessionid  = $("#ddlclass").val();
        let classid    = $("#hiddenSelectedCourseId").val();
        let facultyid  = $("#hiddenFacId").val();
        let sectionid  = $("#hiddenSelectedSectionId").val();
        let ondate     = $(this).val();

        if (sessionid != -1 && classid && sectionid != -1) {
            fetchStudentList(sessionid, classid, facultyid, ondate, sectionid);
        }
    });

    // 7. SAVE ATTENDANCE CHECKBOX
    $(document).on("click", ".cbpresent", function () {
        let ispresent  = this.checked ? "YES" : "NO";
        let studentid  = $(this).data('studentid');
        let courseid   = $("#hiddenSelectedCourseId").val();
        let facultyid  = $("#hiddenFacId").val();
        let sessionid  = $("#ddlclass").val();
        let sectionid  = $("#hiddenSelectedSectionId").val();
        let ondate     = $("#dtpondate").val();

        saveAttendance(studentid, courseid, facultyid, sessionid, ondate, ispresent, sectionid);
        logActivityJS('Attendance Page', `Marked Attendance: Student ID ${studentid} = ${ispresent}`, 'Completed', 'Faculty');
    });

    // 8. REPORT IN EXCEL
    $(document).on("click", "#btnReportInExcel", function () {
        let sessionid = $("#ddlclass").val();
        let classid   = $("#hiddenSelectedCourseId").val();
        let facultyid = $("#hiddenFacId").val();
        let sectionid = $("#hiddenSelectedSectionId").val();
        if (sessionid != -1 && sectionid != -1) {
            let newTab = window.open('about:blank', '_blank');
            downloadCSVFile(sessionid, classid, facultyid, sectionid, newTab);
            logActivityJS('Attendance Page', `Downloaded Excel Report: Class ID ${classid}`, 'Completed', 'Faculty');
        }
    });

    // 9. TODAY'S REPORT
    $(document).on("click", "#btnCurrentDateReportInExcel", function () {
        let sessionid = $("#ddlclass").val();
        let classid   = $("#hiddenSelectedCourseId").val();
        let facultyid = $("#hiddenFacId").val();
        let sectionid = $("#hiddenSelectedSectionId").val();
        let ondate    = $("#dtpondate").val();
        if (sessionid != -1 && sectionid != -1) {
            downloadCurrentDateExcelFile(sessionid, classid, facultyid, ondate, sectionid);
            logActivityJS('Attendance Page', `Downloaded Today Report: Class ID ${classid}, Date ${ondate}`, 'Completed', 'Faculty');
        }
    });

    // 10. LMS REPORT
    $(document).on("click", "#btnReportInExcelLMS", function () {
        let sessionid = $("#ddlclass").val();
        let classid   = $("#hiddenSelectedCourseId").val();
        let facultyid = $("#hiddenFacId").val();
        let sectionid = $("#hiddenSelectedSectionId").val();
        if (sessionid != -1 && sectionid != -1) {
            downloadLMSExcelReport(sessionid, classid, facultyid, sectionid);
            logActivityJS('Attendance Page', `Downloaded LMS Report: Class ID ${classid}`, 'Completed', 'Faculty');
        }
    });

});
