<?php
// =============================
// SHOW ALL ERRORS
// =============================
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Going to root directory
$path = $_SERVER['DOCUMENT_ROOT']; 
// Load database connection
require_once $path."/AI_Builders/database/database.php";

$dbo = new Database();
// Ensure PDO throws exceptions
$dbo->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


// Timetable array
$timetable = [

    'MONDAY' => [
        ['08:00','09:00', 24, 13, 1],
        ['09:00','10:00', 24, 13, 1],
        ['10:00','11:00', 24, 13, 1],
        ['11:00','12:00', 24, 13, 1],
        ['12:00','13:00', 21, 21, 1],
        ['13:00','14:00', 21, 21, 1],
        ['14:00','15:00', 22, 24, 1],
        ['15:00','16:00', 22, 24, 1],
    ],

    'TUESDAY' => [
        ['08:00','09:00', 21, 21, 1],
        ['09:00','10:00', 24, 13, 1],
        ['10:00','11:00', 24, 13, 1],
        ['11:00','12:00', 20, 20, 1],
        ['12:00','13:00', 19, 19, 1],
        ['13:00','14:00', 21, 21, 1],
        ['14:00','15:00', 22, 24, 1],
        ['15:00','16:00', 22, 24, 1],
    ],

    'WEDNESDAY' => [
        ['08:00','09:00', 23, 13, 1],
        ['09:00','10:00', 22, 24, 1],
        ['10:00','11:00', 22, 24, 1],
        ['11:00','12:00', 22, 24, 1],
        ['12:00','13:00', 22, 24, 1],
        ['13:00','14:00', 22, 24, 1],
        ['14:00','15:00', 22, 24, 1],
        ['15:00','16:00', 23, 13, 1],
    ],

    'THURSDAY' => [
        ['08:00','09:00', 20, 20, 1],
        ['09:00','10:00', 20, 20, 1],
        ['10:00','11:00', 20, 20, 1],
        ['11:00','12:00', 20, 20, 1],
        ['12:00','13:00', 20, 20, 1],
        ['13:00','14:00', 20, 20, 1],
        ['14:00','15:00', 18, 18, 1],
        ['15:00','16:00', 20, 20, 1],
    ],

    'FRIDAY' => [
        ['08:00','09:00', 24, 13, 1],
        ['09:00','10:00', 24, 13, 1],
        ['10:00','11:00', 24, 13, 1],
        ['11:00','12:00', 24, 13, 1],
        ['12:00','13:00', 21, 21, 1],
        ['13:00','14:00', 21, 21, 1],
        ['14:00','15:00', 22, 24, 1],
        ['15:00','16:00', 22, 24, 1],
    ],

];

// Prepare the INSERT statement
$insertStmt = $dbo->conn->prepare("
    INSERT INTO time_table
    (course_id, faculty_id, day_of_week, start_time, end_time, session_id)
    VALUES (:course, :faculty, :day, :start, :end, :session)
");

try {
    // Begin transaction
    $dbo->conn->beginTransaction();

    // Loop through timetable and insert each slot
    foreach ($timetable as $day => $slots) {
        foreach ($slots as $slot) {
            [$start, $end, $course, $faculty, $session] = $slot;

            $insertStmt->execute([
                ':course'  => $course,
                ':faculty' => $faculty,
                ':day'     => $day,
                ':start'   => $start,
                ':end'     => $end,
                ':session' => $session
            ]);
        }
    }

    // Commit all inserts
    $dbo->conn->commit();
    echo "✅ TIMETABLE INSERTED SUCCESSFULLY";

} catch (PDOException $e) {
    $dbo->conn->rollBack();
    echo "❌ PDO ERROR: " . $e->getMessage();
} catch (Exception $e) {
    $dbo->conn->rollBack();
    echo "❌ GENERAL ERROR: " . $e->getMessage();
}


function clearTable($dbo, $tabName) {

    // IMPORTANT: Table name cannot be binded using PDO
    // So we directly insert it after validation

    // Basic safety check (only letters, numbers & underscore allowed)
    if (!preg_match("/^[a-zA-Z0-9_]+$/", $tabName)) {
        die("Invalid table name!");
    }

    // SQL query
    $cmd = "DELETE FROM $tabName";

    try {
        $st = $dbo->conn->prepare($cmd);
        $st->execute();
        echo "<br>Table '$tabName' cleared successfully!";
    } 
    catch (PDOException $e) {
        echo "<br>Error in clearTable(): " . $e->getMessage();
    }
}


/* Creating an object of this class.
Remeber when object is created it create an connnection b/w this php file and databse    automatically using "Database" class and _construct function.
so we do not need to build a connection here. */
$dbo = new Database();

// Creating tables for our Attendance management system

// Creating table for student_details
try{
    // If connection is  created successfully executing commands
    $cmd = "CREATE TABLE student_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    roll_no VARCHAR(20) NOT NULL UNIQUE,
    user_name VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL
    )";

    // prepared statements
    // prepare command
    $st = $dbo->conn->prepare($cmd);
    // executing statements
    $st->execute();
    echo"<br> student_details created";
    }
    // catching exception
    catch  (PDOException $o){
        echo "student_details not created<br>REASON:<br>" . $o->getMessage();
    }


// Creating table for course_details
try{
    // If connection is  created successfully executing commands
    $cmd = "CREATE TABLE course_details (
        id INT AUTO_INCREMENT PRIMARY KEY,
        course_code VARCHAR(20),
        course_title VARCHAR(100),
        semester INT,
        session VARCHAR(10),      
        course_type VARCHAR(10),  
        credit INT,

        UNIQUE(course_code, semester, session)
    )";
    /* " UNIQUE(course_code, semester, session) " MEANS THERE WILL BE ATLEAST ONE UNIQUE FIELD AMONG ( course_code, semester, session) THESE THREE.
    IF ALL ARE SOME THAT SPECIFIC ROW/DATA/COURSE WILL NOT BE INSERTED TO DATABASE TABLE "course_details"*/
    


    // prepared statements
    // prepare command
    $st = $dbo->conn->prepare($cmd);
    // executing statements
    $st->execute();
    echo"<br> course_details created";
}
// catching exception
catch  (PDOException $o){
    echo "course_details not created<br>REASON:<br>" . $o->getMessage();
}
 

// Creating table for faculty_details
try{
    // If connection is  created successfully executing commands
    $cmd = "create table faculty_details(
    id int auto_increment primary key,
    user_name varchar(100) unique,
    name varchar(100),
    password varchar(255) NOT NULL
    )"; 

 


    // prepared statements
    // prepare command
    $st = $dbo->conn->prepare($cmd);
    // executing statements
    $st->execute();
    echo"<br> faculty_details created";
}
// catching exception
catch  (PDOException $o){
    echo "faculty_details not created<br>REASON:<br>" . $o->getMessage();
}



// Creating table for session_details
try{
    // If connection is  created successfully executing commands
    $cmd = "create table session_details (
    id int auto_increment primary key,
    year int,
    term varchar(50),
    unique (year,term)


    )"; 


    // prepared statements
    // prepare command
    $st = $dbo->conn->prepare($cmd);
    // executing statements
    $st->execute();
    echo"<br> session_details craeted";
}
// catching exception
catch  (PDOException $o){
    echo "session_details not created<br>REASON:<br>" . $o->getMessage();
}





//Creating table for course_registration
try{
    // If connection is  created successfully executing commands
    $cmd = "create table course_registration (
    student_id int,
    course_id int,
    session_id int,
    primary key (student_id, course_id,session_id)

    )"; 


    // prepared statements
    // prepare command
    $st = $dbo->conn->prepare($cmd);
    // executing statements
    $st->execute();
    echo"<br>course_registration craeted";
}
// catching exception
catch  (PDOException $o){
    echo "course_registration not created<br>REASON:<br>" . $o->getMessage();
}


//Creating table for course_allotment
try{
    // If connection is  created successfully executing commands
    $cmd = "create table  course_allotment (
    faculty_id int,
    course_id int,
    session_id int,
    primary key (faculty_id, course_id,session_id)
    )"; 


    // prepared statements
    // prepare command
    $st = $dbo->conn->prepare($cmd);
    // executing statements
    $st->execute();
    echo"<br> course_allotment craeted";
}
// catching exception
catch  (PDOException $o){
    echo " course_allotment not created<br>REASON:<br>" . $o->getMessage();
}





//Creating table for attendance_details
try{
    // If connection is  created successfully executing commands
    $cmd = "create table  attendance_details (

    faculty_id int,
    course_id int,
    session_id int,
    student_id int,
    on_date date,
    status varchar(10), 
    primary key (faculty_id, course_id,session_id,student_id,on_date)

    )"; 
    // faculty only take ine attendance at one day 
 

    // prepared statements
    // prepare command
    $st = $dbo->conn->prepare($cmd);
    // executing statements
    $st->execute();
    echo"<br> attendance_details craeted";
}
// catching exception
catch  (PDOException $o){
    echo "attendance_details not created<br>REASON:<br>" . $o->getMessage();
}

/*ADDING SOME DATA IN TABLES FOR TESTING
We Develop a UI for the student/faculty/session/course details process later.
so the non-technical person can add data........


1.we insert records into student_details by using php code .

*/








/* 1. FULL STUDENT LIST (roll_no, full name) */
$student_list = [
    ['2025-AI-61', 'Imama Fatima'],
    ['2025-AI-62', 'Rameesha'],
    ['2025-AI-63', 'Eshal Zainab'],
    ['2025-AI-64', 'Inshra'],
    ['2025-AI-65', 'Rabia Akmar'],
    ['2025-AI-66', 'Wajiha Saleem'],
    ['2025-AI-67', 'Zaib un Nisa'],
    ['2025-AI-68', 'Maryam Ahmad'],
    ['2025-AI-69', 'Eman Fatima'],
    ['2025-AI-70', 'Aiman Bukhari'],
    ['2025-AI-71', 'Muniba Umar Shami'],
    ['2025-AI-72', 'Khansa Manzoor'],
    ['2025-AI-73', 'Sakina Batool'],
    ['2025-AI-74', 'Dua Irfan'],
    ['2025-AI-75', 'Momina Nayab'],
    ['2025-AI-76', 'Zainab Irshad'],
    ['2025-AI-77', 'Sania Zafar'],
    ['2025-AI-78', 'Rabia Sabir'],
    ['2025-AI-79', 'Sana Nasir'],
    ['2025-AI-80', 'Ummara Fatima'],
    ['2025-AI-81', 'Muhammad Tahir Hussain'],
    ['2025-AI-82', 'Usman Ahmad'],
    ['2025-AI-83', 'Zain ul Abideen'],
    ['2025-AI-84', 'Haseeb ur Rehman'],
    ['2025-AI-85', 'Ali Hassan Noor'],
    ['2025-AI-86', 'Muhammad Anas Alam'],
    ['2025-AI-87', 'Usman Hassan'],
    ['2025-AI-88', 'Rao Muhammad Abdullah'],
    ['2025-AI-89', 'Muhammad Azan'],
    ['2025-AI-90', 'Hamza Noor'],
    ['2025-AI-91', 'Raaid Javed'],
    ['2025-AI-92', 'Muhammad Arslan'],
    ['2025-AI-93', 'Muhammad Bin Iftikhar'],
    ['2025-AI-94', 'Azwer Ullah Khan'],
    ['2025-AI-95', 'Muhammad Ashar'],
    ['2025-AI-96', 'Mubashir Randhawa'],
    ['2025-AI-97', 'Amir Hamza'],
    ['2025-AI-98', 'Muhammad Abu Bakar Chaudry'],
    ['2025-AI-99', 'Muhammad Muneeb Altaf'],
    ['2025-AI-100', 'Muhammad Ali'],
    ['2025-AI-101', 'Asjad Rauf'],
    ['2025-AI-102', 'Ali Anns'],
    ['2025-AI-103', 'Muhammad Ahmed Majeed'],
    ['2025-AI-104', 'Hafiz Muhammad Umer Bin Shoaib'],
    ['2025-AI-105', 'Ali Zain Idrees'],
    ['2025-AI-106', 'Ali Azmat'],
    ['2025-AI-107', 'Abdullah Arshad'],
    ['2025-AI-108', 'Muzammil Naseer'],
    ['2025-AI-109', 'Ahsan Imran'],
    ['2025-AI-110', 'Anas Saeed'],
    ['2025-AI-111', 'Adulrehman'],
    ['2025-AI-112', 'Qamar Zaman'],
    ['2025-AI-113', 'Avi Daas'],
    ['2025-AI-114', 'Asfand Shafi'],
    ['2025-AI-116', 'Noor e Haram'],
    ['2025-AI-117', 'Kinza Jahanzeb'],
    ['2025-AI-001', 'Ammara Naveed'],
    ['2025-AI-002', 'Sadia Shafiq'],
    ['2025-AI-003', 'Kanwal Fatima'],
    ['2025-AI-004', 'Nashaman Azam'],
    ['2025-AI-005', 'Afia Sajal'],
    ['2025-AI-006', 'Rabia Jamil'],
    ['2025-AI-007', 'Maira Abid'],
    ['2025-AI-008', 'Shiza'],
    ['2025-AI-009', 'Ayesha Malik'],
    ['2025-AI-010', 'Pakiza Noor'],
    ['2025-AI-011', 'Asma'],
    ['2025-AI-012', 'Sara Sohail'],
    ['2025-AI-013', 'Kainat Irshad'],
    ['2025-AI-014', 'Minahil Javed'],
    ['2025-AI-015', 'Mahnoor Asif'],
    ['2025-AI-016', 'Fiza Farooq'],
    ['2025-AI-017', 'Alina Tayyab'],
    ['2025-AI-018', 'Fatima Noor'],
    ['2025-AI-019', 'Sania Bibi'],
    ['2025-AI-020', 'Eman Rashid'],
    ['2025-AI-021', 'Ashna Arfan'],
    ['2025-AI-022', 'Aayan Khan'],
    ['2025-AI-023', 'Muhammad Sarwar Anjum'],
    ['2025-AI-024', 'Abdul Moiz'],
    ['2025-AI-025', 'Muhammad Abu Baker'],
    ['2025-AI-026', 'Rana Muhammad Asad Saleem'],
    ['2025-AI-027', 'Ahmed Rauf'],
    ['2025-AI-028', 'Syed Izzan Abbas'],
    ['2025-AI-029', 'Muhammad Bilal Irshad'],
    ['2025-AI-030', 'Ammar Riaz'],
    ['2025-AI-031', 'Muhammad Zubair'],
    ['2025-AI-032', 'Abdul Rehman Khan'],
    ['2025-AI-033', 'Muhammad Ahmed'],
    ['2025-AI-034', 'Muhammad Ammar'],
    ['2025-AI-035', 'M Zulkifl'],
    ['2025-AI-036', 'Salman Asghar'],
    ['2025-AI-037', 'Abdul Nafay Minhas'],
    ['2025-AI-038', 'Muhammad Shiblan Nadeem'],
    ['2025-AI-039', 'Muhammad Maaz Sultan'],
    ['2025-AI-040', 'Muhammad Umer'],
    ['2025-AI-041', 'Atta Ur Rehman'],
    ['2025-AI-042', 'Muhammad Waris Akram'],
    ['2025-AI-043', 'Muhammad Abzaan'],
    ['2025-AI-044', 'Muhammad Ibrahim ul Husnain'],
    ['2025-AI-045', 'Faizan Ali'],
    ['2025-AI-046', 'Muhammad Sabeel'],
    ['2025-AI-047', 'Umar Ashraf'],
    ['2025-AI-048', 'Muhammad Zunair'],
    ['2025-AI-049', 'Abdul Wahab Mustafa'],
    ['2025-AI-050', 'Ahmad Bilal'],
    ['2025-AI-051', 'Shaheer ul Haq Sher'],
    ['2025-AI-052', 'Waseem Hussain'],
    ['2025-AI-053', 'Muhammad Waleed'],
    ['2025-AI-054', 'Saim Bin Nazeer'],
    ['2025-AI-055', 'Muhamad Najeeb Ullah']
];

/* 2. FUNCTION TO GENERATE STRONG PASSWORD */



function generateStrongPassword($length = 12){
    $upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $lower = "abcdefghijklmnopqrstuvwxyz";
    $numbers = "0123456789";
    $symbols = "@#$%&*_-+=";


    $all = $upper . $lower . $numbers . $symbols;

    $password = $upper[rand(0,25)].$lower[rand(0,25)].$numbers[rand(0,9)].$symbols[rand(0, strlen($symbols) - 1)];

    for ($i = 4; $i < $length; $i++) {
        $password .= $all[rand(0, strlen($all) - 1)];
    }

    return str_shuffle($password);
}

/* 3. HTML TABLE HEADER */
echo "<table border='1'><tr><th>Roll No</th><th>Name</th><th>Username</th><th>Temporary Password</th></tr>";

/* 4. INSERT DATA INTO student_details */
foreach ($student_list as $student) {
    $roll_no = $student[0];
    $fullname = $student[1];


    $name_parts = explode(' ', trim($fullname));

    $first_name = strtolower($name_parts[0]);
    
    if ($first_name == "muhammad" && count($name_parts) > 1) {
        $first_name = strtolower($name_parts[1]);
    }
    
    $roll_digits = substr($roll_no, -2);
    $username = $first_name . $roll_digits;

    
    $raw_password = generateStrongPassword(12);
    $password = password_hash($raw_password, PASSWORD_DEFAULT);

    try {
        $cmd = "INSERT INTO student_details (roll_no, user_name, name, password)
                VALUES (:roll_no, :username, :fullname, :password)";

        $st = $dbo->conn->prepare($cmd);
        $st->bindParam(':roll_no', $roll_no);
        $st->bindParam(':username', $username);
        $st->bindParam(':fullname', $fullname);
        $st->bindParam(':password', $password);
        $st->execute();

        echo "<tr><td>$roll_no</td><td>$fullname</td><td>$username</td><td>$raw_password</td></tr>";

    } catch(PDOException $e) {
        echo "<br>Student data not inserted for $fullname. Reason: " . $e->getMessage();
    }
}

echo "</table>";











// 2. INSERTING DATA of 1st Semester - Morning  TO DATABSE  course_details TABLE
try{

    $cmd1m = "INSERT INTO course_details 
    (course_code, course_title, semester, session, course_type, credit)
    VALUES
    ('IS-102', 'Islamic Studies / Ethics', 1, 'Morning', 'Theory', 2),
    ('HU-103', 'Functional English', 1, 'Morning', 'Theory', 3),
    ('MA-123', 'Calculus & Analytical Geometry', 1, 'Morning', 'Theory', 3),
    ('AI-121', 'Discrete Mathematics', 1, 'Morning', 'Theory', 3),
    ('AI-101', 'AICT', 1, 'Morning', 'Theory', 2),
    ('AI-101L', 'AICT Lab', 1, 'Morning', 'Lab', 1),
    ('AI-133', 'Programming Fundamentals', 1, 'Morning', 'Theory', 3),
    ('AI-133L', 'Programming Fundamentals Lab', 1, 'Morning', 'Lab', 1)";

    $st = $dbo->conn->prepare($cmd1m);
    // executing statements
    $st->execute();
}
catch  (PDOException $e){
    echo "<br>DUPLICATE ENTRY<br>REASON:<br>" . $e->getMessage();
 
}



// INSERTING DATA  of " 1st Semester - Evening "TO DATABSE  course_details TABLE
try{

    $cmd1e = "INSERT INTO course_details 
    (course_code, course_title, semester, session, course_type, credit)
    VALUES
    ('IS-102', 'Islamic Studies / Ethics', 1, 'Evening', 'Theory', 2),
    ('HU-103', 'Functional English', 1, 'Evening', 'Theory', 3),
    ('MA-123', 'Calculus & Analytical Geometry', 1, 'Evening', 'Theory', 3),
    ('AI-121', 'Discrete Mathematics', 1, 'Evening', 'Theory', 3),
    ('AI-101', 'AICT', 1, 'Evening', 'Theory', 2),
    ('AI-101L', 'AICT Lab', 1, 'Evening', 'Lab', 1),
    ('AI-133', 'Programming Fundamentals', 1, 'Evening', 'Theory', 3),
    ('AI-133L', 'Programming Fundamentals Lab', 1, 'Evening', 'Lab', 1)";
    $st = $dbo->conn->prepare($cmd1e);
    // executing statements
    $st->execute();
}
catch  (PDOException $e){
    echo "<br>DUPLICATE ENTRY<br>REASON:<br>" . $e->getMessage();
}


// INSERTING DATA  of 2nd Semester - Morning TO DATABASE course_details TABLE
try{

    $cmd2m = "INSERT INTO course_details 
    (course_code, course_title, semester, session, course_type, credit)
    VALUES
    ('HU-221', 'Technical Writing & Presentation Skills', 2, 'Morning', 'Theory', 2),
    ('MA-224', 'Multivariate Calculus', 2, 'Morning', 'Theory', 3),
    ('MA-234', 'Linear Algebra', 2, 'Morning', 'Theory', 3),
    ('AI-131', 'Software Engineering', 2, 'Morning', 'Theory', 3),
    ('AI-134', 'Object Oriented Programming', 2, 'Morning', 'Theory', 3),
    ('AI-134L', 'OOP Lab', 2, 'Morning', 'Lab', 1),
    ('PHY-118', 'Applied Physics', 2, 'Morning', 'Theory', 3),
    ('PHY-118L', 'Applied Physics Lab', 2, 'Morning', 'Lab', 1)";
    
    $st = $dbo->conn->prepare($cmd2m);
    // executing statements
    $st->execute();
}
catch (PDOException $e){
    echo "<br>DUPLICATE ENTRY<br>REASON:<br>" . $e->getMessage();
}



// INSERTING DATA  of 2nd Semester - Evening TO DATABSE  course_details TABLE
try{

    $cmd2e = "INSERT INTO course_details 
    (course_code, course_title, semester, session, course_type, credit)
    VALUES
    ('HU-221', 'Technical Writing & Presentation Skills', 2, 'Evening', 'Theory', 2),
    ('MA-224', 'Multivariate Calculus', 2, 'Evening', 'Theory', 3),
    ('MA-234', 'Linear Algebra', 2, 'Evening', 'Theory', 3),
    ('AI-131', 'Software Engineering', 2, 'Evening', 'Theory', 3),
    ('AI-134', 'Object Oriented Programming', 2, 'Evening', 'Theory', 3),
    ('AI-134L', 'OOP Lab', 2, 'Evening', 'Lab', 1),
    ('PHY-118', 'Applied Physics', 2, 'Evening', 'Theory', 3),
    ('PHY-118L', 'Applied Physics Lab', 2, 'Evening', 'Lab', 1)";
    $st = $dbo->conn->prepare($cmd2e);
    // executing statements
    $st->execute();
}
catch  (PDOException $e){
    echo "<br>DUPLICATE ENTRY<br>REASON:<br>" . $e->getMessage();
}


/*3.INSERTING DATA IN FACULTY DETAIL TABLE*/


// Multidimensional Indexed Array of faculty with username and full name
/*
$faculty_list
-> [0] → ['shumaila123', 'Ms. Shumaila']
-> [1] → ['fizza124', 'Ms. Fizza']
-> [2] → ['khalid125', 'Mr. Khalid Butt']
-> ...

Accessing values 
$faculty_list[0][0]; // shumaila123
$faculty_list[0][1]; // Ms. Shumaila

 */ 
$faculty_list = [
    // 1st Semester Morning
    ['shumaila123', 'Ms. Shumaila'],
    ['fizza124', 'Ms. Fizza'],
    ['khalid125', 'Mr. Khalid Butt'],
    ['arsalan126', 'Mr. Arsalan'],
    ['mehwish127', 'Dr. Mehwish'],
    ['umer128', 'Mr. Umer Shahid'],
    ['salman129', 'Mr. Salman TF'],
    ['khushbakht130', 'Ms. Khushbakht'],
    ['hafiz131', 'Hafiz Naeem'],

    // 1st Semester Evening
    ['fahad132', 'Mr. Fahad'],
    ['fizza133', 'Ms. Fizza'],
    ['khalid134', 'Mr. Khalid Butt'],
    ['adeem135', 'Dr. Adeem'],
    ['shahid136', 'Mr. Shahid'],
    ['mustafa137', 'Dr. Mustafa'],
    ['husna138', 'Ms. Husna'],
    ['mahnoor139', 'Ms. Mahnoor'],

    // 2nd Semester Morning/Evening
    ['irfan140', 'Dr. Irfan'],
    ['shabeer141', 'Dr. Shabeer'],
    ['maheen142', 'Ms. Maheen'],
    ['usman143', 'Mr. Usman Yousaf'],
    ['mahnoor144', 'Ms. Mahnoor Ijaz'],
    ['amber145', 'Ms. Amber'],
    ['laiba146', 'Ms. Laiba'],
    ['saqib147', 'Mr. Saqib']
];

// Function to generate strong random passwords is defined at top in time of putting data into student_detils table

/*
$faculty_list is an array of arrays, where each element represents a faculty member.
$faculty is one faculty member’s array in each iteration.
So this loop goes through every faculty member in $faculty_list one by one.*/


// Header for table which conatain username passwords for teachers
echo "<table border='1'><tr><th>Name</th><th>Username</th><th>Temporary Password</th></tr>";



foreach ($faculty_list as $faculty) {

    $username = $faculty[0];
    $fullname = $faculty[1];

    /*
    generateStrongPassword(12) generates a random 12-character password.
    password_hash($raw_password, PASSWORD_DEFAULT) hashes the password for secure storage in */
    $raw_password = generateStrongPassword(12);
    $password = password_hash($raw_password, PASSWORD_DEFAULT);
    $password = trim($password);



    // Enter data in into database
    try {
        $cmd = "INSERT INTO faculty_details (user_name, name, password)
        VALUES (:username, :fullname, :password)";
        // preparing statements 

        /*
        Malicious input could break  SQL and run unwanted commands.
        Example: If $username = "hacker', '123'); DROP TABLE users;--"
        That could delete your whole table.

        Using bindParam():
        PDO escapes the input automatically.
        Your database is safe from SQL injection attacks.
        */
        $st = $dbo->conn->prepare($cmd);
        $st->bindParam(':username', $username);
        $st->bindParam(':fullname', $fullname);
        $st->bindParam(':password', $password);
        $st->execute();

        // Printing in HTML table row by row
        echo "<tr><td>$fullname</td><td>$username</td><td>$raw_password</td></tr>";



        // WE should only show raw password once, because after hashing it, we cannot retrieve it from the database.

        echo "<br> Inserted $fullname with username: $username and password:. $password";

    }

    catch(PDOException $e) {
        echo "<br>Faculty data not inserted for $fullname. Reason: " . $e->getMessage();
    }

}

// closing table tag
echo "</table>";


/*echo "<br>All faculty records inserted successfully with strong random passwords!";*/


/*4.INSERTING DATA IN SESSION DETAILS TABLE*/

try {
    $cmd = "INSERT INTO session_details (year, term)
    VALUES
    (2025, 'Fall 2025 - 2nd Semester Morning'),
    (2025, 'Fall 2025 - 2nd Semester Evening'),
    (2026, 'Spring 2026 - 1st Semester Morning'),
    (2026, 'Spring 2026 - 1st Semester Evening'),
    (2026, 'Fall 2026 - 1st Semester Morning'),
    (2026, 'Fall 2026 - 1st Semester Evening')";

    $st = $dbo->conn->prepare($cmd);
    $st->execute();

} 
catch (PDOException $e) {
    echo "DUPLICATE ENTRY" . $e->getMessage();
}

/*5.INSERTING DATA IN course_registrations TABLE*/

// Clear old course registrations for 2nd semester students
clearTable($dbo, "course_registration");

// Prepare insert query once
$sql = "INSERT INTO course_registration 
        (student_id, course_id, session_id)
        VALUES (:sid, :cid, :sessid)";
$st = $dbo->conn->prepare($sql);

// Assume session_id 1 = 2nd semester Morning
$semester_session_id = 1;

// Courses for 2nd semester
$course_ids = [17,18,19,20,21,22,23,24]; // IDs of semester 2 courses


// Loop through 56 students OF SECTION B (1 - 56)
for ($student = 1; $student <= 56; $student++) {

    // Assign each course of the semester to this student
    foreach ($course_ids as $course_id) {
        try {
            $st->execute([
                ":sid" => $student,
                ":cid" => $course_id,
                ":sessid" => $semester_session_id
            ]);
        } catch (PDOException $e) {
            echo "<br>Error inserting course registration for student $student: " . $e->getMessage();
        }
    }
}


// Courses that Section B is registered in (2nd semester)
$sectionB_courses = [17,18,19,20,21,22,23,24];

// Suppose all courses in your system have IDs from 1 to 30
$all_courses = range(1, 30);

// Courses available for Section A (not in Section B)
$available_courses_for_A = array_diff($all_courses, $sectionB_courses);

// Loop through Section A students (57 - 111)
for ($student = 57; $student <= 111; $student++) {

    // Shuffle available courses
    $shuffled_courses = $available_courses_for_A;
    shuffle($shuffled_courses);

    // Decide how many courses this student should take (e.g., 4 to all)
    $num_courses = rand(4, count($shuffled_courses));

    // Take only the first $num_courses
    $assigned_courses = array_slice($shuffled_courses, 0, $num_courses);

    // Assign the selected courses to the student
    foreach ($assigned_courses as $course_id) {
        try {
            $st->execute([
                ":sid" => $student,
                ":cid" => $course_id,
                ":sessid" => $semester_session_id
            ]);
        } catch (PDOException $e) {
            echo "<br>Error inserting course registration for student $student: " . $e->getMessage();
        }
    }
}

echo "<br> All 2nd semester students registered with their courses successfully!";








/*6.INSERTING DATA IN course_allotment TABLE
We can change this with actual data later.... 

*/
/* 
   INSERT DATA INTO course_allotment (AUTO DISTRIBUTION)
   Each faculty gets 1–4 courses (NO DUPLICATES)
 */

clearTable($dbo, "course_allotment");

$sql = "INSERT INTO course_allotment 
        (faculty_id, course_id, session_id)
        VALUES (:fid, :cid, :sessid)";
$st = $dbo->conn->prepare($sql);

/* Session ID */
$session_id = 1;

/* Faculty IDs (1–25) */
$faculty_ids = range(1, 25);

/* Course IDs (1–24) */
$course_ids = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];

/* Shuffle courses so assignment is random */
shuffle($course_ids);

/* Track which course index we are on */
$courseIndex = 0;
$totalCourses = count($course_ids);

foreach ($faculty_ids as $faculty_id) {

    // Each faculty gets between 1 and 4 courses
    $courseCount = rand(1, 4);

    for ($i = 0; $i < $courseCount; $i++) {

        // Reset index if courses end
        if ($courseIndex >= $totalCourses) {
            $courseIndex = 0;
            shuffle($course_ids);
        }

        $course_id = $course_ids[$courseIndex];

        try {
            $st->execute([
                ":fid" => $faculty_id,
                ":cid" => $course_id,
                ":sessid" => $session_id
            ]);
        } catch (PDOException $e) {
            echo "<br>Error inserting allotment: " . $e->getMessage();
        }

        $courseIndex++;
    }
}

echo "<br><b>✔ Course allotment completed successfully!</b>";



// THE END
?>






