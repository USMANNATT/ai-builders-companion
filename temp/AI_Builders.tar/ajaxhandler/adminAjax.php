<?php
/*
 * adminAjax.php — AI Builders Admin AJAX Handler
 *
 * FIX APPLIED:
 *   ob_start() is called at the very top (line 1 of execution).
 *   This buffers ALL output, so any accidental whitespace, BOM
 *   characters, or PHP notices that appear before header() calls
 *   are captured and discarded rather than being sent to the
 *   browser as non-JSON text — which was causing jQuery to throw
 *   the "AJAX ERROR (pollForNewActivity): error /" in the console.
 */
ob_start();

session_start();

require_once(__DIR__ . "/../database/database.php");
require_once(__DIR__ . "/../database/adminDetails.php");

/* ---------------------------------------------------------
   Auth Guard
   Reject any request that does not have a valid admin session.
   Returns 403 so the JS polling backoff stops retrying.
---------------------------------------------------------- */
if (!isset($_SESSION['current_user']) || $_SESSION['role'] !== 'admin') {
    ob_end_clean(); /* Discard any buffered output */
    http_response_code(403);
    header("Content-Type: application/json");
    echo json_encode([
        "status"  => "ERROR",
        "message" => "Unauthorized"
    ]);
    exit;
}

$dbo = new Database();
$abo = new admin_details();

/* Determine which action is being requested */
$action = $_REQUEST['action'] ?? '';

/* ---------------------------------------------------------
   Route: downloadTodayActivity
   Streams today's activity log as a CSV file download.
   Must NOT set Content-Type: application/json.
---------------------------------------------------------- */
if ($action === "downloadTodayActivity") {
    try {
        $activities = $abo->getTodayActivity($dbo);

        /* Discard any buffered output so CSV headers go out cleanly */
        ob_end_clean();

        header("Content-Type: text/csv; charset=UTF-8");
        header("Content-Disposition: attachment; filename=today_activity_log.csv");
        header("Pragma: no-cache");
        header("Expires: 0");

        $output = fopen("php://output", "w");

        /* CSV column headings */
        fputcsv($output, [
            "ID",
            "User Name",
            "Role",
            "Module",
            "Action",
            "Status",
            "IP Address",
            "Country",
            "City",
            "Created At"
        ]);

        /* CSV data rows */
        foreach ($activities as $row) {
            fputcsv($output, [
                $row['id'],
                $row['user_name'],
                $row['role'],
                $row['module'],
                $row['action'],
                $row['status'],
                $row['ip_address'],
                $row['country'],
                $row['city'],
                $row['created_at']
            ]);
        }

        fclose($output);
        exit;

    } catch (Exception $e) {
        ob_end_clean();
        header("Content-Type: application/json");
        http_response_code(500);
        echo json_encode([
            "status"  => "ERROR",
            "message" => $e->getMessage()
        ]);
        exit;
    }
}

/*
 * All remaining actions return JSON.
 * Set the header now — ob_start() ensures nothing has been
 * sent yet even if an included file had trailing whitespace.
 */
ob_end_clean();
header("Content-Type: application/json");

/* ---------------------------------------------------------
   Route: getRecentActivity
   Returns the latest 10 activity log entries for initial load.
---------------------------------------------------------- */
if ($action === "getRecentActivity") {
    try {
        $activities = $abo->getRecentActivity($dbo, 10);
        echo json_encode([
            "status"     => "ALLOK",
            "activities" => $activities
        ]);
        exit;
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            "status"  => "ERROR",
            "message" => $e->getMessage()
        ]);
        exit;
    }
}

/* ---------------------------------------------------------
   Route: pollNewActivity
   Returns only entries newer than the supplied last_id.
   Used for the real-time live table updates.
---------------------------------------------------------- */
if ($action === "pollNewActivity") {

    $last_id = $_POST['last_id'] ?? 0;

    /* Validate: must be a non-negative integer */
    if (!is_numeric($last_id) || (int)$last_id < 0) {
        http_response_code(400);
        echo json_encode([
            "status"  => "ERROR",
            "message" => "Invalid last_id"
        ]);
        exit;
    }

    try {
        $new_activities = $abo->getNewActivitiesSince($dbo, (int) $last_id);
        echo json_encode([
            "status"         => "ALLOK",
            "new_activities" => $new_activities,
            "count"          => count($new_activities)
        ]);
        exit;
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            "status"  => "ERROR",
            "message" => $e->getMessage()
        ]);
        exit;
    }
}

/* ---------------------------------------------------------
   Fallback: Unknown / missing action
---------------------------------------------------------- */
http_response_code(400);
echo json_encode([
    "status"  => "ERROR",
    "message" => "Invalid action"
]);
exit;