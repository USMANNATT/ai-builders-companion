// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBrb0tgKopN9qlCB62lF4QKYBgcZEr0zLw",
  authDomain: "ai-builders-852aa.firebaseapp.com",
  projectId: "ai-builders-852aa",
  storageBucket: "ai-builders-852aa.firebasestorage.app",
  messagingSenderId: "216324469979",
  appId: "1:216324469979:web:c1c7edda2456cc3e8988fe",
  measurementId: "G-5F1K5E214L"
};
const VAPID_KEY = "BB9OUetojdTw7eREUPrIe4GfnjQrgSfrGF1Yxdai8DrASr40GUTdOpR4VvHP7Y6IJgy7ChtlYHi8_KyjfFzm7RI";

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-app.js";
import { getMessaging, getToken, onMessage } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-messaging.js";

const app = initializeApp(firebaseConfig);
const messaging = getMessaging(app);

async function initPushNotifications() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;
  try {
    const registration = await navigator.serviceWorker.register(
      '/AI_Builders/firebase-messaging-sw.js',
      { scope: '/AI_Builders/' }
    );

    console.log('SW registered:', registration);

    await navigator.serviceWorker.ready;

    const permission = await Notification.requestPermission();
    console.log('Permission:', permission);
    if (permission !== 'granted') return;

    const token = await getToken(messaging, {
      vapidKey: VAPID_KEY,
      serviceWorkerRegistration: registration
    });

    console.log('FCM Token:', token);
    if (token) await saveTokenToServer(token);

  } catch (error) {
    console.error('Push init error:', error);
  }
}

async function saveTokenToServer(token) {
  const savedToken = localStorage.getItem('fcm_token');
  if (savedToken === token) return;

  const response = await fetch('/AI_Builders/api/save_token.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      token: token,
      device_type: /Android/i.test(navigator.userAgent) ? 'android' : 'web',
      browser: navigator.userAgent.substring(0, 100)
    })
  });

  const data = await response.json();
  console.log('Save token response:', data);
  if (data.success) localStorage.setItem('fcm_token', token);
}
onMessage(messaging, (payload) => {
  const banner = document.createElement('div');
  banner.style.cssText = `position:fixed;top:20px;right:20px;z-index:9999;
    background:#1A56DB;color:white;padding:16px 20px;border-radius:8px;
    max-width:320px;box-shadow:0 4px 12px rgba(0,0,0,0.3);cursor:pointer`;
  banner.innerHTML = `<strong>${payload.notification.title}</strong>
    <p style="margin:4px 0 0;font-size:13px">${payload.notification.body}</p>`;
  if (payload.data?.url) banner.onclick = () => window.location.href = payload.data.url;
  document.body.appendChild(banner);
  setTimeout(() => banner.remove(), 5000);
});

// Fix: handle both cases - DOM ready or already loaded
if (document.body && document.body.dataset.userId) {
  initPushNotifications();
} else {
  document.addEventListener('DOMContentLoaded', () => {
    if (document.body.dataset.userId) initPushNotifications();
  });
}