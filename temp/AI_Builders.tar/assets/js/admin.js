/* =============================================================
   admin.js — Real-Time Activity Log Polling
   AI Builders Admin Dashboard
============================================================= */

/* ---------------------------------------------------------
   Polling State Tracker
   Prevents console spam by only logging the first network
   error, then silently backing off with longer intervals.
---------------------------------------------------------- */
var _pollTimer       = null;   // Reference to the current setInterval handle
var _pollFailCount   = 0;      // Number of consecutive poll failures
var _pollErrorLogged = false;  // True after the first failure is logged (no repeats)
var POLL_BASE_MS     = 5000;   // Normal polling interval: 5 seconds
var POLL_MAX_MS      = 60000;  // Backoff ceiling: 60 seconds


/* ---------------------------------------------------------
   Utility: Determine OS from User-Agent string
---------------------------------------------------------- */
function parseOS(userAgent) {
    if (!userAgent) return "Unknown";
    if (userAgent.includes("Windows"))                              return "Windows";
    if (userAgent.includes("Macintosh"))                            return "MAC";
    if (userAgent.includes("Android"))                              return "Android";
    if (userAgent.includes("iPhone") || userAgent.includes("iPad")) return "iOS";
    if (userAgent.includes("Linux"))                                return "Linux";
    return "Unknown";
}


/* ---------------------------------------------------------
   Utility: Build a status badge <span>
---------------------------------------------------------- */
function buildStatusBadge(status) {
    const s   = (status || "").toLowerCase();
    let   cls = "pending";

    if (s === "completed") cls = "success";
    if (s === "approved")  cls = "success";
    if (s === "failed")    cls = "failed";
    if (s === "pending")   cls = "pending";

    const span = $("<span>", { class: "status-badge " + cls });
    span.text(status || "Unknown");
    return span;
}


/* ---------------------------------------------------------
   Render: Full activity table body (initial load)
---------------------------------------------------------- */
function renderActivityTable(activities) {
    const tbody = $("#activity-tbody");
    tbody.empty();

    if (!Array.isArray(activities) || activities.length === 0) {
        tbody.append(
            $("<tr>").append(
                $("<td>", { colspan: 7, style: "text-align:center; color:#999;" })
                    .text("No activity found.")
            )
        );
        return;
    }

    activities.forEach(function (entry) {
        tbody.append(buildActivityRow(entry));
    });
}


/* ---------------------------------------------------------
   Render: Single activity row <tr>
---------------------------------------------------------- */
function buildActivityRow(entry) {
    const os = parseOS(entry.user_agent || "");
    const tr = $("<tr>", { "data-id": entry.id, class: "activity-row new-row" });

    tr.append($("<td>").text(entry.user_name  || "—"));
    tr.append($("<td>").text(entry.role       || "—"));
    tr.append($("<td>").text(entry.module     || "—"));
    tr.append($("<td>").text(entry.action     || "—"));
    tr.append($("<td>").text(os));
    tr.append($("<td>").text(entry.ip_address || "—"));
    tr.append($("<td>").append(buildStatusBadge(entry.status)));

    /* Remove the blue highlight animation after it finishes (2 s) */
    setTimeout(function () { tr.removeClass("new-row"); }, 2000);

    return tr;
}


/* ---------------------------------------------------------
   Prepend: New activity rows at the TOP of the table
---------------------------------------------------------- */
function prependNewRows(newActivities) {
    if (!Array.isArray(newActivities) || newActivities.length === 0) return;

    const tbody = $("#activity-tbody");

    /* Prepend in reverse so the newest entry always sits at the top */
    newActivities.slice().reverse().forEach(function (entry) {
        tbody.prepend(buildActivityRow(entry));
    });

    /* Keep the table capped at 10 visible rows */
    tbody.find("tr:gt(9)").remove();

    updateLiveIndicator();
}


/* ---------------------------------------------------------
   Live Indicator: Pulse the green dot when new data arrives
---------------------------------------------------------- */
function updateLiveIndicator() {
    const dot = $("#live-dot");
    dot.addClass("pulse");
    setTimeout(function () { dot.removeClass("pulse"); }, 1000);
}


/* =========================================================
   Polling Helpers: Stop / Start / Backoff
   ========================================================= */

/* Clear any active poll timer */
function stopPolling() {
    if (_pollTimer !== null) {
        clearInterval(_pollTimer);
        _pollTimer = null;
    }
}

/* (Re)start polling at the given interval in milliseconds */
function startPolling(intervalMs) {
    stopPolling();
    _pollTimer = setInterval(pollForNewActivity, intervalMs || POLL_BASE_MS);
}

/* Called after a clean successful poll — resets backoff to normal speed */
function onPollSuccess() {
    if (_pollFailCount > 0) {
        _pollFailCount   = 0;
        _pollErrorLogged = false;
        startPolling(POLL_BASE_MS); /* Restore normal 5-second interval */
    }
}

/*
 * Called after any poll failure.
 *
 * Rules:
 *  - Auth failures (401 / 403): stop polling permanently, log once.
 *  - Network / server errors:   log ONCE, then silently apply
 *    exponential backoff (5s → 10s → 20s → 40s → 60s cap).
 *
 * This completely eliminates the repeated red console errors.
 */
function onPollFailure(httpStatus) {
    _pollFailCount++;

    /* Auth failure — session expired, no point retrying */
    if (httpStatus === 401 || httpStatus === 403) {
        if (!_pollErrorLogged) {
            console.warn("[AI Builders] Session expired — activity polling stopped.");
            _pollErrorLogged = true;
        }
        stopPolling();
        return;
    }

    /* Log only the FIRST network/server error — never repeat it */
    if (!_pollErrorLogged) {
        console.warn(
            "[AI Builders] Activity poll failed (HTTP " +
            (httpStatus || "network error") +
            "). Retrying with backoff — no further errors will be logged."
        );
        _pollErrorLogged = true;
    }

    /* Exponential backoff, capped at POLL_MAX_MS */
    const nextMs = Math.min(
        POLL_BASE_MS * Math.pow(2, _pollFailCount - 1),
        POLL_MAX_MS
    );
    startPolling(nextMs);
}


/* =========================================================
   Core: Initial Load of Activity Log
   ========================================================= */
function loadInitialActivity() {
    $.ajax({
        url:      "/AI_Builders/ajaxhandler/adminAjax.php",
        type:     "POST",
        dataType: "json",
        data:     { action: "getRecentActivity" },

        success: function (response) {
            if (response && response.status === "ALLOK") {
                renderActivityTable(response.activities);

                /* Record the highest ID seen so polling fetches only newer rows */
                if (Array.isArray(response.activities) && response.activities.length > 0) {
                    const maxId = Math.max.apply(
                        null,
                        response.activities.map(function (a) { return parseInt(a.id, 10); })
                    );
                    $("#last-activity-id").val(maxId);
                }
            } else {
                /* PHP returned an error status — warn once, do not crash */
                console.warn(
                    "[AI Builders] getRecentActivity error:",
                    (response && response.message) ? response.message : "Unknown"
                );
            }
        },

        error: function (xhr, status) {
            /* Log once — polling will still start normally below */
            console.warn(
                "[AI Builders] Could not load initial activity (HTTP " +
                (xhr.status || status) + ")."
            );
        }
    });
}


/* =========================================================
   Core: Poll for New Activity (called on interval)
   ========================================================= */
function pollForNewActivity() {
    const lastId = parseInt($("#last-activity-id").val(), 10) || 0;

    $.ajax({
        url:      "/AI_Builders/ajaxhandler/adminAjax.php",
        type:     "POST",
        dataType: "json",
        data: {
            action:  "pollNewActivity",
            last_id: lastId
        },

        success: function (response) {
            /* Guard: ignore malformed or error responses silently */
            if (!response || response.status !== "ALLOK") {
                return;
            }

            onPollSuccess(); /* Reset backoff counter on clean response */

            if (response.count > 0) {
                const newMaxId = Math.max.apply(
                    null,
                    response.new_activities.map(function (a) { return parseInt(a.id, 10); })
                );
                $("#last-activity-id").val(newMaxId);
                prependNewRows(response.new_activities);
            }
        },

        /*
         * ALL network / HTTP errors come here.
         * We delegate entirely to onPollFailure() which:
         *  - logs only once
         *  - applies exponential backoff
         * This is what eliminates the repeated red console errors.
         */
        error: function (xhr) {
            onPollFailure(xhr.status);
        }
    });
}


/* =========================================================
   Download: Today's Activity Log as CSV
   =========================================================
   FIX: The original used window.location.href which caused
   the browser to navigate away, killing active AJAX timers
   and sometimes failing silently on servers that set strict
   Content-Disposition headers.

   Solution: inject a hidden <a download> element, click it
   programmatically, then remove it immediately. This triggers
   the file download without affecting window.location or
   stopping any running poll timers.
   ========================================================= */
function downloadTodayActivity() {
    const link    = document.createElement("a");
    link.href     = "/AI_Builders/ajaxhandler/adminAjax.php?action=downloadTodayActivity";
    link.download = "today_activity_log.csv"; /* Browser filename suggestion */
    link.style.display = "none";

    document.body.appendChild(link);
    link.click(); /* Triggers the download */

    /* Remove the temporary element after the browser processes the click */
    setTimeout(function () {
        if (link.parentNode) {
            document.body.removeChild(link);
        }
    }, 300);
}


/* =========================================================
   jQuery Document Ready — Entry Point
   ========================================================= */
$(document).ready(function () {

    /* 1. Load the existing activity log immediately on page load */
    loadInitialActivity();

    /* 2. Begin real-time polling at the base 5-second interval */
    startPolling(POLL_BASE_MS);

    /* 3. Wire up the "Download Today's Activity Log" button */
    $("#btnDownloadToday").on("click", function () {
        downloadTodayActivity();
    });

});
