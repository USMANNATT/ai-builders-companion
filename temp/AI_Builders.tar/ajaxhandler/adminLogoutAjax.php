<?php
session_start();

header("Content-Type: application/json");

$action = $_POST['action'] ?? '';

if ($action === 'adminLogout') {

    // Verify this is actually an admin session before destroying
    if (!isset($_SESSION['current_user']) || $_SESSION['role'] !== 'admin') {
        echo json_encode([
            "status"  => "ERROR",
            "message" => "No active admin session"
        ]);
        exit;
    }

    // Destroy session completely
    session_unset();
    session_destroy();

    echo json_encode([
        "status"  => "ALLOK",
        "message" => "Logged out successfully"
    ]);
    exit;
}

echo json_encode([
    "status"  => "ERROR",
    "message" => "Invalid action"
]);
exit;
?>
