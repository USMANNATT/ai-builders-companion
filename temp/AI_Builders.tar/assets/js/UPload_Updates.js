$(document).ready(function () {

    function logActivityJS(module, action, status, role) {
        $.ajax({
            url: '/AI_Builders/ajaxhandler/log_activity_ajax.php',
            type: 'POST',
            data: { module, action, status, role },
            success: function (res) { console.log('Activity Logged:', res); },
            error:   function (err) { console.error('Activity Logging Failed:', err); }
        });
    }

    const facid = $("#hiddenFacultyId").val();

    $.ajax({
        url:      '/AI_Builders/ajaxhandler/resourceAJAX.php',
        type:     'POST',
        dataType: 'json',
        data:     { action: 'getCourses', facid: facid },
        success: function (rv) {
            let x = '<option value="">Select Course</option>';
            rv.forEach(course => {
                x += `<option value="${course.id}">${course.course_code} - ${course.course_title}</option>`;
            });
            $("#courseId").html(x);
            logActivityJS('Course Updates Page', 'Fetched Courses for Faculty', 'Completed', 'Faculty');
        },
        error: function (e) {
            alert('Error fetching courses');
            console.error(e);
        }
    });

    const dateField = `
        <div class="form-group">
            <label>Date</label>
            <input type="text" id="currentDate" readonly>
        </div>`;
    const timeField = `
        <div class="form-group">
            <label>Current Time</label>
            <input type="text" id="currentTime" readonly>
        </div>`;
    $("#dateTimeContainer").append(dateField, timeField);

    function updateDate() {
        const months = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
        const now = new Date();
        $("#currentDate").val(
            now.getDate().toString().padStart(2, '0') + ' ' +
            months[now.getMonth()] + ' ' +
            now.getFullYear()
        );
    }
    function updateTime() {
        const now = new Date();
        $("#currentTime").val(
            now.getHours().toString().padStart(2, '0')   + ':' +
            now.getMinutes().toString().padStart(2, '0') + ':' +
            now.getSeconds().toString().padStart(2, '0')
        );
    }
    updateDate();
    updateTime();
    setInterval(updateTime, 1000);

    const previewTag  = $(".preview-card .tag");
    const previewDate = $(".preview-card .date");
    const previewText = $(".preview-card p");

    $("#updateType").on("change", function () {
        previewTag.text($(this).val().toUpperCase());
    });
    $(document).on("input", "#currentDate", function () {
        previewDate.text($(this).val());
    });
    $("textarea").on("input", function () {
        const text = $(this).val().trim();
        previewText.text(text !== "" ? text : "Your update preview will appear here...");
    });
    $("#courseId").on("change", function () {
        $(".preview-card h2").text("Preview — " + $(this).find("option:selected").text());
    });

    $("#updateType").trigger("change");
    $("textarea").trigger("input");

    const publishBtn = $(".form-card button");

    publishBtn.on("click", function () {

        const course_id   = $("#courseId").val();
        const update_type = $("#updateType").val();
        const message     = $("textarea").val().trim();
        const dateText    = $("#currentDate").val();
        const timeText    = $("#currentTime").val();
        const faculty_id  = $("#hiddenFacultyId").val();

        if (!course_id || !update_type || !message) {
            alert("Please fill all required fields");
            return;
        }

        publishBtn.prop("disabled", true).text("Publishing…");

        $.ajax({
            url:      '/AI_Builders/ajaxhandler/upload_updatesAjax.php',
            type:     'POST',
            dataType: 'json',
            timeout:  60000,   // ✅ 60 second timeout — won't error prematurely
            data: {
                action:         'saveUpdate',
                course_id:      course_id,
                faculty_id:     faculty_id,
                update_type:    update_type,
                update_message: message,
                update_date:    dateText,
                update_time:    timeText
            },
            success: function (response) {
                publishBtn.prop("disabled", false).text("Publish");

                if (response && response.status === "success") {
                    alert("✅ Update published!\n📧 Emails & 🔔 Push notifications are being sent to students.");
                    $("textarea").val("").trigger("input");
                    logActivityJS(
                        "Course Update Page",
                        `Published "${update_type}" update for course ID ${course_id}.`,
                        "Completed",
                        "Faculty"
                    );
                } else {
                    alert("Failed to publish: " + (response?.error ?? "Unknown error"));
                    logActivityJS("Course Update Page", `Failed to publish "${update_type}"`, "Failed", "Faculty");
                }
            },
            error: function (xhr, status, error) {
                publishBtn.prop("disabled", false).text("Publish");

                // If it's just a timeout but DB insert likely worked, show partial success
                if (status === 'timeout') {
                    alert("⚠️ Update was saved but notifications may still be processing. Please check the portal.");
                    $("textarea").val("").trigger("input");
                } else {
                    console.error("AJAX error:", status, error, xhr.responseText);
                    alert("An error occurred while saving the update.");
                }

                logActivityJS("Course Update Page", `AJAX ${status} for "${update_type}" course ID ${course_id}`, "Failed", "Faculty");
            }
        });
    });
});