<?php
/**
 * debug_resources.php  — TEMPORARY DEBUG FILE
 * Place in /AI_Builders/ajaxhandler/
 * Visit: yourdomain.com/AI_Builders/ajaxhandler/debug_resources.php?fid=YOUR_FACULTY_ID
 * DELETE after debugging.
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

$base = dirname(__DIR__);

// Load exactly what resourceAJAX.php loads
require_once $base . '/database/database.php';

echo "<pre style='font-size:14px;padding:20px;background:#f8f8f8;'>";
echo "=== STEP 1: Constants ===\n";
foreach (['DB_HOST','DB_NAME','DB_USER','DB_CHARSET'] as $c) {
    echo "$c = " . (defined($c) ? constant($c) : 'NOT DEFINED') . "\n";
}

echo "\n=== STEP 2: Database class inspection ===\n";
if (!class_exists('Database')) {
    echo "ERROR: Database class not found after requiring database.php\n";
    echo "Trying config path...\n";
    $configPath = $base . '/config/database.php';
    if (file_exists($configPath)) {
        require_once $configPath;
        echo "Loaded from config/database.php\n";
    } else {
        echo "config/database.php also not found. Check paths.\n";
        echo "</pre>"; exit;
    }
}

$ref = new ReflectionClass('Database');
echo "File: " . $ref->getFileName() . "\n";

// Public methods
$methods = array_map(fn($m) => $m->getName(), $ref->getMethods(ReflectionMethod::IS_PUBLIC));
echo "Public methods: " . implode(', ', $methods) . "\n";

// Public properties
$props = array_map(fn($p) => $p->getName(), $ref->getProperties(ReflectionProperty::IS_PUBLIC));
echo "Public properties: " . (count($props) ? implode(', ', $props) : '(none)') . "\n";

// Protected/private properties (may hold PDO)
$allProps = $ref->getProperties();
$allPropNames = array_map(fn($p) => $p->getName(), $allProps);
echo "All properties: " . implode(', ', $allPropNames) . "\n";

echo "\n=== STEP 3: Instantiate and inspect ===\n";
$dbo = new Database();
echo "Database instantiated OK\n";

// Check for PDO in public properties
$foundPDO = false;
foreach ($ref->getProperties() as $prop) {
    $prop->setAccessible(true);
    $val = $prop->getValue($dbo);
    if ($val instanceof PDO) {
        echo "Found PDO in property: \$dbo->" . $prop->getName() . "\n";
        $foundPDO = true;
    } else {
        echo "Property \$" . $prop->getName() . " = " . gettype($val) . "\n";
    }
}

echo "\n=== STEP 4: Try each common method to get PDO ===\n";
$pdo = null;
foreach (['getConnection','getPDO','getDB','connect','getInstance','getLink','db','conn'] as $m) {
    if (method_exists($dbo, $m)) {
        try {
            $result = $dbo->$m();
            if ($result instanceof PDO) {
                echo "SUCCESS: \$dbo->$m() returned PDO!\n";
                $pdo = $result;
                break;
            } else {
                echo "\$dbo->$m() returned: " . gettype($result) . "\n";
            }
        } catch (Throwable $e) {
            echo "\$dbo->$m() threw: " . $e->getMessage() . "\n";
        }
    }
}

if (!$pdo && function_exists('getDB')) {
    try {
        $pdo = getDB();
        if ($pdo instanceof PDO) echo "SUCCESS: getDB() function returned PDO!\n";
    } catch(Throwable $e) {
        echo "getDB() threw: " . $e->getMessage() . "\n";
    }
}

if (!$pdo) {
    echo "Could not get PDO from any known method. Trying direct connection with constants...\n";
    try {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        echo "Direct PDO connection SUCCESS\n";
    } catch(Throwable $e) {
        echo "Direct PDO FAILED: " . $e->getMessage() . "\n";
        echo "</pre>"; exit;
    }
}

echo "\n=== STEP 5: Run the query ===\n";
$fid = (int)($_GET['fid'] ?? 0);
echo "Using faculty_id = $fid (pass ?fid=X in URL)\n\n";

if ($fid === 0) {
    echo "Add ?fid=YOUR_FACULTY_ID to the URL!\n";
    echo "</pre>"; exit;
}

// Check what tables exist
$tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
echo "Tables in DB: " . implode(', ', $tables) . "\n\n";

// Try the query
try {
    $stmt = $pdo->prepare("
        SELECT cr.resource_id, cr.course_id, cr.resource_type, cr.title,
               cr.uploaded_at, cd.course_code, cd.course_title
        FROM course_resources cr
        JOIN course_details cd ON cr.course_id = cd.id
        WHERE cr.faculty_id = :fid
        LIMIT 3
    ");
    $stmt->execute([':fid' => $fid]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "Query OK. Rows found: " . count($rows) . "\n";
    if ($rows) print_r($rows[0]);
    else echo "No data for this faculty_id.\n";
} catch(Throwable $e) {
    echo "Query FAILED: " . $e->getMessage() . "\n";
}

echo "\n=== END ===\n</pre>";
