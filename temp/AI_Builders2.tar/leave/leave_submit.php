<?php
// CHECK IF THE USER IS ACCESSING THE PAGE DIRECTLY OR USING USER NAME AND PASSWORD
session_start();

if (isset($_SESSION["current_user"])) {
    $stid = $_SESSION["current_user"];
} else {
    header("Location:" . "/AI_Builders/login.php");
    die();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Builders - Leave Portal</title>

    <!-- ================== FAVICONS ================== -->
    <link rel="apple-touch-icon" sizes="180x180" href="/AI_Builders/assets/favicon_io/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/AI_Builders/assets/favicon_io/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/AI_Builders/assets/favicon_io/favicon-16x16.png">
    <link rel="icon" href="/AI_Builders/assets/favicon_io/favicon.ico">
    <link rel="manifest" href="/AI_Builders/assets/favicon_io/site.webmanifest">

    <!-- ================== STYLES ================== -->
    <link rel="stylesheet" href="/AI_Builders/assets/css/Leave.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>

<!-- Hidden student ID passed to JS -->
<input type="hidden" id="studentSessionId" value="<?= htmlspecialchars($stid) ?>">

<input type="hidden" id="userRole" value="Student">

<!-- ================== MAIN CONTAINER ================== -->
<div class="form-container">

    <!-- ================== HEADER SECTION ================== -->
    <header>
        <div class="logo">🏛️</div>
        <h1>UET Leave Application</h1>
        <p>Submit your leave request below.</p>
    </header>

    <!-- ================== LEAVE APPLICATION FORM ================== -->
    <form id="leaveForm" method="post" enctype="multipart/form-data">

        <!-- ================== SECTION 1: STUDENT INFORMATION ================== -->
        <div class="form-section">
            <h3><span class="step">1</span> Student Information</h3>

            <div class="row">
                <div class="input-group">
                    <label for="studentName">Full Name</label>
                    <input type="text" id="studentName" name="studentName"
                           placeholder="Loading..." readonly required>
                </div>
                <div class="input-group">
                    <label for="rollNumber">Roll Number</label>
                    <input type="text" id="rollNumber" name="rollNumber"
                           placeholder="Loading..." readonly required>
                </div>
            </div>
        </div>

        <!-- ================== SECTION 2: SUBJECT SELECTION ================== -->
        <div class="form-section">
            <h3><span class="step">2</span> Select Subject(s)</h3>
            <p class="section-hint">Click on one or more subjects to apply leave for them.</p>

            <!-- Subject cards will be injected here by JS -->
            <div id="subjectCardsContainer" class="subject-cards-grid">
                <div class="loading-pulse">
                    <div class="pulse-bar"></div>
                    <div class="pulse-bar short"></div>
                    <div class="pulse-bar"></div>
                </div>
            </div>

            <!-- Selected count badge -->
            <div id="selectedCountBadge" class="selected-count-badge hidden">
                <span id="selectedCountText">0 subject(s) selected</span>
            </div>

            <!-- Teacher display panel: appears when subjects are selected -->
            <div id="teacherPanel" class="teacher-panel hidden">
                <h4>📋 Concerned Teachers</h4>
                <div id="teacherCardsContainer" class="teacher-cards-grid"></div>
            </div>
        </div>

        <!-- ================== SECTION 3: LEAVE DETAILS ================== -->
        <div class="form-section">
            <h3><span class="step">3</span> Leave Details</h3>

            <div class="row">
                <div class="input-group">
                    <label for="leaveReason">Reason for Leave</label>
                    <select id="leaveReason" name="leaveReason" required>
                        <option value="" disabled selected>Select reason</option>
                        <option value="Medical">Medical</option>
                        <option value="Personal">Personal</option>
                        <option value="Official">Official</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="input-group">
                    <label for="hospitalName">Hospital Name <small>(If Medical)</small></label>
                    <input type="text" id="hospitalName" name="hospitalName"
                           placeholder="e.g. Shifa International">
                </div>
            </div>

            <div class="row">
                <div class="input-group">
                    <label for="startDate">Start Date</label>
                    <input type="date" id="startDate" name="startDate" required>
                </div>
                <div class="input-group">
                    <label for="endDate">End Date</label>
                    <input type="date" id="endDate" name="endDate" required>
                </div>
            </div>

            <div class="days-display" id="totalDays">Total Days: 0</div>
        </div>

        <!-- ================== SECTION 4: DOCUMENTATION ================== -->
        <div class="form-section">
            <h3><span class="step">4</span> Documentation</h3>

            <div class="input-group">
                <label for="fileAttachment">Attach Evidence <small>(Optional)</small></label>
                <input type="file" id="fileAttachment" name="fileAttachment"
                       class="file-input" accept=".pdf,.jpg,.jpeg,.png">
                <small class="file-hint">
                    • Medical leave: Upload hospital slip or report<br>
                    • Official leave: Upload approval document<br>
                    • Allowed formats: PDF, JPG, PNG (Max 2MB)
                </small>
            </div>

            <div class="input-group" style="margin-top:15px;">
                <label for="description">Detailed Reason</label>
                <textarea id="description" name="description" rows="4"
                          placeholder="Explain the reason for your leave..."></textarea>
            </div>
        </div>

        <!-- ================== FORM ACTION BUTTONS ================== -->
        <div class="form-actions">
            <button type="button" class="btn-secondary" onclick="window.print()">Print Draft</button>
            <button type="submit" class="btn-primary">Submit Application</button>
        </div>

        <!-- ================== STATUS BADGE ================== -->
        <div id="statusMessage" class="status-badge hidden">
            Status: Pending Review
        </div>

    </form>
</div>

<script src="/AI_Builders/assets/js/jquery.js"></script>
<script src="/AI_Builders/assets/js/leavesssss.js"></script>
</body>
</html>
