<?php
/**
 * debug_email_lookup.php
 * ─────────────────────────────────────────────────────────────
 * DROP in: /AI_Builders/ajaxhandler/debug_email_lookup.php
 * Visit:   https://aibuilderss.com/AI_Builders/ajaxhandler/debug_email_lookup.php
 * DELETE after debugging.
 * ─────────────────────────────────────────────────────────────
 */

ob_start();
header('Content-Type: application/json');

$base = dirname(__DIR__);
require_once $base . '/vendor/autoload.php';
require_once $base . '/database/database.php';

$dbo     = new Database();
$results = [];

// ── 1. Show first 5 rows of student_details ──────────────────
try {
    $stmt = $dbo->conn->prepare("
        SELECT id, roll_no, name, email
        FROM   student_details
        LIMIT  5
    ");
    $stmt->execute();
    $results['student_details_sample'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $results['student_details_error'] = $e->getMessage();
}

// ── 2. Show all columns of student_details ───────────────────
try {
    $stmt = $dbo->conn->prepare("DESCRIBE student_details");
    $stmt->execute();
    $results['student_details_columns'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $results['describe_error'] = $e->getMessage();
}

// ── 3. Show first 5 rows of course_registration ──────────────
try {
    $stmt = $dbo->conn->prepare("
        SELECT *
        FROM   course_registration
        LIMIT  5
    ");
    $stmt->execute();
    $results['course_registration_sample'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $results['course_registration_error'] = $e->getMessage();
}

// ── 4. Show all columns of course_registration ───────────────
try {
    $stmt = $dbo->conn->prepare("DESCRIBE course_registration");
    $stmt->execute();
    $results['course_registration_columns'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $results['describe_cr_error'] = $e->getMessage();
}

// ── 5. Show first 5 rows of results/exam table ───────────────
try {
    $stmt = $dbo->conn->prepare("SHOW TABLES");
    $stmt->execute();
    $results['all_tables'] = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $results['tables_error'] = $e->getMessage();
}

ob_end_clean();
echo json_encode($results, JSON_PRETTY_PRINT);