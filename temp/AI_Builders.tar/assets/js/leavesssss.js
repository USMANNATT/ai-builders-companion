// ======================================================
// 🔹 ACTIVITY LOGGER FUNCTION
// ======================================================
function logActivityJS(module, action, status, role) {
    $.ajax({
        url: '/AI_Builders/ajaxhandler/log_activity_ajax.php',
        type: 'POST',
        data: { module, action, status, role },
        success: function(res) { console.log('Activity Logged:', res); },
        error:   function(err) { console.error('Activity Logging Failed:', err); }
    });
}

// ======================================================
// 🔹 SECURITY: ESCAPE HTML
// ======================================================
function escapeHTML(text) {
    if (!text) return '';
    return text.toString()
        .replace(/&/g, "&amp;")
        .replace(/</g,  "&lt;")
        .replace(/>/g,  "&gt;")
        .replace(/"/g,  "&quot;")
        .replace(/'/g,  "&#039;");
}

// ======================================================
// 🔹 FACULTY LEAVE STATUS UPDATE (Faculty dashboard)
// ======================================================
function updateLeaveStatus(leaveId, status) {
    if (!confirm("Are you sure you want to " + status + " this leave?")) return;

    $.ajax({
        url: "../ajaxhandler/update_leave_status_Ajax.php",
        type: "POST",
        data: { leave_id: leaveId, status: status },
        dataType: "json",
        success: function(data) {
            if (data.success) {
                logActivityJS("Display Leaves", "Faculty " + status + " leave ID " + leaveId, "Completed", "Faculty");
                if (data.attendance_skipped && data.attendance_skipped.length > 0) {
                    alert("✅ " + data.message + "\n\nAttendance marked for: " +
                          (data.attendance_marked || []).join(", ") +
                          "\nSkipped days (no class or error): " + data.attendance_skipped.join(", "));
                } else {
                    alert("✅ " + data.message);
                }
                location.reload();
            } else {
                logActivityJS("Display Leaves", "Faculty failed to " + status + " leave ID " + leaveId, "Failed", "Faculty");
                alert("❌ Error: " + data.message);
            }
        },
        error: function(xhr, statusText, error) {
            logActivityJS("Display Leaves", "AJAX error while " + status + " leave ID " + leaveId, "Failed", "Faculty");
            alert("⚠ SERVER ERROR\n\nStatus: " + statusText + "\nError: " + error + "\nResponse:\n" + xhr.responseText);
        }
    });
}

// ======================================================
// 🔹 GENERATE LEAVE TABLE HTML (Faculty dashboard)
// ======================================================
function leavesHTML(data) {
    let x = `<table>
        <tr>
            <th>Student Name</th><th>Roll No</th><th>Course</th>
            <th>Leave Reason</th><th>Start</th><th>End</th>
            <th>Total Days</th><th>Hospital</th><th>Description</th>
            <th>Attachment</th><th>Status</th><th>Applied At</th>
        </tr>`;

    data.forEach(row => {
        x += `<tr>
            <td>${escapeHTML(row.name)}</td>
            <td>${escapeHTML(row.roll_no)}</td>
            <td>${escapeHTML(row.course_title)} (${row.course_code})</td>
            <td>${escapeHTML(row.leave_reason)}</td>
            <td>${row.start_date}</td><td>${row.end_date}</td>
            <td>${row.total_days}</td>
            <td>${row.hospital_name ? escapeHTML(row.hospital_name) : '-'}</td>
            <td>${escapeHTML(row.description)}</td>
            <td>${row.attachment ? `<a href="../uploads/${row.attachment}" target="_blank">View</a>` : 'No File'}</td>
            <td>`;

        if (row.status === 'pending') {
            x += `<button class="approve-btn" onclick="updateLeaveStatus(${row.leave_id}, 'approved')">Approve</button>
                  <button class="reject-btn"  onclick="updateLeaveStatus(${row.leave_id}, 'rejected')">Reject</button>`;
        } else {
            x += `<span class="status ${row.status}">${row.status.charAt(0).toUpperCase() + row.status.slice(1)}</span>`;
        }

        x += `</td><td>${row.applied_at}</td></tr>`;
    });

    x += `</table>`;
    return x;
}

// ======================================================
// 🔹 MAIN JQUERY
// ======================================================
$(function () {
    
        // ─────────────────────────────────────────────────────────
    // 7. FACULTY LEAVE VIEW (if on faculty page)
    // ─────────────────────────────────────────────────────────
    const facid = $("#hiddenFacId").val();
    if (facid) {
        $.ajax({
            url: "/AI_Builders/ajaxhandler/LeaveAjax.php",
            type: "POST",
            data: { facid: facid, action: "getleaveDetails" },
            dataType: "json",
            success: function(data) {

                document.getElementById("leaveDetails").innerHTML = leavesHTML(data);
          
            },
            error: function(xhr, statusText, error) {
                console.error("AJAX Error: ", statusText, error, xhr.responseText);

            }
        });
    }

    const studentSessionId = $("#studentSessionId").val();

    if (!studentSessionId) return;

    // ─────────────────────────────────────────────────────────
    // 1. FETCH STUDENT DETAILS (name + roll number read-only)
    // ─────────────────────────────────────────────────────────
    $.ajax({
        url: "/AI_Builders/ajaxhandler/LeaveAjax.php",
        type: "POST",
        data: { action: "getStudentInfo", studentId: studentSessionId },
        dataType: "json",
        success: function(data) {

            if (data && data.name && data.roll_no) {
                $("#studentName").val(data.name);
                $("#rollNumber").val(data.roll_no);
            }
        },
        error: function(xhr) {
            console.error("Failed to fetch student info:", xhr.responseText);
        }
    });

    // ─────────────────────────────────────────────────────────
    // 2. FETCH REGISTERED SUBJECTS FOR THIS STUDENT
    // ─────────────────────────────────────────────────────────
    $.ajax({
        url: "/AI_Builders/ajaxhandler/LeaveAjax.php",
        type: "POST",
        data: { action: "getStudentSubjects", studentId: studentSessionId },
        dataType: "json",
        success: function(subjects) {
            renderSubjectCards(subjects);
        },
        error: function(xhr) {
            console.error("Failed to fetch subjects:", xhr.responseText);
            $("#subjectCardsContainer").html('<p class="error-msg">Could not load subjects. Please refresh.</p>');
        }
    });

    // ─────────────────────────────────────────────────────────
    // 3. RENDER SUBJECT CARDS
    // ─────────────────────────────────────────────────────────
    function renderSubjectCards(subjects) {
        const container = $("#subjectCardsContainer");
        container.empty();

        if (!subjects || subjects.length === 0) {
            container.html('<p class="error-msg">No registered subjects found.</p>');
            return;
        }

        subjects.forEach(function(subj) {
            const card = $(`
                <div class="subject-card"
                     data-course-id="${escapeHTML(String(subj.course_id))}"
                     data-course-code="${escapeHTML(subj.course_code)}"
                     data-course-title="${escapeHTML(subj.course_title)}"
                     data-teacher-id="${escapeHTML(String(subj.teacher_id || ''))}"
                     data-teacher-name="${escapeHTML(subj.teacher_name || 'N/A')}">
                    <div class="subject-card-check">
                        <span class="check-icon">✓</span>
                    </div>
                    <div class="subject-card-body">
                        <span class="subject-code">${escapeHTML(subj.course_code)}</span>
                        <span class="subject-title">${escapeHTML(subj.course_title)}</span>
                    </div>
                </div>
            `);

            card.on("click", function() {
                $(this).toggleClass("selected");
                updateSelectedState();
            });

            container.append(card);
        });

        $("#selectedCountBadge").removeClass("hidden");
        updateSelectedState();
    }

    // ─────────────────────────────────────────────────────────
    // 4. UPDATE SELECTED COUNT + TEACHER PANEL
    // ─────────────────────────────────────────────────────────
    function updateSelectedState() {
        const selected = $(".subject-card.selected");
        const count    = selected.length;

        $("#selectedCountText").text(count + " subject" + (count !== 1 ? "s" : "") + " selected");

        if (count === 0) {
            $("#teacherPanel").addClass("hidden");
            return;
        }

        const teacherPanel = $("#teacherCardsContainer");
        teacherPanel.empty();

        const seenTeachers = {};

        selected.each(function() {
            const teacherId   = $(this).data("teacher-id");
            const teacherName = $(this).data("teacher-name");
            const code        = $(this).data("course-code");
            const title       = $(this).data("course-title");

            if (!seenTeachers[teacherId]) {
                seenTeachers[teacherId] = { name: teacherName, courses: [] };
            }
            seenTeachers[teacherId].courses.push(code + " – " + title);
        });

        Object.values(seenTeachers).forEach(function(t) {
            const tc = $(`
                <div class="teacher-card">
                    <div class="teacher-avatar">${escapeHTML(t.name.charAt(0).toUpperCase())}</div>
                    <div class="teacher-info">
                        <span class="teacher-name">${escapeHTML(t.name)}</span>
                        <span class="teacher-courses">${t.courses.map(c => escapeHTML(c)).join('<br>')}</span>
                    </div>
                </div>
            `);
            teacherPanel.append(tc);
        });

        $("#teacherPanel").removeClass("hidden");
    }

    // ─────────────────────────────────────────────────────────
    // 5. DATE CALCULATION
    // ─────────────────────────────────────────────────────────
    function calculateTotalDays() {
        const startDate = new Date($('#startDate').val());
        const endDate   = new Date($('#endDate').val());
        if (startDate && endDate && endDate >= startDate) {
            const diffDays = Math.floor((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1;
            $('#totalDays').text(`Total Days: ${diffDays}`);
        } else {
            $('#totalDays').text('Total Days: 0');
        }
    }

    $('#startDate, #endDate').on('change', calculateTotalDays);

    // ─────────────────────────────────────────────────────────
    // 6. FORM SUBMISSION
    // ─────────────────────────────────────────────────────────
    $("#leaveForm").on("submit", function(e) {
        e.preventDefault();

        const selectedCourseIds = [];
        $(".subject-card.selected").each(function() {
            selectedCourseIds.push($(this).data("course-id"));
        });

        if (selectedCourseIds.length === 0) {
            alert("Please select at least one subject before submitting.");
            return;
        }

        let formData = new FormData(this);
        formData.append("action", "submitLeave");
        formData.append("selectedCourseIds", JSON.stringify(selectedCourseIds));

        $.ajax({
            url: "/AI_Builders/ajaxhandler/LeaveAjax.php",
            type: "POST",
            data: formData,
            dataType: "json",
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.status === "success") {
                    logActivityJS("Submit Leave", "Student submitted leave application", "Completed", "Student");
                    $("#statusMessage").removeClass("hidden").text(response.message);
                    $("#leaveForm")[0].reset();
                    $(".subject-card").removeClass("selected");
                    $("#teacherPanel").addClass("hidden");
                    updateSelectedState();
                } else {
                    logActivityJS("Submit Leave", "Student leave submission failed", "Failed", "Student");
                    alert("ERROR: " + response.message);
                }
            },
            error: function(xhr, statusText, error) {
                logActivityJS("Submit Leave", "AJAX error during leave submission", "Failed", "Student");
                alert("AJAX REQUEST FAILED!\nSTATUS: " + statusText + "\nERROR: " + error + "\nRESPONSE: " + xhr.responseText);
            }
        });
    });



});