<?php
define('FCM_PROJECT_ID', 'ai-builders-852aa');
define('FCM_SERVICE_ACCOUNT_PATH', '/home/u725099291/domains/aibuilderss.com/private/ai-builders-852aa-firebase-adminsdk-fbsvc-8d401b6cb1.json');
define('FCM_ENDPOINT', 'https://fcm.googleapis.com/v1/projects/' . FCM_PROJECT_ID . '/messages:send');