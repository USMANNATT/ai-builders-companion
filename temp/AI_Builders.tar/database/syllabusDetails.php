<?php
class syllabus_details {

    public function getCoursesOfAFaculty($dbo,$facid){
        $c = "SELECT cd.id, cd.course_code, cd.course_title
              FROM course_allotment ca, course_details cd
              WHERE ca.course_id = cd.id
              AND ca.faculty_id = :facid";

        $s = $dbo->conn->prepare($c);
        $s->execute([":facid"=>$facid]);

        return $s->fetchAll(PDO::FETCH_ASSOC);
    }

    public function insertResource(
        $dbo,$course_id,$faculty_id,$type,$title,$desc,$file,$link,$visibility
    ){
        $c = "INSERT INTO course_resources
              (course_id, faculty_id, resource_type, title, description,
               file_path, external_link, visibility)
              VALUES
              (:cid,:fid,:type,:title,:desc,:file,:link,:vis)";

        $s = $dbo->conn->prepare($c);
        $s->execute([
            ":cid"=>$course_id,
            ":fid"=>$faculty_id,
            ":type"=>$type,
            ":title"=>$title,
            ":desc"=>$desc,
            ":file"=>$file,
            ":link"=>$link,
            ":vis"=>$visibility
        ]);
    }

    public function getCourseResources($dbo, $course_id) {

        try {
            $sql = "SELECT
                        resource_id,
                        resource_type,
                        title,
                        description,
                        file_path,
                        external_link
                    FROM course_resources
                    WHERE course_id = :cid
                    AND visibility = 'PUBLISHED'
                    ORDER BY resource_id DESC";
    
            $stmt = $dbo->conn->prepare($sql);
            $stmt->bindParam(":cid", $course_id, PDO::PARAM_INT);
            $stmt->execute();
    
            return [
                "status" => "success",
                "data"   => $stmt->fetchAll(PDO::FETCH_ASSOC)
            ];
    
        } catch (PDOException $e) {
    
            return [
                "status" => "error",
                "message" => $e->getMessage(),   // DB error
                "code"    => $e->getCode()
            ];
        }
    }
}    