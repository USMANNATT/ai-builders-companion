<?php
// Going to root directory
$path = $_SERVER['DOCUMENT_ROOT'];
// Getting inside our database file and loading it here
require_once $path . "/AI_Builders/database/database.php";

class admin_details {

    /* ---------------------------------------------------------
       Verify Admin Login
    ---------------------------------------------------------- */
    public function verifyAdmin($dbo, $user_name, $password) {

        $sql = "
            SELECT id, name, password
            FROM admin_details
            WHERE user_name = :user_name
              AND status    = 'active'
            LIMIT 1
        ";

        $stmt = $dbo->conn->prepare($sql);
        $stmt->execute([":user_name" => $user_name]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        // No matching username found
        if (!$row) {
            return ["status" => "Invalid username or password"];
        }

        // Verify bcrypt password
        if (!password_verify($password, $row['password'])) {
            return ["status" => "Invalid username or password"];
        }

        return [
            "status" => "ALLOK",
            "id"     => $row['id'],
            "name"   => $row['name']
        ];
    }

    /* ---------------------------------------------------------
       Fetch Recent Activity Log (latest 10 entries)
    ---------------------------------------------------------- */
    public function getRecentActivity($dbo, $limit = 10) {

        $sql = "
            SELECT
                id,
                user_name,
                role,
                module,
                action,
                status,
                ip_address,
                country,
                city,
                user_agent,
                DATE_FORMAT(created_at, '%d %b %Y %H:%i:%s') AS created_at
            FROM activity_log
            ORDER BY id DESC
            LIMIT :limit
        ";

        $stmt = $dbo->conn->prepare($sql);
        $stmt->bindValue(":limit", (int) $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }



    /* ---------------------------------------------------------
       Fetch Only New Activities Since a Given ID
    ---------------------------------------------------------- */
    public function getNewActivitiesSince($dbo, $last_id) {

        $sql = "
            SELECT
                id,
                user_name,
                role,
                module,
                action,
                status,
                ip_address,
                country,
                city,
                user_agent,
                DATE_FORMAT(created_at, '%d %b %Y %H:%i:%s') AS created_at
            FROM activity_log
            WHERE id > :last_id
            ORDER BY id DESC
        ";

        $stmt = $dbo->conn->prepare($sql);
        $stmt->bindValue(":last_id", (int) $last_id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /* ---------------------------------------------------------
       Fetch Today's Activity Log
       Used for CSV Download by Admin
    ---------------------------------------------------------- */
    public function getTodayActivity($dbo) {
    
        $sql = "
            SELECT
                id,
                user_name,
                role,
                module,
                action,
                status,
                ip_address,
                country,
                city,
                user_agent,
                DATE_FORMAT(created_at, '%d %b %Y %H:%i:%s') AS created_at
            FROM activity_log
            WHERE DATE(created_at) = CURDATE()
            ORDER BY id DESC
        ";
    
        $stmt = $dbo->conn->prepare($sql);
        $stmt->execute();
    
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

}
