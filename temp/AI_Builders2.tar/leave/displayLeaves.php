<?php
session_start();

if (isset($_SESSION["current_user"])) {
    $facid=$_SESSION["current_user"]; 
}
else{
    header("Location:"."/AI_Builders/login.php");
    die();
}

// Include the database connection
include __DIR__ . '/../database/database.php';

// Include activity log functions
include __DIR__ . '/../php/activity_log.php';

// Create database object
$dbo = new Database();
?>
<!DOCTYPE html>
<html>
<head>
    <title>AI-Buiders | Leave Records</title>
        <!-- ================== FAVICONS ================== -->
    <!-- apple device icon (iOS home screen) -->
    <link rel="apple-touch-icon" sizes="180x180" href="/AI_Builders/assets/favicon_io/apple-touch-icon.png">
    <!-- standard favicon for most desktop browsers (32×32) -->
    <link rel="icon" type="image/png" sizes="32x32" href="/AI_Builders/assets/favicon_io/favicon-32x32.png">
    <!-- smaller favicon for older browsers or low-resolution displays -->
    <link rel="icon" type="image/png" sizes="16x16" href="/AI_Builders/assets/favicon_io/favicon-16x16.png">
    <!-- fallback favicon for very old browsers -->
    <link rel="icon" href="/AI_Builders/assets/favicon_io/favicon.ico">
    <!-- web app manifest - helps progressive web app features (PWA) -->
    <link rel="manifest" href="/AI_Builders/assets/favicon_io/site.webmanifest">

    <link rel="stylesheet" href="/AI_Builders/assets/css/displayLeaves.css">
    <script src="/AI_Builders/assets/js/jquery.js"></script>
    <script src="/AI_Builders/assets/js/leavesssss.js"></script>
</head>
<body>
    <input type="hidden" id="userRole" value="Faculty">


    <h2 class="page-title">Leave Applications</h2>

<div id  = "leaveDetails">

    <!-- LEAVES ARE WRITTEN DYNAMICALLY USING JAVASCRIPT -->
</div>
    <!--  input hidden fields to store faculty id and selected course id -->
    <input type="hidden" name="hiddenFacId" id="hiddenFacId" value="<?php echo($facid);?>"> 


</body>
</html>
