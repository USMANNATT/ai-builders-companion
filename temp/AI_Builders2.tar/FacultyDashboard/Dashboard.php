<?php
    // CHECK IF THE USER IS ACCESSING THE PAGE DIRECTLY OR USING USER NAME AND PASSWORD
session_start();

if (isset($_SESSION["current_user"])) {
    // IF THE USER/FACULTY IS LOGED IN GET THE USER FACULTY ID THAT WE USE TO DSIPLAY SUBJECTS OF ANY FACULTY THAT IS LOGED IN
    $facid=$_SESSION["current_user"]; 
}
else{
    header("Location:"."/AI_Builders/login.php");
    die();

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elite Faculty Dashboard</title>

    <!-- favicons - icons shown in browser tabs and mobile home screens -->
    <!-- apple device icon (iOS home screen) -->
    <link rel="apple-touch-icon" sizes="180x180" href="/AI_Builders/assests/favicon_io/apple-touch-icon.png">
    <!-- standard favicon for most desktop browsers (32×32) -->
    <link rel="icon" type="image/png" sizes="32x32" href="/AI_Builders/assests/favicon_io/favicon-32x32.png">
    <!-- smaller favicon for older browsers or low-resolution displays -->
    <link rel="icon" type="image/png" sizes="16x16" href="/AI_Builders/assests/favicon_io/favicon-16x16.png">
    <!-- fallback favicon for very old browsers -->
    <link rel="icon" href="/AI_Builders/assests/favicon_io/favicon.ico">
    <!-- web app manifest - helps progressive web app features (PWA) -->
    <link rel="manifest" href="/AI_Builders/assests/favicon_io/site.webmanifest">

    <link rel="stylesheet" href="/AI_Builders/assets/css/FacultyDashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

    <script src="../assets/js/jquery.js"></script>
    <script src="/AI_Builders/assets/js/facultyDashboard.js"></script>
    <script src="/AI_Builders/assets/js/attendance.js"></script>
    <script src="/AI_Builders/assets/js/responsive.js"></script>
 
</head>
<body>

<!-- Sidebar Overlay -->
<div class="sidebar-overlay"></div>

<!-- Hamburger Menu -->
<button class="hamburger" aria-label="Toggle Menu">
    <span></span>
    <span></span>
    <span></span>
</button>

<div class="dashboard-container">
    <aside class="sidebar">
        <div class="logo-area">
            <div class="logo-icon"><i class="fas fa-graduation-cap"></i></div>
            <h2>AI<span>Builders</span></h2>
        </div>

        <nav>

            <ul>
                <li class="active"><a href="#"><i class="fas fa-th-large"></i> <span>Dashboard</span></a></li>
                <li><a href="/AI_Builders/attendance/attendance.php"><i class="fas fa-user-check"></i> <span>Attendance</span></a></li>
                <li><a href="/AI_Builders/leave/displayLeaves.php"><i class="fas fa-paper-plane"></i> <span>Leave Requests</span></a></li>




                <li><a href="/AI_Builders/resources/teacher_upload_resource.php"><i class="fas fa-layer-group"></i> <span>Upload Resources</span></a></li>




                <li>
                    <a href="/AI_Builders/updates/upload_updates.php">
                        <i class="fas fa-bullhorn"></i>
                        <span>Upload Updates</span>
                    </a>
                </li>

                <li>
                    <a href="/AI_Builders/exams/upload_exams.php">
                        <i class="fas fa-clipboard-list"></i>
                        <span>Upload Exams</span>
                    </a>
                </li>




                <li><a href="/AI_Builders/feedback/view_feedback.php"><i class="fas fa-chart-pie"></i> <span>Feedback</span></a></li>
                <li class="nav-divider"></li>
                <li><a href="#"><i class="fas fa-cog"></i> <span>Settings</span></a></li>
                <li class="logout"><a href="#" id="btnLogout"><i class="fas fa-power-off"> </i> <span>Logout</span></a></li>

            </ul>
        </nav>
    </aside>

    <main class="main-content">
        <header class="top-header">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="Search students, files...">
            </div>
            <div class="user-profile">
                <div class="date-chip" id="date"></div>
                <div class="notif-bell"><i class="fas fa-bell"></i><span class="dot"></span></div>
                <img src="https://ui-avatars.com/api/?name=Admin+User&background=007bff&color=fff" alt="Profile">
            </div>
        </header>



        <section class="welcome-section">
            <h1>Welcome back  <span class="wave">👋</span> <h1 id = "professor-name">Professor</h1> 
            </h1>
            <p>Here is what's happening with your courses today.</p>
        </section>




        <div class="stats-grid">
            <div class="stat-card">
                <div class="icon-box blue"><i class="fas fa-users"></i></div>
                <div class="stat-info"><h3 id = "totalStudents">60</h3><p>Total Students</p></div>
                <div class="trend up">+5%</div>
            </div>
            <div class="stat-card">
                <div class="icon-box green"><i class="fas fa-check-circle"></i></div>
                <div class="stat-info"><h3 id = "presentStudents">0</h3><p>Present Today</p></div>
                <div class="progress-bar"><div class="fill" style="width: 80%"></div></div>
            </div>
            <div class="stat-card">
                <div class="icon-box orange"><i class="fas fa-clock"></i></div>
                <div class="stat-info"><h3>03</h3><p>Pending Leaves</p></div>
                <button class="action-btn">Review</button>
            </div>
            <!-- <div class="stat-card">
                <div class="icon-box purple"><i class="fas fa-book-open"></i></div>
                <div class="stat-info"><h3>05</h3><p>Active Subjects</p></div>
            </div> -->
        </div>

        <div class="content-row">
            <div class="activity-panel">
                <div class="panel-header">
                  
                </div>
                <ul class="activity-list"> </ul>
            </div>

            <div class="quick-tools">
                <h3>Quick Actions</h3>
                <div class="tools-grid">
                    <button class="tool-card"><i class="fas fa-plus"></i> New Quiz</button>
                    <button class="tool-card"><i class="fas fa-file-export"></i> Report</button>
                    <button class="tool-card"><i class="fas fa-envelope"></i> Email All</button>
                    <button class="tool-card"><i class="fas fa-bullhorn"></i> Announce</button>
                </div>
            </div>
        </div>
    </main>
</div>


    <input type="hidden" name="hiddenFacId" id="hiddenFacId" value="<?php echo($facid);?>"> 
    <input type="hidden" name="hiddenselectedCourseId" id="hiddenSelectedCourseId" value="-1"> 

</body>
</html>