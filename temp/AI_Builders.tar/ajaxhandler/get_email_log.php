<?php
/**
 * get_email_log.php
 * ─────────────────────────────────────────────────────────────
 * Called by viewResources.js 15 seconds after resource upload
 * to fetch the most recent email log and report counts back.
 *
 * GET param: type = 'resource' | 'results'
 * ─────────────────────────────────────────────────────────────
 */

ob_start();
header('Content-Type: application/json');

$base   = dirname(__DIR__);
$type   = $_GET['type'] ?? 'resource';
$prefix = $type === 'results' ? 'emails_' : 'resource_emails_';
$logDir = $base . '/logs';

if (!is_dir($logDir)) {
    ob_end_clean();
    echo json_encode(['error' => 'Log directory not found']);
    exit;
}

// Find the most recently modified log file matching the prefix
$files = glob($logDir . '/' . $prefix . '*.json');

if (empty($files)) {
    ob_end_clean();
    echo json_encode(['error' => 'No log files found yet — emails may still be sending']);
    exit;
}

// Sort by modification time, newest first
usort($files, fn($a, $b) => filemtime($b) - filemtime($a));
$latestFile = $files[0];

// Only return logs from the last 2 minutes (relevant to current upload)
if (time() - filemtime($latestFile) > 120) {
    ob_end_clean();
    echo json_encode(['error' => 'No recent log found — emails may still be processing']);
    exit;
}

$log = json_decode(file_get_contents($latestFile), true);

ob_end_clean();
echo json_encode($log);
exit;