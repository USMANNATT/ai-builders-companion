/* ---------------------------------------------------------
   Activity Log Function
---------------------------------------------------------- */
function logActivityJS(module, action, status, role) {

    $.ajax({
        url: '/AI_Builders/ajaxhandler/log_activity_ajax.php',
        type: 'POST',
        data: { module, action, status, role },
        success: function(res) { console.log('Activity Logged:', res); },
        
        error: function(err) { console.error('Activity Logging Failed:', err.responseText || err.statusText); }
    });
}

/* ---------------------------------------------------------
   Render updates safely
---------------------------------------------------------- */
function renderCourseUpdates(updates) {
    const container = $(".updates-list");
    container.empty();

    if (!Array.isArray(updates) || updates.length === 0) {
        container.append($("<p>").text("No updates found"));
        return;
    }

    updates.forEach((update, index) => {
        const type = update.update_type ? update.update_type.toUpperCase() : "GENERAL";
        const date = update.update_date || "";
        const time = update.update_time || "";
        const message = update.update_message || "";

        const article = $("<article>", { class: "update-item" + (index === 0 ? " active" : "") });
        const meta = $("<div>", { class: "meta" });
        meta.append($("<span>", { class: "category", text: type }));
        meta.append($("<span>", { class: "date", text: date + " " + time }));
        article.append(meta);
        article.append($("<h4>", { text: message }));
        article.append($("<span>", { class: "arrow", text: "↗" }));
        container.append(article);
    });
}

/* ---------------------------------------------------------
   jQuery document ready
---------------------------------------------------------- */
$(document).ready(function() {

    const role = "Student";
    const courseId = $("#hiddenCourseId").val();

    if (!courseId) return console.warn("No course ID found for updates");

    // Fetch course updates
    $.ajax({
        url: "/AI_Builders/ajaxhandler/upload_updatesAjax.php",
        type: "POST",
        dataType: "json",
        data: { action: "getUpdates", course_id: courseId },
        success: function(response) {
            logActivityJS(
                "View Updates Page",
                `Fetched course updates for course ID: ${courseId}`,
                "Completed",
                "Student"
            );
            renderCourseUpdates(response);

        },
        error: function(xhr, status, error) {
            console.error(`AJAX ERROR: ${status} / ${error}`);
            logActivityJS(
                "View Updates Page",
                `Failed to fetch course updates for course ID: ${courseId}`,
                "Failed",
                role
            );
        }
    });

});
