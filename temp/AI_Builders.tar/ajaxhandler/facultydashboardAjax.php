<?php
// Get root directory path
$path = $_SERVER['DOCUMENT_ROOT']; 

// Include database connection file
require_once $path."/AI_Builders/database/database.php";

// Include faculty details file
require_once $path."/AI_Builders/database/facultyDetails.php";

// Include faculty details file
require_once $path."/AI_Builders/database/studentDetails.php";

// Include faculty details file
require_once $path."/AI_Builders/database/courseRegistrationDetails.php";

// Include faculty details file
require_once $path."/AI_Builders/database/attendanceDetails.php";


// Get action sent from frontend
$action = $_REQUEST["action"];

if (!empty($action)) {

    // If user wants to login
    if ($action == "getProfessorName") {

        // Get username and password from form
        $facid = $_POST["facid"];



        // Create database object
        $dbo = new Database();

        // Create faculty object
        $fdo = new faculty_details();



        // Verify user credentials
        // returns associative array $rv which conatain user id and status
        $rv = $fdo->getFacultyName($dbo, $facid);


        // Send response back as JSON
        echo json_encode($rv);
    }   
    
    //getTotalStudents


    if ($action == "getTotalStudents") {

        // Get username and password from form
        $facid = $_POST["facid"];



        // Create database object
        $dbo = new Database();

        $crgo = new CourseRegistrationDetails();

        // returns associative array $rv which contain total students registed in the course
        $rv= $crgo->getRegisteredStudentsByFacultyID($dbo,$facid);


        // Send response back as JSON
        echo json_encode($rv);
    } 



    //getpresentStudents
    if ($action == "getpresentStudents") {

        // Get username and password from form
        $facid = $_POST["facid"];
        $ondate = $_POST["date"];

        // Create database object
        $dbo = new Database();

        $ado = new attendanceDetails();

        // returns associative array $rv which contain the students who attendaed toady class
        $rv= $ado->getAttendanceOfAClassByFacultyIDOnADate($dbo, $facid, $ondate);

        // Send response back as JSON
        echo json_encode($rv);
    } 
}



?>
