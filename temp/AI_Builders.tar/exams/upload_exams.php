<?php
// CHECK IF THE USER IS ACCESSING THE PAGE DIRECTLY OR USING USER NAME AND PASSWORD
session_start();

if (isset($_SESSION["current_user"])) {
    // IF THE USER/FACULTY IS LOGED IN GET THE USER FACULTY ID THAT WE USE TO DSIPLAY SUBJECTS OF ANY FACULTY THAT IS LOGED IN
    $facid=$_SESSION["current_user"]; 
}
else{
    header("Location:"."/AI_Builders/login.php");
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Upload Exam Results</title>


    <!-- favicons - icons shown in browser tabs and mobile home screens -->
    <!-- apple device icon (iOS home screen) -->
    <link rel="apple-touch-icon" sizes="180x180" href="/AI_Builders/assests/favicon_io/apple-touch-icon.png">
    <!-- standard favicon for most desktop browsers (32×32) -->
    <link rel="icon" type="image/png" sizes="32x32" href="/AI_Builders/assests/favicon_io/favicon-32x32.png">
    <!-- smaller favicon for older browsers or low-resolution displays -->
    <link rel="icon" type="image/png" sizes="16x16" href="/AI_Builders/assests/favicon_io/favicon-16x16.png">
    <!-- fallback favicon for very old browsers -->
    <link rel="icon" href="/AI_Builders/assests/favicon_io/favicon.ico">
    <!-- web app manifest - helps progressive web app features (PWA) -->
    <link rel="manifest" href="/AI_Builders/assests/favicon_io/site.webmanifest">

    <link rel="stylesheet" href="/AI_Builders/assets/css/upload_updates.css">
    <link rel="stylesheet" href="/AI_Builders/assets/css/upload_exams.css">
    <script src="/AI_Builders/assets/js/jquery.js"></script>
    <!-- <script src="/AI_Builders/assets/js/teacher_upload_resource.js"></script> -->
    <script src="/AI_Builders/assets/js/upload_updates.js"></script>
    <script src="/AI_Builders/assets/js/upload_exams.js"></script>
    
    <link rel="manifest" href="/AI_Builders/manifest.json">
    
    
</head>
<body>

<h1 class="page-title">Upload Exam Results</h1>

<div class="container">

  <!-- LEFT: FORM -->

  <form id="examUploadForm" method="POST" enctype="multipart/form-data">

    <div class="card">
      <h2>Create Result</h2>

      <label>Select Subject</label>
      <select id="courseId" name="course_id" required></select>

      <label>Assessment Type</label>
      <select name="exam_type" required>
        <option value="Quiz 1">Quiz 1</option>
        <option value="Quiz 2">Quiz 2</option>
        <option value="Midterm">Midterm</option>
        <option value="Quiz 3">Quiz 3</option>
        <option value="Final">Final</option>
        <option value="Presentation 1">Presentation 1</option>
        <option value="Presentation 2">Presentation 2</option>
      </select>

      <label>Total Marks</label>
      <input type="number" name="total_marks" placeholder="100" required>




      <div id="dateTimeContainer"></div>

      <label>Upload Results</label>
      <input type="file" name="result_file" accept=".xls,.xlsx" required>
      <small>Upload an Excel file</small>

      <label>Exams Message</label>
      <textarea name="exam_message" placeholder="Write exam details here..."></textarea>

      <button type="submit">Publish Result</button>

    </div>

  </form>



  <!-- Preview -->
  <div class="glass-card preview-card">
    <h2>Preview</h2>

    <div class="update-card">
      <span class="tag">QUIZ</span>
      <p>
        Quiz-2 syllabus has been uploaded to the resources section.
      </p>

      <span class="arrow">↗</span>
    </div>
  </div>
</div>

    <input type="hidden" name="hiddenFacId" id="hiddenFacultyId" value="<?php echo($facid);?>"> 
    <script type="module" src="/AI_Builders/assets/js/Push-notifications.js"></script>

</body>
</html>
