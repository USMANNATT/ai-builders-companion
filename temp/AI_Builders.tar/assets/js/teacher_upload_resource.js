$(document).ready(function () {

    // Activity logging function
    function logActivityJS(module, action, status, role) {
        $.ajax({
            url: '/AI_Builders/ajaxhandler/log_activity_ajax.php',
            type: 'POST',
            data: {
                module: module,
                action: action,
                status: status,
                role: role  // send role from current page
            },
            success: function(res) {
                console.log('Activity Logged:', res);
            },
            error: function(err) {
                console.error('Activity Logging Failed:', err);
            }
        });
    }

    let facid = $("#hiddenFacultyId").val();

    // ===============================
    // TOAST NOTIFICATION  (NEW)
    // ===============================
    function showToast(message, type) {
        let $toast = $('#toast');
        $toast.removeClass('toast-success toast-error').addClass('toast-' + type).text(message);
        $toast.addClass('toast-visible');
        clearTimeout($toast.data('timer'));
        $toast.data('timer', setTimeout(function () {
            $toast.removeClass('toast-visible');
        }, 3500));
    }

    // ===============================
    // FETCH COURSES OF FACULTY
    // ===============================
    $.ajax({
        url: "/AI_Builders/ajaxhandler/resourceAJAX.php",
        type: "POST",
        dataType: "json",
        data: {
            action: "getCourses",
            facid: facid
        },
        success: function (rv) {
            let x = `<option value="">Select Course</option>`;
            let f = `<option value="">All Courses</option>`;   // NEW: for filter dropdown
            rv.forEach(course => {
                x += `<option value="${course.id}">${course.course_code} - ${course.course_title}</option>`;
                f += `<option value="${course.id}">${course.course_code} - ${course.course_title}</option>`;
            });
            $("#courseId").html(x);
            $("#filterCourse").html(f);    // NEW
            // Log fetching courses
            logActivityJS('Resource Page', 'Fetched Courses for Faculty', 'Completed', 'Faculty');
        },
        error: function(e){
            alert("Error fetching courses");
            console.error(e);
        } 
    });

    // ===============================
    // SUBMIT RESOURCE
    // ===============================
    $("#resourceForm").on("submit", function (e) {
        e.preventDefault();

        // NEW: duplicate title+type+course check before submit
        let newTitle  = $("#title").val().trim().toLowerCase();
        let newType   = $("#resourceType").val();
        let newCourse = $("#courseId").val();
        let duplicate = allResources.some(function(r) {
            return r.title.trim().toLowerCase() === newTitle &&
                   r.resource_type               === newType  &&
                   String(r.course_id)           === newCourse;
        });
        if (duplicate) {
            showToast('A resource with this title and type already exists for this course.', 'error');
            return;
        }

        let formData = new FormData();
        formData.append("action", "uploadResource");
        formData.append("faculty_id", facid);
        formData.append("course_id", $("#courseId").val());
        formData.append("resource_type", $("#resourceType").val());
        formData.append("title", $("#title").val());
        formData.append("description", $("#description").val());
        formData.append("visibility", $("#visibility").val());
        formData.append("external_link", $("#externalLink").val());
        if ($("#resourceFile")[0].files.length > 0) {
            formData.append("resource_file", $("#resourceFile")[0].files[0]);
        }

        // NEW: show uploading state
        let $btn = $('#submitBtn');
        $btn.prop('disabled', true).addClass('btn-uploading');
        $('#btnText').text('Uploading…');
        $('#btnSpinner').show();

        $.ajax({
            url: "/AI_Builders/ajaxhandler/resourceAJAX.php",
            type: "POST",
            dataType: "json",
            data: formData,
            contentType: false,
            processData: false,
            success: function (rv) {
                // NEW: reset button
                $btn.prop('disabled', false).removeClass('btn-uploading');
                $('#btnText').text('Upload Resource');
                $('#btnSpinner').hide();

                $("#msg").text(rv.message);
                if (rv.status === "success") {
                    $("#resourceForm")[0].reset();
                    showToast('Resource uploaded successfully!', 'success');  // NEW
                    loadFacultyResources();  // NEW: refresh the table below
                    // Log resource upload
                    let courseName = $("#courseId option:selected").text();
                    logActivityJS('Resource Page', `Uploaded Resource "${$("#title").val()}" for ${courseName}`, 'Completed', 'Faculty');
                } else {
                    showToast(rv.message || 'Upload failed.', 'error');  // NEW
                }
            },
            error: function (e) {
                // NEW: reset button on error
                $btn.prop('disabled', false).removeClass('btn-uploading');
                $('#btnText').text('Upload Resource');
                $('#btnSpinner').hide();

                alert("ERROR: SOMETHING WENT WRONG");
                console.error(e);
            }
        });
    });

    // ================================================================
    // NEW SECTION: MY UPLOADED RESOURCES — load, render, filter, delete
    // ================================================================

    let allResources = [];

    const TYPE_COLORS = {
        'SYLLABUS':    '#6366f1',
        'NOTES':       '#0ea5e9',
        'BOOK':        '#f59e0b',
        'SLIDES':      '#10b981',
        'PAST PAPERS': '#ef4444',
        'REFERENCE':   '#8b5cf6'
    };

    function fmtDate(dt) {
        if (!dt) return '—';
        let d = new Date(dt.replace(' ', 'T'));
        return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
    }

    // Fetch all resources this faculty has uploaded
    function loadFacultyResources() {
        $('#resourcesTableWrapper').html('<p class="loading-text">Loading your resources…</p>');

        $.ajax({
            url: "/AI_Builders/ajaxhandler/resourceAJAX.php",
            type: "POST",
            data: { action: "getFacultyResources", faculty_id: facid },
            success: function (rawResponse) {
                // Don't use dataType:"json" so we can manually parse and see raw errors
                let rv;
                try {
                    rv = (typeof rawResponse === 'string') ? JSON.parse(rawResponse) : rawResponse;
                } catch (e) {
                    console.error('[Resources] JSON parse error:', rawResponse);
                    $('#resourcesTableWrapper').html('<p class="empty-text">Server error. Open F12 console for details.</p>');
                    return;
                }
                if (!rv.success) {
                    console.error('[Resources] Server returned error:', rv);
                    $('#resourcesTableWrapper').html('<p class="empty-text">Error: ' + (rv.error || 'Unknown error') + '</p>');
                    return;
                }
                allResources = rv.data;
                renderResources(allResources);
            },
            error: function (xhr) {
                console.error('[Resources] AJAX failed:', xhr.responseText);
                $('#resourcesTableWrapper').html('<p class="empty-text">Request failed. Open F12 console for details.</p>');
            }
        });
    }

    // Build and inject the resources table
    function renderResources(data) {
        if (!data || data.length === 0) {
            $('#resourcesTableWrapper').html('<p class="empty-text">No resources uploaded yet.</p>');
            return;
        }

        let html = `
        <div class="res-table-scroll">
        <table class="res-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Course</th>
                    <th>Type</th>
                    <th>Title</th>
                    <th>Visibility</th>
                    <th>Uploaded</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>`;

        data.forEach(function (r, idx) {
            let color = TYPE_COLORS[r.resource_type] || '#64748b';
            let vis   = r.visibility === 'PUBLISHED'
                ? '<span class="badge badge-published">Published</span>'
                : '<span class="badge badge-draft">Draft</span>';
            html += `
            <tr data-id="${r.resource_id}">
                <td>${idx + 1}</td>
                <td class="td-course">${r.course_code}<br><small>${r.course_title}</small></td>
                <td><span class="type-badge" style="background:${color}">${r.resource_type}</span></td>
                <td class="td-title">${r.title}</td>
                <td>${vis}</td>
                <td>${fmtDate(r.uploaded_at)}</td>
                <td><button class="btn-delete" data-id="${r.resource_id}">&#x1F5D1; Delete</button></td>
            </tr>`;
        });

        html += `</tbody></table></div>`;
        $('#resourcesTableWrapper').html(html);
    }

    // Client-side filter by course and type
    $('#filterCourse, #filterType').on('change', function () {
        let courseFilter = $('#filterCourse').val();
        let typeFilter   = $('#filterType').val();
        let filtered = allResources.filter(function (r) {
            let courseMatch = courseFilter === '' || String(r.course_id) === courseFilter;
            let typeMatch   = typeFilter   === '' || r.resource_type     === typeFilter;
            return courseMatch && typeMatch;
        });
        renderResources(filtered);
    });

    // Delete — event delegation so it works after dynamic rendering
    $('#resourcesTableWrapper').on('click', '.btn-delete', function () {
        let rid  = $(this).data('id');
        let $row = $(this).closest('tr');

        if (!confirm('Delete this resource? This cannot be undone.')) return;

        $(this).prop('disabled', true).text('Deleting…');

        $.ajax({
            url: "/AI_Builders/ajaxhandler/resourceAJAX.php",
            type: "POST",
            dataType: "json",
            data: { action: 'deleteResource', resource_id: rid, faculty_id: facid },
            success: function (rv) {
                if (rv.success) {
                    $row.addClass('row-deleted');
                    setTimeout(function () {
                        $row.remove();
                        allResources = allResources.filter(r => r.resource_id != rid);
                        if ($('#resourcesTableWrapper tbody tr').length === 0) {
                            $('#resourcesTableWrapper').html('<p class="empty-text">No resources uploaded yet.</p>');
                        }
                    }, 400);
                    showToast('Resource deleted successfully.', 'success');
                    logActivityJS('Resource Page', 'Deleted Resource ID ' + rid, 'Completed', 'Faculty');
                } else {
                    showToast(rv.error || 'Delete failed.', 'error');
                }
            },
            error: function (e) {
                console.error(e);
                showToast('Server error while deleting.', 'error');
            }
        });
    });

    // Load on page init
    loadFacultyResources();

});
