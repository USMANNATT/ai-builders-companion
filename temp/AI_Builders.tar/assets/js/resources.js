/* ---------------------------------------------------------
   Function: renderCourseResources
---------------------------------------------------------- */
function renderCourseResources(resources) {

    const content = $(".content");
    content.find(".resources-section").remove();

    const section = $("<div>", { class: "resources-section active" });
    const groupedResources = {};

    resources.forEach(resource => {
        const type = resource.resource_type.toLowerCase();
        if (!groupedResources[type]) groupedResources[type] = [];
        groupedResources[type].push(resource);
    });

    for (const type in groupedResources) {
        let cssClass = type.replace("_", "-");
        const category = $("<div>", { class: `resource-category ${cssClass}` });
        const title    = $("<h3>").text(cssClass.replace("-", " ").toUpperCase());
        const list     = $("<div>", { class: "resource-list" });

        groupedResources[type].forEach(res => {
            const item        = $("<div>", { class: "resource-item" });
            const info        = $("<div>", { class: "resource-info" });
            const name        = $("<div>", { class: "resource-name", text: res.title });
            const meta        = $("<div>", { class: "resource-meta", text: res.description || "No description" });
            info.append(name, meta);

            const btnGroup    = $("<div>");
            const downloadBtn = $("<button>", { class: "download-btn", html: "⬇️ Download", "data-filename": res.file_path });
            const viewBtn     = $("<a>", {
                class:  "download-btn",
                html:   "👁 View",
                href:   res.external_link ? res.external_link : "../uploads/" + res.file_path,
                target: "_blank"
            });

            btnGroup.append(downloadBtn, viewBtn);
            item.append(info, btnGroup);
            list.append(item);
        });

        category.append(title, list);
        section.append(category);
    }

    content.append(section);
    updateDownloadedBadges();
}

/* ---------------------------------------------------------
   Function: addDownloadedBadge
---------------------------------------------------------- */
function addDownloadedBadge(button) {
    if (button.parent().find(".downloaded-badge").length === 0) {
        $("<span>", { class: "downloaded-badge", text: "✓ Downloaded" }).appendTo(button.parent());
    }
}

/* ---------------------------------------------------------
   Function: updateDownloadedBadges
---------------------------------------------------------- */
function updateDownloadedBadges() {
    $(".downloaded-badge").remove();
    $(".download-btn").each(function () {
        const filename = $(this).data("filename");
        if (downloadedResources.has(filename)) addDownloadedBadge($(this));
    });
}

/* ---------------------------------------------------------
   Load previously downloaded resources
---------------------------------------------------------- */
const downloadedResources = new Set(JSON.parse(localStorage.getItem('downloadedResources') || '[]'));

/* ---------------------------------------------------------
   Activity Log Function
---------------------------------------------------------- */
function logActivityJS(module, action, status, role) {
    $.ajax({
        url:  '/AI_Builders/ajaxhandler/log_activity_ajax.php',
        type: 'POST',
        data: { module, action, status, role },
        success: function (res) { console.log('Activity Logged:', res); },
        error:   function (err) { console.error('Activity Logging Failed:', err); }
    });
}

/* ---------------------------------------------------------
   jQuery document ready
---------------------------------------------------------- */
$(document).ready(function () {

    const role      = "Student";
    const course_id = $("#hiddenCourseId").val();

    logActivityJS("View Resources Page", "Opened resources page", "Completed", role);

    // ── Fetch course name ─────────────────────────────────────
    $.ajax({
        url:      "/AI_Builders/ajaxhandler/dashboardAjax.php",
        type:     "POST",
        dataType: "json",
        data:     { action: "getSubjectName", course_id },
        success: function (response) {
            $("#subject-title").html(response.course_title);
        },
        error: function (xhr, status, error) {
            alert("AJAX Error: " + error);
            logActivityJS("View Resources Page", "Failed fetching course title", "Failed", role);
        }
    });

    // ── Fetch course resources ────────────────────────────────
    $.ajax({
        url:      "/AI_Builders/ajaxhandler/resourceAJAX.php",
        type:     "POST",
        dataType: "json",
        data:     { action: "getSubjectResources", course_id },
        success: function (response) {
            renderCourseResources(response.data.data);
            logActivityJS("View Resources Page", "Fetched resources successfully", "Completed", role);
        },
        error: function (xhr, status, error) {
            let message = "AJAX ERROR 🚨\nStatus: " + status + "\nError: " + error + "\nHTTP: " + xhr.status + "\nResponse: " + xhr.responseText;
            alert(message);
            logActivityJS("View Resources Page", "Failed fetching resources", "Failed", role);
        }
    });

    // ── Handle resource upload form submit ────────────────────
    // Assumes faculty upload form has id="resourceUploadForm"
    $(document).on("submit", "#resourceUploadForm", function (e) {
        e.preventDefault();

        const $btn = $(this).find('[type="submit"]');
        $btn.prop('disabled', true).text('Uploading…');

        const formData = new FormData(this);
        formData.append('action', 'uploadResource');

        $.ajax({
            url:         '/AI_Builders/ajaxhandler/resourceAJAX.php',
            type:        'POST',
            data:        formData,
            processData: false,
            contentType: false,
        success: function (response) {
        
            $btn.prop('disabled', false).text('Upload');
        
            if (typeof response === 'string') {
                try { response = JSON.parse(response); } catch (e) {}
            }
        
            console.log("FULL RESPONSE:", response);
        
            if (response.status === 'success') {
        
                let message = "✅ " + response.message;
        
                // 🔹 If email result exists
                if (response.email_result) {
        
                    const emailData = response.email_result.summary;
        
                    if (emailData) {
                        message += `
        
        📧 Email Summary:
        • Total Students: ${emailData.total}
        • Sent Successfully: ${emailData.sent}
        • Failed: ${emailData.failed}`;
                    }
        
                    // If some failed
                    if (response.email_result.summary.failed > 0) {
                        message += "\n\n⚠ Some emails failed. Check console for details.";
                        console.error("❌ Email Errors:", response.email_result.errors);
                    }
        
                    // If no students found
                    if (response.email_result.summary.total === 0) {
                        message += "\n\n⚠ No students found for this course.";
                    }
                }
        
                alert(message);
        
                logActivityJS(
                    'Resource Upload Page',
                    `Uploaded resource for course ID ${formData.get('course_id')}`,
                    'Completed',
                    'Faculty'
                );
        
            } else {
        
                alert('❌ Upload failed: ' + (response.message || 'Unknown error'));
        
                logActivityJS(
                    'Resource Upload Page',
                    'Resource upload failed',
                    'Failed',
                    'Faculty'
                );
            }
        },


            error: function (xhr, status, error) {
                $btn.prop('disabled', false).text('Upload');
                alert('AJAX Request Failed!\nStatus: ' + status + '\nError: ' + error + '\n\n' + xhr.responseText);
                logActivityJS('Resource Upload Page', 'AJAX error during resource upload', 'Failed', 'Faculty');
            }
        });
    });

    // ── Handle download click ─────────────────────────────────
    $(document).on("click", ".download-btn", function (e) {
        const button   = $(this);
        const filename = button.data("filename");
        if (!filename) return;

        const a = document.createElement("a");
        a.href     = "../uploads/" + filename;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        if (!downloadedResources.has(filename)) {
            downloadedResources.add(filename);
            localStorage.setItem("downloadedResources", JSON.stringify([...downloadedResources]));
            addDownloadedBadge(button);
        }

        logActivityJS("View Resources Page", "Downloaded resource: " + filename, "Completed", role);
    });

    updateDownloadedBadges();
});
