<?php
    // CHECK IF THE USER IS ACCESSING THE PAGE DIRECTLY OR USING USER NAME AND PASSWORD
session_start();

if (isset($_SESSION["current_user"])) {
    // IF THE USER/FACULTY IS LOGED IN GET THE USER FACULTY ID THAT WE USE TO DSIPLAY SUBJECTS OF ANY FACULTY THAT IS LOGED IN
    $facid=$_SESSION["current_user"]; 
}
else{
    header("Location:"."/AI_Builders/login.php");
    die();

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View All Feedback</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/AI_Builders/assets/css/view_feedback.css">
    <script src="/AI_Builders/assets/js/jquery.js"></script>
    <script src="/AI_Builders/assets/js/feedback.js"></script>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📋 All Feedback</h1>
            <p>View all submitted feedback entries</p>
        </div>

        <div class="content">
            <h3 style="color: #555; margin-bottom: 1rem;">Total Feedbacks: <strong style="color: #6a0dad;">1</strong></h3>
            
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Roll</th>
                        <th>Section</th>
                        <th>Rating</th>
                        <th>Feedback Message</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                <tr>
                    <td data-label="ID"><strong>1</strong></td>
                    <td data-label="Name">John Doe</td>
                    <td data-label="Email">john@example.com</td>
                    <td data-label="Roll">
                        <span class="roll-no">2025-AI-82</span>
                    </td>
                    <td data-label="Section">A</td>
                    <td data-label="Rating"><span class="rating-stars">★★★★☆</span></td>
                    <td data-label="Message" class="message-cell">This is a message.</td>
                    <td data-label="Date">Feb 07, 2026</td>
                </tr>
                <tr>
                    <td data-label="ID"><strong>1</strong></td>
                    <td data-label="Name">John Doe</td>
                    <td data-label="Email">john@example.com</td>
                    <td data-label="Roll">
                        <span class="roll-no">2025-AI-82</span>
                    </td>
                    <td data-label="Section">A</td>
                    <td data-label="Rating"><span class="rating-stars">★★★★☆</span></td>
                    <td data-label="Message" class="message-cell">This is a message.</td>
                    <td data-label="Date">Feb 07, 2026</td>
                </tr>
                <tr>
                    <td data-label="ID"><strong>1</strong></td>
                    <td data-label="Name">John Doe</td>
                    <td data-label="Email">john@example.com</td>
                    <td data-label="Roll">
                        <span class="roll-no">2025-AI-82</span>
                    </td>
                    <td data-label="Section">A</td>
                    <td data-label="Rating"><span class="rating-stars">★★★★☆</span></td>
                    <td data-label="Message" class="message-cell">This is a message.</td>
                    <td data-label="Date">Feb 07, 2026</td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    <input type="hidden" name="hiddenFacId" id="hiddenFacId" value="<?php echo($facid);?>"> 
    <!--   -->
</body>
</html>