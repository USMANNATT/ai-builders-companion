$(document).ready(function () {



    /* ==========================
       LOAD COURSE UPDATES
    ========================== */
    
    const courseId = $("#hiddenCourseId").val();
    const limitVal = $("#updatesLimit").val(); // optional: could be 3
    const maxDefault = 10; // default max to display if limit not specified
    
    if (courseId) {
    
        $.ajax({
            url: "/AI_Builders/ajaxhandler/upload_updatesAjax.php",
            type: "POST",
            dataType: "json",
            data: {
                action: "getUpdates",
                course_id: courseId
            },
            success: function (response) {
    
                const container = $(".updates-list");
                container.empty();
    
                if (!response || response.length === 0) {
                    container.append("<p>No updates found</p>");
                    return;
                }
    
                // Determine how many updates to display
                let displayLimit = maxDefault; // default 10
    
                if (limitVal) {
                    const parsedLimit = parseInt(limitVal, 10);
                    if (!isNaN(parsedLimit)) {
                        displayLimit = parsedLimit; // override if limit is set
                    }
                }
    
                // Slice updates array according to display limit
                const updatesToShow = response.slice(0, displayLimit);
    
                // Render updates
                updatesToShow.forEach((update, index) => {
                    container.append(`
                        <article class="update-item ${index === 0 ? 'active' : ''}">
                            <div class="meta">
                                <span class="category">${update.update_type.toUpperCase()}</span>
                                <span class="date">${update.update_date}</span>
                                <span class="date">${update.update_time}</span>
                            </div>
                            <h4>${update.update_message}</h4>
                            <span class="arrow">↗</span>
                        </article>
                    `);
                });
    
            },
            error: function (xhr, status, error) {
                console.error("Fetch updates error:", error);
                console.error("Fetch updates status:", status);
                console.error("Fetch updates response:", xhr.responseText);
            }
        });
    
    }
    
        /* ==========================
           ELEMENT REFERENCES
           ========================== */
    
        const $mobileNavToggle   = $("#mobileNavToggle");
        const $sidebarToggleLeft = $("#sidebarToggleLeft");
        const $navCloseBtn       = $("#navCloseBtn");
        const $navbar1           = $("#navbar1");
        const $sidebar            = $("#sidebar");
        const $menuOverlay        = $("#menuOverlay");
    
        /* ==========================
           SAFETY CHECK
           ========================== */
        if (!$navbar1.length || !$sidebar.length || !$menuOverlay.length) {
            console.warn("Required layout elements are missing.");
            return;
        }
    
        /* ==========================
           MENU CONTROL FUNCTIONS
           ========================== */
    
        // Close all menus and overlay
        function closeAllMenus() {
            $navbar1.removeClass("active");
            $sidebar.removeClass("active");
            $menuOverlay.removeClass("active");
            $("body").removeClass("nav-open");
        }
    
        // Open a specific menu
        function openMenu($menu) {
            closeAllMenus();
            $menu.addClass("active");
            $menuOverlay.addClass("active");
            
            // Add class to body when nav is open (for close button visibility)
            if ($menu.is($navbar1)) {
                $("body").addClass("nav-open");
            }
        }
    
        /* ==========================
           TOGGLE BUTTON EVENTS
           ========================== */
    
        // Mobile top navigation toggle
        $mobileNavToggle.on("click", function (e) {
            e.stopPropagation();
            $navbar1.hasClass("active")
                ? closeAllMenus()
                : openMenu($navbar1);
        });
    
        // Left sidebar toggle
        $sidebarToggleLeft.on("click", function (e) {
            e.stopPropagation();
            $sidebar.hasClass("active")
                ? closeAllMenus()
                : openMenu($sidebar);
        });
    
        // Close button for navigation
        $navCloseBtn.on("click", function (e) {
            e.stopPropagation();
            closeAllMenus();
        });
    
        /* ==========================
           OVERLAY CLICK
           ========================== */
    
        // Clicking overlay closes everything
        $menuOverlay.on("click", closeAllMenus);
    
        /* ==========================
           CLOSE MENUS ON LINK CLICK
           (Mobile Only)
           ========================== */
    
        $(".navbar1 a, .sidebar a").on("click", function () {
            if ($(window).width() <= 768) {
                closeAllMenus();
            }
        });
    
        /* ==========================
           RESPONSIVE HANDLER
           ========================== */
    
        function handleResize() {
            if ($(window).width() <= 768) {
                $mobileNavToggle.css("display", "flex");
                $sidebarToggleLeft.css("display", "flex");
            } else {
                $mobileNavToggle.hide();
                $sidebarToggleLeft.hide();
                closeAllMenus();
            }
        }
    
        $(window).on("resize", handleResize);
        handleResize();
    
        /* ==========================
           LOAD STUDENT SUBJECTS
           ========================== */
    
        const sid = $("#hiddenStId").val();
    
        if (sid) {
            $.ajax({
                url: "/AI_Builders/ajaxhandler/dashboardAjax.php",
                type: "POST",
                dataType: "json",
                data: {
                    action: "getStudentSubjects",
                    student_id: sid
                },
                success: function (response) {
                
    
                    const $menu = $("#subjectMenu");
                    $menu.empty().addClass("show");
    
                    if (!response || response.length === 0) {
                        $menu.append("<p>No subjects assigned</p>");
                        return;
                    }
    
                    // Append subject links
                    $.each(response, function (_, subject) {
                        $("<a>", {
                            href: "subject.php?id=" + subject.id,
                            text: subject.course_title
                        }).appendTo($menu);
                    });
                },
                error: function (xhr, status, error) {
                    console.error("Fetch updates error:", error);
                    console.log(xhr.responseText); // will show PHP errors
                }
                
            });
        }
    
        /* ==========================
           LOAD COURSE NAME
           ========================== */
    
        const course_id = $("#hiddenCourseId").val();
    
        if (course_id) {
            $.ajax({
                url: "/AI_Builders/ajaxhandler/dashboardAjax.php",
                type: "POST",
                dataType: "json",
                data: {
                    action: "getSubjectName",
                    course_id: course_id
                },
                success: function (response) {
                    if (response && response.course_title) {
                        $(".title").text(response.course_title);
                        document.title = response.course_title;
                    }
                },
                error: function (xhr, status, error) {
                    console.error("Course name AJAX error:", error);
                }
            });
        }
    
    
    
    });
    