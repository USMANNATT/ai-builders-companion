<?php
/**
 * upload_results_Ajax.php
 * ─────────────────────────────────────────────────────────────
 * Handles exam result uploads. Responds immediately after DB insert,
 * then sends emails in the background to avoid timeout.
 * ─────────────────────────────────────────────────────────────
 */

ob_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json');

$base = dirname(__DIR__);
require_once $base . '/vendor/autoload.php';
require_once $base . '/database/database.php';
require_once $base . '/database/resultDetails.php';
require_once __DIR__ . '/sendExamResultEmail.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$dbo = new Database();
$rbo = new result_details();
$action = $_REQUEST['action'] ?? '';

try {

    if ($action === 'uploadResults') {

        $errors = [];

        // =============================
        // VALIDATE FILE
        // =============================
        if (!isset($_FILES['result_file'])) {
            $errors[] = "Excel file is required.";
        } elseif ($_FILES['result_file']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = "Error uploading Excel file.";
        }

        // =============================
        // VALIDATE FORM FIELDS
        // =============================
        $faculty_id  = trim($_POST['hiddenFacId'] ?? '');
        $course_id   = (int) ($_POST['course_id'] ?? 0);
        $exam_type   = trim($_POST['exam_type']   ?? '');
        $total_marks = trim($_POST['total_marks'] ?? '');

        if (empty($faculty_id)) {
            $errors[] = "Faculty ID is missing.";
        }
        if (empty($course_id)) {
            $errors[] = "Course ID is missing.";
        }
        if (empty($exam_type)) {
            $errors[] = "Exam type is required.";
        }
        if ($total_marks === '') {
            $errors[] = "Total marks field is required.";
        }

        if (!empty($errors)) {
            ob_end_clean();
            echo json_encode(['status' => false, 'errors' => $errors]);
            exit;
        }

        // =============================
        // READ EXCEL
        // =============================
        $fileTmp     = $_FILES['result_file']['tmp_name'];
        $spreadsheet = IOFactory::load($fileTmp);
        $sheet       = $spreadsheet->getActiveSheet();
        $rows        = $sheet->toArray(null, true, true, true);
        unset($rows[1]); // remove header row

        if (empty($rows)) {
            ob_end_clean();
            echo json_encode(['status' => false, 'errors' => ['Excel file is empty.']]);
            exit;
        }

        // =============================
        // VALIDATE EACH ROW
        // =============================
        $rowNumber = 2;
        foreach ($rows as $row) {
            $student_id = trim($row['A'] ?? '');
            $marks      = trim($row['B'] ?? '');

            if (empty($student_id)) {
                $errors[] = "Row {$rowNumber}: Student ID is missing.";
            }
            if ($marks === '') {
                $errors[] = "Row {$rowNumber}: Marks are missing.";
            }
            if (!is_numeric($marks)) {
                $errors[] = "Row {$rowNumber}: Marks must be numeric.";
            }
            if (is_numeric($marks) && $marks > $total_marks) {
                $errors[] = "Row {$rowNumber}: Marks cannot exceed total marks ({$total_marks}).";
            }
            $rowNumber++;
        }

        if (!empty($errors)) {
            ob_end_clean();
            echo json_encode(['status' => false, 'errors' => $errors]);
            exit;
        }

        // =============================
        // INSERT DATA
        // =============================
        $rbo->insertResultsBulk(
            $dbo,
            $rows,
            $faculty_id,
            $exam_type,
            $total_marks
        );

        // =============================
        // RESPOND IMMEDIATELY
        // =============================
        ob_end_clean();
        echo json_encode([
            'status'  => true,
            'message' => 'Results uploaded successfully. Emails will be sent shortly.',
        ]);

        // Flush to browser
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }

        // =============================
        // SEND EMAILS IN BACKGROUND
        // =============================
        ignore_user_abort(true);
        set_time_limit(0);

        // Small delay to ensure HTTP response fully sent
        usleep(100000); // 0.1 second

        $emailResult = sendExamResultEmail(
            $dbo,
            $rows,
            $course_id,
            $exam_type,
            (int) $total_marks
        );

        // Log results
        $logDir = $base . '/logs';
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }
        @file_put_contents(
            $logDir . '/emails_' . date('Y-m-d_His') . '.json',
            json_encode($emailResult, JSON_PRETTY_PRINT)
        );

        exit;
    }

    ob_end_clean();
    echo json_encode(['status' => false, 'errors' => ['Invalid action.']]);
    exit;

} catch (Exception $e) {
    ob_end_clean();
    echo json_encode(['status' => false, 'errors' => ['System Error: ' . $e->getMessage()]]);
    exit;
}
