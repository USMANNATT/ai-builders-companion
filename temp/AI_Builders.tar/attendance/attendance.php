<?php
// CHECK IF THE USER IS ACCESSING THE PAGE DIRECTLY OR USING USER NAME AND PASSWORD
session_start();
if (isset($_SESSION["current_user"])) {
    $facid=$_SESSION["current_user"]; 
}
else{
    header("Location:"."/AI_Builders/login.php");
    die();
}
include __DIR__ . '/../database/database.php';
include __DIR__ . '/../php/activity_log.php';
$dbo = new Database();
$stmt = $dbo->conn->prepare("SELECT name FROM faculty_details WHERE id = :id");
$stmt->execute([':id' => $facid]);
$faculty_name = ($row = $stmt->fetch(PDO::FETCH_ASSOC)) ? $row['name'] : 'Unknown Faculty';
logActivity(
    $dbo,
    $facid,
    $faculty_name,
    'Faculty',
    'Attendance Page',
    'Accessed Attendance Page',
    'Completed'
);
?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI Builders-Attendance</title>
  <link rel="apple-touch-icon" sizes="180x180" href="/AI_Builders/assests/favicon_io/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="/AI_Builders/assests/favicon_io/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="/AI_Builders/assests/favicon_io/favicon-16x16.png">
  <link rel="icon" href="/AI_Builders/assests/favicon_io/favicon.ico">
  <link rel="manifest" href="/AI_Builders/assests/favicon_io/site.webmanifest">
  <link rel="stylesheet" href="../assets/css/Attendance.css">
</head>
<body>
<div class="page">
    <div class="header-area">
        <div class="logo-area"><h1 class="logo">Attendance page</h1></div> 
        <div class="logout-area"><button class="btnLogout" id="btnLogout">LOGOUT</button></div>
    </div>
    <div class="session-area">
        <div class="label-area"> 
            <label>SESSION</label> 
        </div>
        <div class="dropdown-area">
            <select class="ddlclass" id="ddlclass">
                <!-- Sessions come dynamically using javascript -->
            </select>
        </div>
    </div>
    <div class="classlist-area" id="classlistarea">
        <!-- Classcards come dynamically using javascript -->
    </div>

    <!-- ── NEW: Section selector (hidden until a course card is clicked) ── -->
    <div class="section-selector-area" id="sectionSelectorArea" style="display:none;">
        <div class="section-selector-inner">
            <span class="section-label">SELECT SECTION</span>
            <div class="section-buttons" id="sectionButtons">
                <!-- A–I buttons injected by JS -->
            </div>
        </div>
    </div>
    <!-- ─────────────────────────────────────────────────────────────────── -->

    <div class="classdetails-area" id="classdetailsarea">
        <!-- Class details come dynamically using javascript -->
    </div>
    <div class="studentlist-area" id="studentlistarea">
        <!-- Student details come dynamically using javascript -->
    </div> 
</div>
<input type="hidden" name="hiddenFacId"            id="hiddenFacId"            value="<?php echo($facid);?>"> 
<input type="hidden" name="hiddenselectedCourseId" id="hiddenSelectedCourseId" value="-1"> 
<!-- NEW: stores the currently selected section id -->
<input type="hidden" name="hiddenSelectedSectionId" id="hiddenSelectedSectionId" value="-1">

<script src="../assets/js/jquery.js"></script>
<script src="../assets/js/Attendance.js"></script>   
</body>
</html>