<?php
// Going to root directory
$path = $_SERVER['DOCUMENT_ROOT']; 
// Getting inside or database file and loading it here 
require_once $path."/AI_Builders/database/database.php";

// class to handle course registration details
class CourseRegistrationDetails
{
    // ─────────────────────────────────────────────────────────
    // ORIGINAL: Get registered students for a course in a session
    // MODIFIED: added optional $sectionid parameter to filter by section
    // ─────────────────────────────────────────────────────────
    public function getRegisteredStudents($dbo, $sessionid, $courseid, $sectionid = null){
        // Initialize an empty array to hold the results
        $rv = [];

        // Build section filter only when sectionid is provided
        $sectionCondition = $sectionid ? "and crg.section_id = :sectionid" : "";

        // Prepare the SQL query to fetch registered students
        $c = "select sd.id, sd.roll_no, sd.name from student_details as sd,
        course_registration as crg
        where crg.student_id = sd.id
        and crg.session_id = :sessionid
        and crg.course_id  = :courseid
        {$sectionCondition}";

        // Prepare and execute the SQL statement
        $s = $dbo->conn->prepare($c);
        try {
            $params = [":sessionid" => $sessionid, ":courseid" => $courseid];
            if ($sectionid) {
                $params[":sectionid"] = $sectionid;
            }
            $s->execute($params);
            $rv = $s->fetchAll(PDO::FETCH_ASSOC);
        } 
        catch (Exception $e) {
            echo "error in class courseRegistrationDetails";
        }
        return $rv;
    }

    // ─────────────────────────────────────────────────────────
    // ORIGINAL: Get total registered students count by faculty ID
    // ─────────────────────────────────────────────────────────
    public function getRegisteredStudentsByFacultyID($dbo, $facid){
        $rv = [];
        $c = "SELECT COUNT(DISTINCT crg.student_id) AS total_students
                FROM course_registration crg
                WHERE crg.course_id = (
                    SELECT ca.course_id
                    FROM course_allotment ca
                    WHERE ca.faculty_id = :facid
                    LIMIT 1
                )";
        $s = $dbo->conn->prepare($c);
        try {
            $s->execute([":facid"=>$facid]);
            $rv = $s->fetch(PDO::FETCH_ASSOC);
        } 
        catch (Exception $e) {
            echo"error in class courseRegistrationDetails";
        }
        return $rv;
    }

    // ─────────────────────────────────────────────────────────
    // ORIGINAL: Get all registered courses of a student
    // ─────────────────────────────────────────────────────────
    public function getAllRegisteredCoursesOfAStudent($dbo, $studentId){
        $cmd = "SELECT cr.course_id, ca.faculty_id
                FROM course_registration cr
                JOIN (
                    SELECT course_id, faculty_id
                    FROM course_allotment
                    GROUP BY course_id
                ) ca ON cr.course_id = ca.course_id
                WHERE cr.student_id = :studentId";
        $stmt = $dbo->conn->prepare($cmd);
        $stmt->execute([":studentId" => $studentId]);
        $allCourses = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $allCourses;
    }

    // ─────────────────────────────────────────────────────────
    // ORIGINAL: Get subjects (title + id) by student id
    // ─────────────────────────────────────────────────────────
    public function getSubjectsByStudent($dbo, $student_id){
        $sql = "SELECT 
                    cd.course_title,
                    cd.id
                FROM course_registration cr
                INNER JOIN course_details cd ON cr.course_id = cd.id
                WHERE cr.student_id = :student_id";
        $stmt = $dbo->conn->prepare($sql);
        $stmt->bindParam(":student_id", $student_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ─────────────────────────────────────────────────────────
    // ORIGINAL: Get subject name by course id
    // ─────────────────────────────────────────────────────────
    public function getSubjectName($dbo, $course_id){
        $sql = "SELECT 
                    cd.course_title
                FROM course_details cd 
                WHERE cd.id = :course_id";
        $stmt = $dbo->conn->prepare($sql);
        $stmt->bindParam(":course_id", $course_id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // ─────────────────────────────────────────────────────────
    // NEW: Get registered subjects WITH teacher info
    // Used by subject-card rendering on the leave form
    // Joins course_allotment ON course_id AND session_id
    // so teacher shown matches the student's actual session
    // Returns: course_id, course_code, course_title,
    //          teacher_id, teacher_name, teacher_email
    // ─────────────────────────────────────────────────────────
    public function getRegisteredSubjectsWithTeacher($dbo, $studentId){
        $rv  = [];
        $cmd = "SELECT
                    cd.id               AS course_id,
                    cd.course_code,
                    cd.course_title,
                    fd.id               AS teacher_id,
                    fd.name             AS teacher_name
                FROM course_registration AS cr
                INNER JOIN course_details AS cd
                        ON cr.course_id   = cd.id
                LEFT  JOIN course_allotment AS ca
                        ON  ca.course_id  = cd.id
                        AND ca.session_id = cr.session_id
                LEFT  JOIN faculty_details AS fd
                        ON  fd.id         = ca.faculty_id
                WHERE cr.student_id = :studentId
                ORDER BY cd.course_title ASC;";

        $s = $dbo->conn->prepare($cmd);
        try {
            $s->execute([":studentId" => $studentId]);
            $rv = $s->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            echo "error in class courseRegistrationDetails";
        }
        return $rv;
    }
}
?>