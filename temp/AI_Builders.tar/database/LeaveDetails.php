<?php
// Get root folder path
$path = $_SERVER['DOCUMENT_ROOT'];

// Include database connection file
require_once $path . "/AI_Builders/database/database.php";

class leave_requests {

    // ─────────────────────────────────────────────────────────
    // PRIVATE: Shared INSERT helper
    // ─────────────────────────────────────────────────────────
    private function _insertRow(
        $dbo, $studentId, $facultyId, $courseId,
        $leaveReason, $startDate, $endDate, $totalDays,
        $hospitalName, $description, $fileName
    ) {
        $cmd = "INSERT INTO leave_requests
                    (student_id, faculty_id, course_id,
                     leave_reason, start_date, end_date, total_days,
                     hospital_name, description, attachment)
                VALUES
                    (:studentId, :facultyId, :courseId,
                     :leaveReason, :startDate, :endDate, :totalDays,
                     :hospitalName, :description, :attachment)";

        $stmt = $dbo->conn->prepare($cmd);
        $stmt->execute([
            ":studentId"    => $studentId,
            ":facultyId"    => $facultyId,
            ":courseId"     => $courseId,
            ":leaveReason"  => $leaveReason,
            ":startDate"    => $startDate,
            ":endDate"      => $endDate,
            ":totalDays"    => $totalDays,
            ":hospitalName" => $hospitalName ?: null,
            ":description"  => $description  ?: null,
            ":attachment"   => $fileName      ?: null,
        ]);
    }

    // ─────────────────────────────────────────────────────────
    // Insert leave for multiple courses (ALL SUBJECTS path)
    // $allCourses rows must contain: course_id, faculty_id
    // ─────────────────────────────────────────────────────────
    public function insertLeaves(
        $dbo, $studentId, $leaveReason, $startDate, $endDate,
        $totalDays, $hospitalName, $description, $fileName, $allCourses
    ) {
        foreach ($allCourses as $courseRow) {
            $this->_insertRow(
                $dbo,
                $studentId,
                $courseRow['faculty_id'],
                $courseRow['course_id'],
                $leaveReason, $startDate, $endDate, $totalDays,
                $hospitalName, $description, $fileName
            );
        }
    }

    // ─────────────────────────────────────────────────────────
    // Insert single leave by course CODE (legacy path)
    // Looks up course_id from course_details,
    // then faculty_id from course_allotment
    // ─────────────────────────────────────────────────────────
    public function insertSingleLeave(
        $dbo, $CourseCode, $studentId, $leaveReason,
        $startDate, $endDate, $totalDays, $hospitalName, $description, $fileName
    ) {
        // Get course_id
        $stmt = $dbo->conn->prepare(
            "SELECT id FROM course_details WHERE course_code = :courseCode LIMIT 1"
        );
        $stmt->execute([":courseCode" => $CourseCode]);
        $row      = $stmt->fetch(PDO::FETCH_ASSOC);
        $courseId = $row ? $row['id'] : null;

        if (!$courseId) {
            throw new Exception("Course not found for code: $CourseCode");
        }

        // Get faculty_id from course_allotment
        $stmt = $dbo->conn->prepare(
            "SELECT faculty_id FROM course_allotment WHERE course_id = :courseId LIMIT 1"
        );
        $stmt->execute([":courseId" => $courseId]);
        $allot     = $stmt->fetch(PDO::FETCH_ASSOC);
        $facultyId = $allot ? $allot['faculty_id'] : null;

        $this->_insertRow(
            $dbo, $studentId, $facultyId, $courseId,
            $leaveReason, $startDate, $endDate, $totalDays,
            $hospitalName, $description, $fileName
        );
    }

    // ─────────────────────────────────────────────────────────
    // Insert single leave by course ID (NEW — subject-card path)
    // Looks up faculty_id from course_allotment by course_id
    // ─────────────────────────────────────────────────────────
    public function insertSingleLeaveById(
        $dbo, $courseId, $studentId, $leaveReason,
        $startDate, $endDate, $totalDays, $hospitalName, $description, $fileName
    ) {
        // Get faculty_id from course_allotment
        $stmt = $dbo->conn->prepare(
            "SELECT faculty_id FROM course_allotment WHERE course_id = :courseId LIMIT 1"
        );
        $stmt->execute([":courseId" => $courseId]);
        $allot     = $stmt->fetch(PDO::FETCH_ASSOC);
        $facultyId = $allot ? $allot['faculty_id'] : null;

        $this->_insertRow(
            $dbo, $studentId, $facultyId, $courseId,
            $leaveReason, $startDate, $endDate, $totalDays,
            $hospitalName, $description, $fileName
        );
    }

    // ─────────────────────────────────────────────────────────
    // Fetch recent leaves for a student (last 7 days)
    // ─────────────────────────────────────────────────────────
    public function fetchLeaves($dbo, $studentId) {
        $rv  = [];
        $cmd = "SELECT
                    cd.course_code,
                    cd.course_title,
                    fd.name,
                    lr.status,
                    lr.start_date,
                    lr.end_date
                FROM leave_requests AS lr
                INNER JOIN course_details  AS cd ON lr.course_id  = cd.id
                INNER JOIN faculty_details AS fd ON lr.faculty_id = fd.id
                WHERE lr.student_id = :student_id
                  AND lr.applied_at >= CURRENT_DATE - INTERVAL 7 DAY
                ORDER BY lr.applied_at DESC";

        $s = $dbo->conn->prepare($cmd);
        try {
            $s->execute([":student_id" => $studentId]);
            $rv = $s->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $th) {
            // silent — caller gets empty array
        }
        return $rv;
    }

    // ─────────────────────────────────────────────────────────
    // Get all leave details for faculty dashboard
    // ─────────────────────────────────────────────────────────
    public function getLeaveDetails($dbo, $facid) {
        try {
            $sql = "SELECT
                        lr.leave_id,
                        lr.leave_reason,
                        lr.start_date,
                        lr.end_date,
                        lr.total_days,
                        lr.hospital_name,
                        lr.description,
                        lr.attachment,
                        lr.status,
                        lr.applied_at,
                        s.name,
                        s.roll_no,
                        c.course_title,
                        c.course_code
                    FROM leave_requests lr
                    JOIN student_details s ON lr.student_id = s.id
                    JOIN course_details  c ON lr.course_id  = c.id
                    WHERE lr.faculty_id = :facid
                    ORDER BY lr.leave_id DESC";

            $stmt = $dbo->conn->prepare($sql);
            $stmt->execute([':facid' => $facid]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);

        } catch (Exception $e) {
            die("Database Error: " . $e->getMessage());
        }
    }
}
?>

