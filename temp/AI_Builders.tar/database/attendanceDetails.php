<?php
// attendanceDetails.php
// Changes from original:
//   • getAttendanceReport()                          — accepts $sectionid, filters students by section
//   • getAttendanceOfAClassByFacultyOnADateForExcel() — accepts $sectionid
//   • generateLMSExcelReport()                       — accepts $sectionid, adds "SECTION" row to Excel header
//   • CourseRegistrationDetails::getRegisteredStudents() — see courseRegistrationDetails.php

$path = $_SERVER['DOCUMENT_ROOT'];
require_once $path . "/AI_Builders/database/database.php";
require_once $path . "/AI_Builders/vendor/autoload.php";

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;

class attendanceDetails {

    // ─── Save attendance (unchanged) ──────────────────────────────────
    public function saveAttendance($dbo, $session, $course, $fac, $student, $ondate, $status) {
        $rv = [];
        $c  = "INSERT INTO attendance_details
                (faculty_id, course_id, session_id, student_id, on_date, status)
                VALUES (:faculty_id, :course_id, :session_id, :student_id, :on_date, :status)
                ON DUPLICATE KEY UPDATE status = VALUES(status)";
        $s = $dbo->conn->prepare($c);
        try {
            $s->execute([
                ":faculty_id" => $fac,   ":course_id"  => $course,
                ":session_id" => $session, ":student_id" => $student,
                ":on_date"    => $ondate, ":status"     => $status
            ]);
            $rv = ["state" => "success", "message" => "Attendance saved successfully."];
        } catch (Exception $e) {
            $rv = ["status" => "error", "message" => "Error saving/updating attendance: " . $e->getMessage()];
        }
        return $rv;
    }

    // ─── Get present students on a date (unchanged) ───────────────────
    public function getAttendanceOfAClassByFacultyOnADate($dbo, $session, $course, $fac, $ondate) {
        $rv = [];
        $c  = "SELECT student_id FROM attendance_details
               WHERE session_id = :sessionid AND course_id = :courseid
               AND faculty_id = :facid AND on_date = :ondate
               AND status IN ('YES','LEAVE')";
        $s = $dbo->conn->prepare($c);
        try {
            $s->execute([":sessionid" => $session, ":courseid" => $course, ":facid" => $fac, ":ondate" => $ondate]);
            $rv = $s->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            $rv = ["status" => "error", "message" => $e->getMessage()];
        }
        return $rv;
    }

    // ─── Full attendance report (NOW accepts $sectionid) ─────────────
    public function getAttendanceReport($dbo, $session, $course, $fac, $sectionid = null) {
        $report = [];
        $sessionName = ''; $facName = ''; $courseName = '';

        // Session name
        $s = $dbo->conn->prepare("SELECT * FROM session_details WHERE id = :id");
        try { $s->execute([":id" => $session]); $sd = $s->fetch(PDO::FETCH_ASSOC); $sessionName = $sd['year'] . " " . $sd['term']; } catch (Exception $e) {}

        // Faculty name
        $s = $dbo->conn->prepare("SELECT * FROM faculty_details WHERE id = :id");
        try { $s->execute([":id" => $fac]); $sd = $s->fetch(PDO::FETCH_ASSOC); $facName = $sd['name']; } catch (Exception $e) {}

        // Course name
        $s = $dbo->conn->prepare("SELECT * FROM course_details WHERE id = :id");
        try { $s->execute([":id" => $course]); $sd = $s->fetch(PDO::FETCH_ASSOC); $courseName = $sd['course_code'] . "-" . $sd['course_title']; } catch (Exception $e) {}

        // Section name
        $sectionName = 'All';
        if ($sectionid) {
            $s = $dbo->conn->prepare("SELECT section_name FROM section_details WHERE id = :id");
            try { $s->execute([":id" => $sectionid]); $sd = $s->fetch(PDO::FETCH_ASSOC); $sectionName = $sd['section_name']; } catch (Exception $e) {}
        }

        array_push($report, ["SESSION:", $sessionName]);
        array_push($report, ["COURSE:",  $courseName]);
        array_push($report, ["FACULTY:", $facName]);
        array_push($report, ["SECTION:", $sectionName]); // ← NEW

        // Total distinct dates
        $total = 0; $start = ''; $end = '';
        $cmd = "SELECT DISTINCT on_date FROM attendance_details
                WHERE session_id = :session_id AND course_id = :course_id AND faculty_id = :faculty_id
                ORDER BY on_date";
        $s = $dbo->conn->prepare($cmd);
        try {
            $s->execute([":session_id" => $session, ":course_id" => $course, ":faculty_id" => $fac]);
            $rv    = $s->fetchAll(PDO::FETCH_ASSOC);
            $total = count($rv);
            if ($total > 0) { $start = $rv[0]['on_date']; $end = $rv[$total - 1]['on_date']; }
        } catch (Exception $e) {}

        array_push($report, ["total" => $total]);
        array_push($report, ["start" => $start]);
        array_push($report, ["end"   => $end]);

        // Students registered in this section ← CHANGED
        $sectionJoin = $sectionid
            ? "AND crd.section_id = :section_id"
            : "";

        $cmd = "SELECT rsd.id, rsd.roll_no, rsd.name, COUNT(ad.on_date) AS attended
                FROM (
                    SELECT sd.id, sd.roll_no, sd.name, crd.session_id, crd.course_id
                    FROM student_details AS sd
                    JOIN course_registration AS crd ON sd.id = crd.student_id
                    WHERE crd.session_id = :session_id AND crd.course_id = :course_id
                    {$sectionJoin}
                ) AS rsd
                LEFT JOIN attendance_details AS ad
                    ON rsd.id = ad.student_id
                    AND rsd.session_id = ad.session_id
                    AND rsd.course_id  = ad.course_id
                    AND ad.status IN ('YES','LEAVE')
                    AND ad.faculty_id = :faculty_id
                GROUP BY rsd.id";

        $s = $dbo->conn->prepare($cmd);
        try {
            $params = [":session_id" => $session, ":course_id" => $course, ":faculty_id" => $fac];
            if ($sectionid) $params[":section_id"] = $sectionid;
            $s->execute($params);
            $rv = $s->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) { $rv = []; }

        for ($i = 0; $i < count($rv); $i++) {
            $rv[$i]['percent'] = ($total > 0) ? round(($rv[$i]['attended'] / $total) * 100.0, 2) : 0.0;
        }

        array_push($report, ["SR NO", "ROLL NO", "FULL NAME", "ATTENDED", "ATTENDANCE PERCENTAGE"]);
        return array_merge($report, $rv);
    }

    // ─── Today's Excel (NOW accepts $sectionid) ───────────────────────
    public function getAttendanceOfAClassByFacultyOnADateForExcel($dbo, $session, $course, $fac, $ondate, $sectionid = null) {
        $rv = [];
        require_once $_SERVER['DOCUMENT_ROOT'] . "/AI_Builders/database/courseRegistrationDetails.php";
        $crgo     = new CourseRegistrationDetails();
        $students = $crgo->getRegisteredStudents($dbo, $session, $course, $sectionid); // ← section filter
        $present  = $this->getAttendanceOfAClassByFacultyOnADate($dbo, $session, $course, $fac, $ondate);
        $presentIds = array_column($present, 'student_id');

        foreach ($students as $student) {
            $status = in_array($student['id'], $presentIds) ? "PRESENT" : "ABSENT";
            $rv[]   = [$student['roll_no'], $student['name'], $status];
        }
        array_unshift($rv, ["ROLL NO", "NAME", "STATUS"]);
        array_unshift($rv, ["DATE", $ondate, ""]);
        return $rv;
    }

    // ─── One student's attendance (unchanged) ─────────────────────────
    public function getAttendanceOfOneStudent($dbo, $student) {
        $rv  = [];
        $sql = "
            SELECT cd.id AS course_id, cd.course_title AS course_name, cd.course_code,
                   (COUNT(DISTINCT tt.day_of_week) * 16) AS total_classes,
                   COUNT(DISTINCT CASE WHEN ad.student_id = :studentid AND ad.status IN ('YES','LEAVE') THEN ad.on_date END) AS attended_classes
            FROM course_registration cr
            INNER JOIN course_details cd ON cd.id = cr.course_id
            LEFT  JOIN time_table tt     ON tt.course_id = cd.id
            LEFT  JOIN attendance_details ad ON ad.course_id = cd.id AND ad.student_id = :studentid
            WHERE cr.student_id = :studentid
            GROUP BY cd.id ORDER BY cd.course_title ASC";
        try {
            $stmt = $dbo->conn->prepare($sql);
            $stmt->execute([":studentid" => $student]);
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($data as &$row) {
                $row['attendance_percentage'] = ($row['total_classes'] > 0)
                    ? round(($row['attended_classes'] / $row['total_classes']) * 100, 2)
                    : 0;
            }
            $rv = $data;
        } catch (Exception $e) {
            $rv = ["status" => "error", "message" => "Error: " . $e->getMessage()];
        }
        return $rv;
    }

    // ─── Faculty present count by date (unchanged) ────────────────────
    public function getAttendanceOfAClassByFacultyIDOnADate($dbo, $fac, $ondate) {
        $rv = [];
        $c  = "SELECT COUNT(DISTINCT student_id) AS present_students
               FROM attendance_details
               WHERE faculty_id = :facid AND on_date = :ondate AND status IN ('YES','LEAVE')";
        $s = $dbo->conn->prepare($c);
        try {
            $s->execute([":facid" => $fac, ":ondate" => $ondate]);
            $rv = $s->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            $rv = ["status" => "error", "message" => $e->getMessage()];
        }
        return $rv;
    }

    // ─── Helper: column letter ─────────────────────────────────────────
    private function columnLetter($colNumber) {
        $letter = '';
        while ($colNumber > 0) {
            $mod    = ($colNumber - 1) % 26;
            $letter = chr(65 + $mod) . $letter;
            $colNumber = (int)(($colNumber - $mod) / 26);
        }
        return $letter;
    }

    // ─── LMS Excel report (NOW accepts $sectionid, adds SECTION row) ──
    public function generateLMSExcelReport($dbo, $session, $courseId, $fac, $sectionid = null) {
        $path = $_SERVER['DOCUMENT_ROOT'];

        // 1. Meta info
        $stmt = $dbo->conn->prepare("SELECT year, term FROM session_details WHERE id = :id");
        $stmt->execute([":id" => $session]);
        $sd = $stmt->fetch(PDO::FETCH_ASSOC);
        $sessionName = $sd ? $sd['year'] . " " . $sd['term'] : "N/A";

        $stmt = $dbo->conn->prepare("SELECT name FROM faculty_details WHERE id = :id");
        $stmt->execute([":id" => $fac]);
        $fd = $stmt->fetch(PDO::FETCH_ASSOC);
        $facultyName = $fd ? $fd['name'] : "N/A";

        $stmt = $dbo->conn->prepare("SELECT course_code, course_title FROM course_details WHERE id = :id");
        $stmt->execute([":id" => $courseId]);
        $cd = $stmt->fetch(PDO::FETCH_ASSOC);
        $courseName = $cd ? $cd['course_code'] . "-" . $cd['course_title'] : "N/A";

        // Section name ← NEW
        $sectionName = "All Sections";
        if ($sectionid) {
            $stmt = $dbo->conn->prepare("SELECT section_name FROM section_details WHERE id = :id");
            $stmt->execute([":id" => $sectionid]);
            $sec = $stmt->fetch(PDO::FETCH_ASSOC);
            $sectionName = $sec ? "Section " . $sec['section_name'] : "N/A";
        }

        // 2. Distinct dates
        $stmt = $dbo->conn->prepare("
            SELECT DISTINCT on_date FROM attendance_details
            WHERE session_id = :session AND course_id = :course AND faculty_id = :fac
            ORDER BY on_date ASC");
        $stmt->execute([":session" => $session, ":course" => $courseId, ":fac" => $fac]);
        $dates        = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $totalClasses = count($dates);

        // 3. Registered students (filtered by section) ← CHANGED
        $sectionJoin  = $sectionid ? "AND cr.section_id = :sectionid" : "";
        $studentSql   = "SELECT sd.id, sd.roll_no, sd.name
                         FROM student_details sd
                         JOIN course_registration cr ON sd.id = cr.student_id
                         WHERE cr.session_id = :session AND cr.course_id = :course
                         {$sectionJoin}";
        $stmt = $dbo->conn->prepare($studentSql);
        $sparams = [":session" => $session, ":course" => $courseId];
        if ($sectionid) $sparams[":sectionid"] = $sectionid;
        $stmt->execute($sparams);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 4. Spreadsheet
        $spreadsheet = new Spreadsheet();
        $sheet       = $spreadsheet->getActiveSheet();

        // 5. Header rows (now 5 rows: adds SECTION) ← CHANGED
        $lastCol = $this->columnLetter(5 + $totalClasses);

        $headerRows = [
            1 => "SESSION: $sessionName",
            2 => "COURSE: $courseName",
            3 => "FACULTY: $facultyName",
            4 => "SECTION: $sectionName",   // ← NEW row
            5 => "TOTAL CLASSES: $totalClasses"
        ];
        foreach ($headerRows as $r => $val) {
            $sheet->mergeCells("A{$r}:{$lastCol}{$r}")->setCellValue("A{$r}", $val);
            $sheet->getStyle("A{$r}")->getFont()->setBold(true);
            $sheet->getStyle("A{$r}")->getAlignment()
                ->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER)
                ->setVertical(\PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER);
        }

        // 6. Table header (now at row 6) ← CHANGED (was 5)
        $rowHeader = 6;
        $sheet->setCellValue("A$rowHeader", "SR NO")
              ->setCellValue("B$rowHeader", "ROLL NO")
              ->setCellValue("C$rowHeader", "FULL NAME")
              ->setCellValue("D$rowHeader", "ATTENDED")
              ->setCellValue("E$rowHeader", "%");

        $col = 6;
        foreach ($dates as $d) {
            $sheet->setCellValue($this->columnLetter($col) . $rowHeader, $d);
            $col++;
        }

        // Style column header row
        $sheet->getStyle("A{$rowHeader}:{$lastCol}{$rowHeader}")->getFont()->setBold(true);
        $sheet->getStyle("A{$rowHeader}:{$lastCol}{$rowHeader}")->getFill()
            ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('D0D8E8');

        // 7. Student data rows
        $rowNumber = $rowHeader + 1;
        $sr = 1;

        foreach ($students as $student) {
            $sheet->setCellValue("A$rowNumber", $sr)
                  ->setCellValue("B$rowNumber", $student['roll_no'])
                  ->setCellValue("C$rowNumber", $student['name']);

            $attended = 0;
            $col      = 6;

            foreach ($dates as $d) {
                $stmt = $dbo->conn->prepare("
                    SELECT status FROM attendance_details
                    WHERE session_id = :session AND course_id = :course
                    AND faculty_id = :fac AND student_id = :student AND on_date = :date");
                $stmt->execute([
                    ":session" => $session, ":course" => $courseId,
                    ":fac"     => $fac,     ":student" => $student['id'],
                    ":date"    => $d
                ]);
                $data  = $stmt->fetch(PDO::FETCH_ASSOC);
                $value = 0;
                $cell  = $this->columnLetter($col) . $rowNumber;

                if ($data) {
                    if ($data['status'] == "YES") {
                        $value = 1; $attended++;
                        $sheet->getStyle($cell)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('00FF00');
                    } elseif ($data['status'] == "LEAVE") {
                        $value = 1; $attended++;
                        $sheet->getStyle($cell)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('FFFF00');
                    } else {
                        $sheet->getStyle($cell)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('FF0000');
                    }
                } else {
                    $sheet->getStyle($cell)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('FF0000');
                }

                $sheet->setCellValue($cell, $value);
                $sheet->getStyle($cell)->getAlignment()
                    ->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER)
                    ->setVertical(\PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER);
                $col++;
            }

            $sheet->setCellValue("D$rowNumber", $attended);
            $percent = ($totalClasses > 0) ? round(($attended / $totalClasses) * 100, 2) : 0;
            $sheet->setCellValue("E$rowNumber", $percent);

            $rowNumber++;
            $sr++;
        }

        // 8. Auto-fit columns
        for ($i = 1; $i <= 5 + $totalClasses; $i++) {
            $sheet->getColumnDimension($this->columnLetter($i))->setAutoSize(true);
        }

        // 9. Freeze header (now row 7) ← CHANGED
        $sheet->freezePane('A7');

        // 10. Save
        $filename = "/AI_Builders/reports/LMS_Report_" . time() . ".xlsx";
        $writer   = new Xlsx($spreadsheet);
        $writer->save($path . $filename);

        return $filename;
    }
}
?>
