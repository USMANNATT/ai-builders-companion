$(document).ready(function () {

    // ===============================
    // ACTIVITY LOG FUNCTION
    // ===============================
    function logActivityJS(module, action, status, role) {
        $.ajax({
            url: '/AI_Builders/ajaxhandler/log_activity_ajax.php',
            type: 'POST',
            data: {
                module: module,
                action: action,
                status: status,
                role: role
            },
            success: function(res) {
                console.log('Activity Logged:', res);
            },
            error: function(err) {
                console.error('Activity Logging Failed:', err);
            }
        });
    }

    // ===============================
    // UTILITY FUNCTIONS
    // ===============================

    function renderFeedbackTable(feedbacks) {
        const tbody = $("table tbody");
        tbody.empty();

        feedbacks.forEach((fb, index) => {
            const stars = "★".repeat(fb.rating) + "☆".repeat(5 - fb.rating);
            const row = `
                <tr>
                    <td data-label="ID"><strong>${index + 1}</strong></td>
                    <td data-label="Name">${fb.name || fb.student_name}</td>
                    <td data-label="Email">${fb.email}</td>
                    <td data-label="Roll"><span class="roll-no">${fb.roll_no}</span></td>
                    <td data-label="Section">B</td>
                    <td data-label="Rating"><span class="rating-stars">${stars}</span></td>
                    <td data-label="Message" class="message-cell">${fb.feedback_message}</td>
                    <td data-label="Date">${fb.created_at}</td>
                </tr>
            `;
            tbody.append(row);
        });
    }

    function updateTotalCount(count) {
        $(".content h3 strong").text(count);
    }

    // ===============================
    // FACULTY VIEW FEEDBACK
    // ===============================
    function fetchFeedback(facid) {
        if (!facid) return;

        $.ajax({
            url: "/AI_Builders/ajaxhandler/feedbackAjax.php",
            type: "POST",
            dataType: "json",
            data: { action: "getFacultyFeedback", faculty_id: facid },
            success: function (response) {

                if (response.status && response.data.length > 0) {
                    renderFeedbackTable(response.data);
                    updateTotalCount(response.data.length);

                    // ✅ LOG: Faculty viewed feedback
                    logActivityJS(
                        "Feedback Page",
                        `Viewed ${response.data.length} feedback entries`,
                        "Completed",
                        "Faculty"
                    );

                } else {
                    $("table tbody").html('<tr><td colspan="8">No feedback found</td></tr>');
                    updateTotalCount(0);

                    // ✅ LOG: Faculty viewed feedback but none found
                    logActivityJS(
                        "Feedback Page",
                        "Viewed feedback (No feedback found)",
                        "Completed",
                        "Faculty"
                    );
                }
            },
            error: function () {
                console.error("Failed to load feedback");

                // ❌ LOG: Error loading feedback
                logActivityJS(
                    "Feedback Page",
                    "Failed to load feedback",
                    "Failed",
                    "Faculty"
                );
            }
        });
    }

    // ===============================
    // FETCH COURSE NAME (No logging needed)
    // ===============================
    function fetchCourseName(course_id) {
        if (!course_id) return;

        $.ajax({
            url: "/AI_Builders/ajaxhandler/dashboardAjax.php",
            type: "POST",
            dataType: "json",
            data: { action: "getSubjectName", course_id: course_id },
            success: function (response) {
                if (response.course_title) {
                    $("#categoryText").val(response.course_title + " Instructor");
                    $(document).attr("title", response.course_title + " Feedback");
                }
            }
        });
    }

    // ===============================
    // STUDENT SUBMIT FEEDBACK
    // ===============================
    if ($("#feedbackForm").length) {

        $("#feedbackForm").on("submit", function (e) {
            e.preventDefault();

            const form = this;
            const formData = new FormData(form);
            formData.append("action", "submitFeedback");

            const course_id = new URLSearchParams(window.location.search).get("course_id");
            if (course_id) formData.append("course_id", course_id);

            $.ajax({
                url: "/AI_Builders/ajaxhandler/feedbackAjax.php",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                dataType: "json",

                success: function (response) {

                    if (response.status === "success") {

                        alert(response.message);

                        // ✅ LOG: Student submitted feedback
                        logActivityJS(
                            "Feedback Page",
                            `Submitted feedback for course ID ${course_id}`,
                            "Completed",
                            "Student"
                        );

                        $("#feedbackForm")[0].reset();

                    } else {

                        alert(response.message || "Failed to submit feedback");

                        // ❌ LOG: Submission failed
                        logActivityJS(
                            "Feedback Page",
                            `Failed to submit feedback for course ID ${course_id}`,
                            "Failed",
                            "Student"
                        );
                    }
                },

                error: function () {

                    console.error("Server error during feedback submission");

                    // ❌ LOG: AJAX failure
                    logActivityJS(
                        "Feedback Page",
                        `AJAX error during feedback submission for course ID ${course_id}`,
                        "Failed",
                        "Student"
                    );
                }
            });
        });
    }

    // ===============================
    // INITIALIZATION
    // ===============================

    // Faculty View Page
    const facid = $("#hiddenFacId").val();
    if (facid) {
        fetchFeedback(facid);
    }

    // Course Name (Student Page)
    const course_id = new URLSearchParams(window.location.search).get("course_id");
    if (course_id) {
        fetchCourseName(course_id);
    }

});
