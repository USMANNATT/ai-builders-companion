
/* =============================================================
   adminLogout.js — Admin Logout Handler
   AI Builders Admin Dashboard
============================================================= */

$(document).ready(function () {

    /* ---------------------------------------------------------
       Top-right logout button click
    ---------------------------------------------------------- */
    $(document).on('click', '#topLogoutBtn', function () {

        const confirmed = confirm('Are you sure you want to logout?');
        if (!confirmed) return;

        // Visual feedback on the button
        const btn = $(this);
        btn.text('Logging out...').prop('disabled', true);

        $.ajax({
            url:      '/AI_Builders/ajaxhandler/adminLogoutAjax.php',
            type:     'POST',
            dataType: 'json',
            data:     { action: 'adminLogout' },

            success: function (response) {
                if (response.status === 'ALLOK') {
                    // Redirect to login after session is destroyed
                    window.location.replace('/AI_Builders/login.php');
                } else {
                    alert('Logout failed. Please try again.');
                    btn.html('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg> Logout');
                    btn.prop('disabled', false);
                }
            },

            error: function (xhr, status, error) {
                console.error('Logout AJAX Error:', status, '/', error);
                alert('Something went wrong. Please try again.');
                btn.html('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg> Logout');
                btn.prop('disabled', false);
            }
        });
    });

});
