<?php
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../config/firebase_config.php';

use Google\Auth\Credentials\ServiceAccountCredentials;

function getFcmAccessToken(): string {
    $credentials = new ServiceAccountCredentials(
        'https://www.googleapis.com/auth/firebase.messaging',
        json_decode(file_get_contents(FCM_SERVICE_ACCOUNT_PATH), true)
    );
    $token = $credentials->fetchAuthToken();
    return $token['access_token'];
}

function buildFcmPayload(string $token, string $title, string $body, string $url = '/AI_Builders/', string $type = 'general'): array {
    return [
        'message' => [
            'token' => $token,
            'notification' => [
                'title' => $title,
                'body'  => $body,
            ],
            'data' => [
                'url'  => $url,
                'type' => $type,
            ],
            'webpush' => [
                'headers' => ['Urgency' => 'high'],
                'notification' => [
                    'icon'  => '/AI_Builders/assets/images/logo.png',
                    'badge' => '/AI_Builders/assets/images/logo.png',
                    'vibrate' => [200, 100, 200],
                ],
                'fcm_options' => ['link' => $url]
            ],
        ]
    ];
}

function sendFcmNotification(string $token, string $title, string $body, string $url = '/AI_Builders/', string $type = 'general'): array {
    $accessToken = getFcmAccessToken();
    $payload     = buildFcmPayload($token, $title, $body, $url, $type);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => FCM_ENDPOINT,
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $responseBody = curl_exec($ch);
    $httpCode     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError    = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        return ['success' => false, 'error' => 'cURL error: ' . $curlError];
    }

    $response = json_decode($responseBody, true);

    if ($httpCode === 200) {
        return ['success' => true, 'response' => $response];
    }

    $errorCode = $response['error']['details'][0]['errorCode'] ?? '';
    if (in_array($errorCode, ['UNREGISTERED', 'INVALID_ARGUMENT'])) {
        return ['success' => false, 'error' => 'TOKEN_EXPIRED', 'token' => $token];
    }

    return ['success' => false, 'error' => $response['error']['message'] ?? 'Unknown error'];
}