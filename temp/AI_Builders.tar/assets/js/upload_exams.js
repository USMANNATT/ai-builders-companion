$(document).ready(function () {

    // =========================
    // ACTIVITY LOG FUNCTION
    // =========================
    function logActivityJS(module, action, status, role) {
        $.ajax({
            url: '/AI_Builders/ajaxhandler/log_activity_ajax.php',
            type: 'POST',
            data: { module, action, status, role },
            success: function (res) { console.log('Activity Logged:', res); },
            error:   function (err) { console.error('Activity Logging Failed:', err); }
        });
    }

    const facid = $("#hiddenFacultyId").val();

    // ===============================
    // FETCH COURSES OF FACULTY
    // ===============================
    $.ajax({
        url:      '/AI_Builders/ajaxhandler/resourceAJAX.php',
        type:     'POST',
        dataType: 'json',
        data:     { action: 'getCourses', facid: facid },
        success: function (rv) {
            let x = '<option value="">Select Course</option>';
            rv.forEach(course => {
                x += `<option value="${course.id}">${course.course_code} - ${course.course_title}</option>`;
            });
            $("#courseId").html(x);
            logActivityJS('Exam Upload Page', 'Fetched Courses for Faculty', 'Completed', 'Faculty');
        },
        error: function (e) {
            alert('Error fetching courses');
            console.error(e);
        }
    });

    // ===============================
    // SUBMIT EXAM RESULTS FORM
    // ===============================
    $("#examUploadForm").on("submit", function (e) {
        e.preventDefault();

        const $submitBtn = $(this).find('[type="submit"]');
        $submitBtn.prop('disabled', true).text('Uploading…');

        const formData = new FormData(this);
        formData.append('hiddenFacId', $("#hiddenFacultyId").val());
        formData.append('course_id',   $("#courseId").val());      // needed for email lookup
        formData.append('action',      'uploadResults');

        $.ajax({
            url:         '/AI_Builders/ajaxhandler/upload_results_Ajax.php',
            type:        'POST',
            data:        formData,
            processData: false,
            contentType: false,

            success: function (response) {
                $submitBtn.prop('disabled', false).text('Upload');
                console.log('Full Response:', response);

                // Parse if response came back as string
                if (typeof response === 'string') {
                    try {
                        response = JSON.parse(response);
                    } catch (e) {
                        alert('Invalid JSON response from server:\n\n' + response);
                        return;
                    }
                }

                // ── Validation / row errors ──────────────────────────
                if (response.errors && Array.isArray(response.errors)) {
                    let errorMessage = 'Errors:\n\n';
                    response.errors.forEach(err => { errorMessage += '• ' + err + '\n'; });
                    alert(errorMessage);

                    logActivityJS(
                        'Exam Upload Page',
                        'Attempted to upload results',
                        'Failed',
                        'Faculty'
                    );

                // ── Success ──────────────────────────────────────────
                } else if (response.status === true && response.message) {

                    alert(`✅ ${response.message}`);

                    logActivityJS(
                        'Exam Upload Page',
                        `Uploaded results for course ID ${$("#courseId").val()}.`,
                        'Completed',
                        'Faculty'
                    );

                    // Reset form after successful upload
                    $("#examUploadForm")[0].reset();

                // ── Unexpected ───────────────────────────────────────
                } else {
                    alert('Unexpected response from server.');
                    logActivityJS(
                        'Exam Upload Page',
                        'Unexpected server response during results upload',
                        'Failed',
                        'Faculty'
                    );
                }
            },

            error: function (xhr, status, error) {
                $submitBtn.prop('disabled', false).text('Upload');
                console.log('AJAX Error:', xhr);
                console.log('Status:', status);
                console.log('Error:', error);

                alert(
                    'AJAX Request Failed!\n\n' +
                    'Status: ' + status + '\n' +
                    'Error: '  + error  + '\n\n' +
                    'Server Response:\n' + xhr.responseText
                );

                logActivityJS(
                    'Exam Upload Page',
                    'AJAX request failed during results upload',
                    'Failed',
                    'Faculty'
                );
            }
        });
    });

});
