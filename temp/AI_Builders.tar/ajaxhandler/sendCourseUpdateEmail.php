<?php
/**
 * sendCourseUpdateEmail.php
 * ─────────────────────────────────────────────────────────────
 * Reusable helper: fetches every student enrolled in a course
 * (via course_registration) and sends them an HTML email using
 * PHPMailer + Hostinger SMTP.
 *
 * Usage:
 *   require_once 'sendCourseUpdateEmail.php';
 *   $result = sendCourseUpdateEmail($dbo, $course_id, $update_type, $update_message);
 *   // $result = ['sent' => n, 'failed' => n, 'errors' => [...]]
 * ─────────────────────────────────────────────────────────────
 */

$path = $_SERVER['DOCUMENT_ROOT'];
require_once $path . '/AI_Builders/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Fetch enrolled students + course name, then email every one of them.
 *
 * @param  object $dbo            Active Database object (uses $dbo->conn PDO connection)
 * @param  int    $course_id      The course that was just updated
 * @param  string $update_type    e.g. "General", "Assignment", "Exam" …
 * @param  string $update_message The message body typed by the faculty
 * @return array  ['sent' => int, 'failed' => int, 'errors' => string[]]
 */
function sendCourseUpdateEmail($dbo, int $course_id, string $update_type, string $update_message): array
{
    // ── 1. Pull enrolled students + course name from DB ──────────────────────
    try {
        $sql = "
            SELECT
                sd.name,
                sd.email,
                c.course_title,
                c.course_code
            FROM course_registration cr
            JOIN student_details     sd ON sd.id = cr.student_id
            JOIN course_details             c  ON c.id  = cr.course_id
            WHERE cr.course_id = :course_id
              AND sd.email IS NOT NULL
              AND sd.email <> ''
        ";

        $stmt = $dbo->conn->prepare($sql);
        $stmt->execute([':course_id' => $course_id]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        return [
            'sent'   => 0,
            'failed' => 0,
            'errors' => ['DB error: ' . $e->getMessage()],
        ];
    }

    if (empty($students)) {
        return [
            'sent'   => 0,
            'failed' => 0,
            'errors' => ['No enrolled students found for course_id ' . $course_id],
        ];
    }

    // ── 2. Shared SMTP config ────────────────────────────────────────────────
    $smtpHost    = 'smtp.hostinger.com';
    $smtpUser    = 'admin@aibuilderss.com';
    $smtpPass    = '!AvG2Ae5';   // ← replace with real password
    $smtpPort    = 587;
    $fromAddress = 'admin@aibuilderss.com';
    $fromName    = 'AI Builders';

    $sent   = 0;
    $failed = 0;
    $errors = [];

    // Course info is the same for every row in the result set
    $courseTitle = $students[0]['course_title'] ?? 'Course';
    $courseCode  = $students[0]['course_code']  ?? '';

    // Email subject: "CS101 - Web Development Updates"
    $subject = $courseCode . ' - ' . $courseTitle . ' Updates';

    // ── 3. Loop & send one email per student ─────────────────────────────────
    foreach ($students as $student) {

        $recipientEmail = trim($student['email']);
        $recipientName  = trim($student['name']);

        $htmlBody = buildEmailBody(
            $recipientName,
            $courseCode,
            $courseTitle,
            $update_type,
            $update_message
        );

        $mail = new PHPMailer(true);
        try {
            // SMTP settings
            $mail->isSMTP();
            $mail->Host          = $smtpHost;
            $mail->SMTPAuth      = true;
            $mail->Username      = $smtpUser;
            $mail->Password      = $smtpPass;
            $mail->SMTPSecure    = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port          = $smtpPort;
            $mail->Timeout       = 30;
            $mail->SMTPKeepAlive = false;
            $mail->SMTPDebug     = 0;   // set to 2 for verbose SMTP debug output

            // Sender & recipient
            $mail->setFrom($fromAddress, $fromName);
            $mail->addAddress($recipientEmail, $recipientName);

            // Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $htmlBody;
            $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>'], "\n", $htmlBody));

            $mail->send();
            $sent++;

        } catch (Exception $e) {
            $failed++;
            $errors[] = "Failed [{$recipientEmail}]: " . $mail->ErrorInfo;
        }

        $mail->clearAddresses();
    }

    return [
        'sent'   => $sent,
        'failed' => $failed,
        'errors' => $errors,
    ];
}


/**
 * Builds a clean, branded HTML email body.
 */
function buildEmailBody(
    string $studentName,
    string $courseCode,
    string $courseTitle,
    string $updateType,
    string $updateMessage
): string {

    $safeStudent = htmlspecialchars($studentName,  ENT_QUOTES, 'UTF-8');
    $safeCode    = htmlspecialchars($courseCode,   ENT_QUOTES, 'UTF-8');
    $safeTitle   = htmlspecialchars($courseTitle,  ENT_QUOTES, 'UTF-8');
    $safeType    = htmlspecialchars($updateType,   ENT_QUOTES, 'UTF-8');
    $safeMessage = nl2br(htmlspecialchars($updateMessage, ENT_QUOTES, 'UTF-8'));
    $date        = date('d M Y, h:i A');

    return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <style>
    body      { font-family: Arial, sans-serif; background:#f4f4f4; margin:0; padding:0; }
    .wrapper  { max-width:600px; margin:30px auto; background:#fff; border-radius:8px;
                overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,.1); }
    .header   { background:#1a1a2e; color:#fff; padding:24px 32px; }
    .header h1{ margin:0; font-size:20px; }
    .header p { margin:4px 0 0; font-size:13px; opacity:.8; }
    .badge    { display:inline-block; background:#e94560; color:#fff; border-radius:4px;
                padding:4px 12px; font-size:12px; font-weight:bold; text-transform:uppercase; }
    .body     { padding:28px 32px; color:#333; line-height:1.7; }
    .message  { background:#f8f8f8; border-left:4px solid #1a1a2e; border-radius:4px;
                padding:14px 18px; font-size:15px; margin:16px 0; white-space:pre-wrap; }
    .footer   { padding:16px 32px; background:#f0f0f0; font-size:12px; color:#888;
                text-align:center; }
  </style>
</head>
<body>
  <div class="wrapper">

    <div class="header">
      <h1>AI Builders — Course Update</h1>
      <p>{$safeCode} &nbsp;·&nbsp; {$safeTitle}</p>
    </div>

    <div class="body">
      <p>Dear <strong>{$safeStudent}</strong>,</p>
      <p>Your instructor has posted a new update for your course:</p>

      <span class="badge">{$safeType}</span>

      <div class="message">{$safeMessage}</div>

      <p>Log in to the portal to view the update in detail.</p>
      <a href="https://aibuilderss.com" class="cta">Go to Portal →</a>
      <p>Best regards,<br><strong>AI Builders Team</strong></p>
    </div>

    <div class="footer">
      Sent on {$date} &nbsp;|&nbsp; This is an automated notification — please do not reply.
    </div>

  </div>
</body>
</html>
HTML;
}
?>