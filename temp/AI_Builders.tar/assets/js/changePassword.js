/**
 * changePassword.js  (inline)
 * ─────────────────────────────────────────────────────────────
 * Handles the change-password form:
 *   • Real-time password strength indicator
 *   • Confirm-password match check
 *   • Full-screen themed loader overlay during AJAX request
 *   • Inline feedback box (no alert())
 *   • AJAX POST to loginAjax.php with action=changePassword
 */
(function ($) {
    'use strict';

    /* ── Cache DOM references ───────────────────────────────── */
    var un        = $('#cpUsername');       // username input
    var curPw     = $('#cpCurrentPw');      // current password input
    var newPw     = $('#cpNewPw');          // new password input
    var confPw    = $('#cpConfirmPw');      // confirm password input
    var submitBtn = $('#cpSubmit');         // update button
    var feedback  = $('#cpFeedback');       // inline feedback div
    var strengthF = $('#strengthFill');     // coloured strength bar fill
    var strengthL = $('#strengthLabel');    // strength label text
    var loader    = $('#cpLoader');         // full-screen loader overlay
    var loaderSt  = $('#cpLoaderStatus');   // status text inside loader card

    /* ── Bind events ────────────────────────────────────────── */

    // Re-evaluate form state on any input change
    $('input').on('input keyup', function () {
        updateStrength();   // refresh the strength bar when new-pw changes
        updateButton();     // enable / disable the submit button
        feedback.hide();    // dismiss stale error messages while user types
    });

    // Toggle show/hide for each password field via its eye button
    $(document).on('click', '.cp-toggle', function () {
        var targetId = $(this).data('target');          // e.g. "cpNewPw"
        var input    = $('#' + targetId);
        var isHidden = input.attr('type') === 'password';
        input.attr('type', isHidden ? 'text' : 'password');
        $(this).find('i')
               .toggleClass('fa-eye',       !isHidden)
               .toggleClass('fa-eye-slash',  isHidden);
    });

    // Wire up the submit button
    submitBtn.on('click', handleSubmit);

    /* ── Password strength metre ────────────────────────────── */

    /**
     * Scores the new-password field on 0–4 criteria and updates
     * the strength bar colour and label accordingly.
     */
    function updateStrength() {
        var pw    = newPw.val();    // value currently typed in the new-password field
        var score = 0;              // running strength score

        // Reset bar when field is empty
        if (pw.length === 0) {
            strengthF.css({ width: '0%', background: '#E5E7EB' });
            strengthL.text('Password strength').css('color', '#9CA3AF');
            return;
        }

        // Score each criterion (+1 each)
        if (pw.length >= 8)           score++;   // at least 8 characters
        if (/[A-Z]/.test(pw))         score++;   // at least one uppercase letter
        if (/[0-9]/.test(pw))         score++;   // at least one digit
        if (/[^A-Za-z0-9]/.test(pw))  score++;   // at least one special character

        // Map final score to visual bar properties
        var levels = [
            { width:'25%',  color:'#EF4444', label:'Weak'   },
            { width:'50%',  color:'#F97316', label:'Fair'   },
            { width:'75%',  color:'#EAB308', label:'Good'   },
            { width:'100%', color:'#22C55E', label:'Strong' }
        ];
        var level = levels[score - 1] || levels[0];   // clamp to valid index

        // Apply the calculated colour and width to the bar fill element
        strengthF.css({ width: level.width, background: level.color });
        strengthL.text(level.label).css('color', level.color);
    }

    /* ── Button enable / disable ────────────────────────────── */

    /**
     * The submit button is active only when:
     *   • all four fields are non-empty, AND
     *   • newPassword === confirmPassword
     */
    function updateButton() {
        var allFilled = (
            un.val().trim()     !== '' &&
            curPw.val().trim()  !== '' &&
            newPw.val().trim()  !== '' &&
            confPw.val().trim() !== ''
        );
        var match = (newPw.val() === confPw.val());   // passwords match check

        if (allFilled && match) {
            // Enable — matches the visual class used in the existing CSS
            submitBtn.removeClass('inactive').addClass('active').prop('disabled', false);
        } else {
            // Disable
            submitBtn.removeClass('active').addClass('inactive').prop('disabled', true);
        }
    }

    /* ── Submit handler ─────────────────────────────────────── */

    /**
     * Validates inputs client-side, shows the loader, then fires the AJAX
     * POST to change the password. On success the loader turns green before
     * redirecting; on failure it is hidden and an inline error is shown.
     */
    function handleSubmit() {

        /* ── 1. Read & trim all field values ── */
        var username    = un.val().trim();
        var currentPw   = curPw.val().trim();
        var newPassword = newPw.val().trim();
        var confirmPw   = confPw.val().trim();

        /* ── 2. Client-side validation ── */

        // Minimum password length check (server also enforces this)
        if (newPassword.length < 8) {
            showFeedback('err', 'New password must be at least 8 characters.');
            return;
        }

        // Both new-password fields must agree
        if (newPassword !== confirmPw) {
            showFeedback('err', 'New passwords do not match. Please re-enter.');
            return;
        }

        // Prevent trivial "change" to the same password
        if (currentPw === newPassword) {
            showFeedback('err', 'New password must be different from your current password.');
            return;
        }

        /* ── 3. Lock the button & show the loader ── */
        var originalLabel = submitBtn.text();   // remember label for restore on error
        submitBtn.prop('disabled', true)
                 .removeClass('active')
                 .addClass('inactive')
                 .text('Updating…');            // simple text; no inline SVG needed

        feedback.hide();                        // dismiss any previous inline message
        showLoader('Updating your password…');  // reveal the overlay

        /* ── 4. AJAX POST ── */
        $.ajax({
            url:      '../ajaxhandler/loginAjax.php',  // unified PHP handler
            type:     'POST',                        // credentials in body, never in URL
            dataType: 'json',                        // always expect JSON back
            timeout:  15000,                         // 15-second hard timeout
            data: {
                action:       'changePassword',      // PHP switches on this key
                user_name:    username,              // identifies the user across all tables
                password:     currentPw,             // old password (server verifies first)
                new_password: newPassword            // new password to bcrypt-hash and store
            },

            /* ── Success callback ── */
            success: function (response) {

                if (response && response.status === 'ALLOK') {
                    /* ── Password changed successfully ── */

                    // Switch loader to success (green) state
                    loaderSt.text('Password updated! Redirecting to login…');
                    loader.addClass('is-success');

                    // Clear the sensitive fields from the DOM immediately
                    curPw.val('');
                    newPw.val('');
                    confPw.val('');

                    // After a brief moment redirect to the login page
                    setTimeout(function () {
                        window.location.replace('/AI_Builders/login.php');
                    }, 1200);   // 1.2 s — enough to read the green confirmation

                } else {
                    /* ── Server rejected the request ── */
                    var msg = (response && response.status)
                        ? response.status
                        : (response && response.message ? response.message : 'Password update failed.');

                    hideLoader();               // dismiss overlay
                    showFeedback('err', msg);   // show inline error
                    restoreButton(originalLabel);
                }
            },

            /* ── Error callback — network / timeout / 500 ── */
            error: function (xhr, status) {
                alert(status);
                alert(xhr.response);
                var msg = 'Unable to connect. Please try again.';
                if (status === 'timeout') msg = 'Request timed out. Please try again.';

                hideLoader();
                showFeedback('err', msg);
                restoreButton(originalLabel);
            }
        });
    }

    /* ── Loader helpers ─────────────────────────────────────── */

    /**
     * Shows the full-screen loader overlay.
     * @param {string} statusText - Message shown under the dots.
     */
    function showLoader(statusText) {
        loaderSt.text(statusText || 'Please wait…');   // set status label
        loader.removeClass('is-success');               // clear any previous success state
        loader.addClass('is-visible');                  // make overlay visible
    }

    /**
     * Hides the loader overlay and resets its state.
     */
    function hideLoader() {
        loader.removeClass('is-visible is-success');
    }

    /* ── Feedback helpers ───────────────────────────────────── */

    /**
     * Shows a coloured inline message in the feedback box.
     * @param {'err'|'ok'|'info'} type   - CSS modifier class
     * @param {string}            message - Text to display
     */
    function showFeedback(type, message) {
        feedback.removeClass('err ok info')
                .addClass(type)
                .text(message)
                .show();
    }

    /**
     * Restores the submit button text and re-evaluates its state.
     * @param {string} label - Original button label
     */
    function restoreButton(label) {
        submitBtn.text(label || 'Update Password');
        updateButton();   // re-enable if inputs still pass validation
    }

}(jQuery));