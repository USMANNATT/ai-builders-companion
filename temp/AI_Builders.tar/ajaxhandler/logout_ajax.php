<?php
// Start the session 
session_start();
// Remove the session data 
unset($_SESSION["current_user"]);
// Destroy the session
$rv=[];
// Check if the session is successfully destroyed
echo json_encode($rv);

?>