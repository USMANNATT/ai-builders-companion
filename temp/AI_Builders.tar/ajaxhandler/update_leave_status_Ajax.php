<?php
// ==============================
// SHOW ALL ERRORS
// =============================
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ==============================
// START SESSION AND SET HEADERS
// =============================
session_start();
header("Content-Type: application/json");

// Include database
require_once("../database/database.php");

// ==============================
// HELPER FUNCTION TO RETURN JSON ERROR
// =============================
function jsonError($message) {
    echo json_encode([
        "success" => false,
        "message" => $message
    ]);
    exit;
}

// ==============================
// CHECK AUTH
// =============================
if (!isset($_SESSION['current_user'])) {
    jsonError("Unauthorized");
}

// ==============================
// VALIDATE INPUT
// =============================
if (!isset($_POST['leave_id'], $_POST['status'])) {
    jsonError("Invalid request: leave_id or status missing");
}

$leaveId = $_POST['leave_id'];
$status  = $_POST['status'];
$facid   = $_SESSION['current_user'];

if (!in_array($status, ['approved', 'rejected'])) {
    jsonError("Invalid status");
}

try {
    $dbo = new Database();
    $dbo->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ==============================
    // UPDATE LEAVE STATUS
    // ==============================
    $sql = "UPDATE leave_requests 
            SET status = :status,
                reviewed_at = NOW(),
                reviewed_by = :facid
            WHERE leave_id = :leave_id";
    $stmt = $dbo->conn->prepare($sql);
    $stmt->execute([
        ":status" => $status,
        ":facid" => $facid,
        ":leave_id" => $leaveId
    ]);

    // ==============================
    // IF APPROVED, MARK ATTENDANCE
    // ==============================
    if ($status === 'approved') {

        // Get leave details
        
        $stmt = $dbo->conn->prepare("SELECT student_id, faculty_id, course_id, start_date, end_date FROM leave_requests WHERE leave_id = :leave_id");
        $stmt->execute([":leave_id" => $leaveId]);
        $leave = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$leave) jsonError("Leave not found");

        $student_id = $leave['student_id'];
        $faculty_id = $leave['faculty_id'];
        $course_id  = $leave['course_id'];

        // Get session
        $stmt = $dbo->conn->prepare("SELECT session_id FROM course_registration WHERE course_id = :courseId AND student_id = :studentId");
        $stmt->execute([":courseId"=>$course_id, ":studentId"=>$student_id]);
        $session = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$session) jsonError("Session not found for student/course");
        $session_id = $session['session_id'];

        // Date range
        $start = new DateTime($leave['start_date']);
        $end   = new DateTime($leave['end_date']);
        $end->modify('+1 day');
        $period = new DatePeriod($start, new DateInterval('P1D'), $end);

        // Prepare insert statement
        $insertStmt = $dbo->conn->prepare("
            INSERT INTO attendance_details
            (faculty_id, course_id, session_id, student_id, on_date, status)
            VALUES (:facultyid, :courseid, :sessionid, :studentid, :on_date, 'LEAVE')
            ON DUPLICATE KEY UPDATE status = 'LEAVE'
        ");

        $marked_days = [];
        $skipped_days = [];

        foreach ($period as $date) {
            $on_date = $date->format('Y-m-d');
            $day_of_week = strtoupper($date->format('l')); // MONDAY, TUESDAY, etc.

            // Check timetable
            $stmt = $dbo->conn->prepare("
                SELECT COUNT(*) as class_count 
                FROM time_table
                WHERE course_id = :courseId
                  AND faculty_id = :facultyId
                  AND session_id = :sessionId
                  AND day_of_week = :dayOfWeek
            ");
            $stmt->execute([
                ":courseId"  => $course_id,
                ":facultyId" => $faculty_id,
                ":sessionId" => $session_id,
                ":dayOfWeek" => $day_of_week
            ]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($row['class_count'] > 0) {
                $insertStmt->execute([
                    ":facultyid" => $faculty_id,
                    ":courseid"  => $course_id,
                    ":sessionid" => $session_id,
                    ":studentid" => $student_id,
                    ":on_date"   => $on_date
                ]); 
                $marked_days[] = $on_date;
            } else {
                $skipped_days[] = $on_date;
            }
        }

        // Return detailed result
        echo json_encode([
            "success" => true,
            "message" => "Leave approved and attendance updated",
            "attendance_marked" => $marked_days,
            "attendance_skipped" => $skipped_days
        ]);
        exit;
    }

    // If status is 'rejected', simple success
    echo json_encode([
        "success" => true,
        "message" => "Leave status updated to rejected"
    ]);

} catch (PDOException $e) {
    echo json_encode([
        "success" => false,
        "message" => "PDO Error: " . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "General Error: " . $e->getMessage()
    ]);
}
?>