<?php
// Session check is optional — this page is accessible without login
// (user proves identity by entering their current credentials)
// session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password — AI Builders</title>

    <!-- Favicons (same as login page) -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/favicon_io/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon_io/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon_io/favicon-16x16.png">
    <link rel="icon" href="assets/favicon_io/favicon.ico">

    <!-- Google Fonts + Icons (same as login page so styling is consistent) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="/AI_Builders/assets/css/changePassword.css">


    <style>

    </style>
</head>
<body>

<div class="cp-card">

    <!-- Back to login link -->
    <a href="/AI_Builders/login.php" class="cp-back">
        <i class="fas fa-arrow-left" style="font-size:0.75rem;"></i>
        Back to Login
    </a>

    <!-- Brand logo row -->
    <div class="cp-brand">
        <svg width="28" height="28" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="16" cy="16" r="16" fill="#4F46E5"/>
            <path d="M16 8L12 12H14V18H18V12H20L16 8Z" fill="white"/>
            <path d="M12 20H20V22H12V20Z" fill="white"/>
        </svg>
        <span class="cp-brand-name">AI Builders</span>
    </div>

    <!-- Page heading -->
    <div class="cp-heading">
        <h1>Change Password</h1>
        <p>Verify your identity, then set a new password.</p>
    </div>

    <!-- ── Inline feedback (replaces alert()) ── -->
    <div id="cpFeedback" class="cp-feedback" role="alert" aria-live="polite"></div>

    <!-- ── Form fields ── -->

    <!-- Username -->
    <div class="cp-group">
        <label for="cpUsername">Username</label>
        <input type="text" id="cpUsername" placeholder="Your username" autocomplete="username">
    </div>

    <!-- Current password -->
    <div class="cp-group">
        <label for="cpCurrentPw">Current Password</label>
        <div class="pw-wrap">
            <input type="password" id="cpCurrentPw" placeholder="Enter current password"
                   autocomplete="current-password">
            <button type="button" class="cp-toggle" data-target="cpCurrentPw" aria-label="Toggle visibility">
                <i class="fas fa-eye"></i>
            </button>
        </div>
    </div>

    <!-- New password + strength indicator -->
    <div class="cp-group">
        <label for="cpNewPw">New Password</label>
        <div class="pw-wrap">
            <input type="password" id="cpNewPw" placeholder="Min 8 characters"
                   autocomplete="new-password">
            <button type="button" class="cp-toggle" data-target="cpNewPw" aria-label="Toggle visibility">
                <i class="fas fa-eye"></i>
            </button>
        </div>
        <!-- Visual password strength indicator -->
        <div class="strength-bar"><div class="strength-fill" id="strengthFill"></div></div>
        <div class="strength-label" id="strengthLabel">Password strength</div>
    </div>

    <!-- Confirm new password -->
    <div class="cp-group">
        <label for="cpConfirmPw">Confirm New Password</label>
        <div class="pw-wrap">
            <input type="password" id="cpConfirmPw" placeholder="Repeat new password"
                   autocomplete="new-password">
            <button type="button" class="cp-toggle" data-target="cpConfirmPw" aria-label="Toggle visibility">
                <i class="fas fa-eye"></i>
            </button>
        </div>
    </div>

    <!-- Submit button (disabled until all fields filled) -->
    <button id="cpSubmit" class="cp-btn inactive" disabled>
        Update Password
    </button>

    <!-- Footer credit -->
    <div class="cp-footer">Created by Usman Ahmad &amp; Muniba Shami</div>

</div><!-- /cp-card -->

<!-- ══════════════════════════════════════════════════════════
     FULL-SCREEN LOADER OVERLAY  (same design as login page)
     JS shows it on submit, hides it on success/error.
     ══════════════════════════════════════════════════════════ -->
<div id="cpLoader" class="cp-loader" aria-hidden="true" role="status">
    <div class="cp-loader-backdrop"></div>
    <div class="cp-loader-card">
        <div class="cp-loader-logo-wrap">
            <div class="cp-loader-ring cp-loader-ring--outer"></div>
            <div class="cp-loader-ring cp-loader-ring--inner"></div>
            <div class="cp-loader-logo-icon">
                <svg width="36" height="36" viewBox="0 0 32 32" fill="none"
                     xmlns="http://www.w3.org/2000/svg">
                    <circle cx="16" cy="16" r="16" fill="#4F46E5"/>
                    <path d="M16 8L12 12H14V18H18V12H20L16 8Z" fill="white"/>
                    <path d="M12 20H20V22H12V20Z" fill="white"/>
                </svg>
            </div>
        </div>
        <p class="cp-loader-brand">AI Builders</p>
        <p class="cp-loader-status" id="cpLoaderStatus">Updating password…</p>
        <div class="cp-loader-dots" aria-hidden="true">
            <span class="cp-loader-dot"></span>
            <span class="cp-loader-dot"></span>
            <span class="cp-loader-dot"></span>
        </div>
    </div>
</div>

<!-- jQuery (reuse same version as login page) -->
<script src="/AI_Builders/assets/js/jquery.js"></script>
<script src="/AI_Builders/assets/js/changePassword.js"></script>


</body>
</html>
