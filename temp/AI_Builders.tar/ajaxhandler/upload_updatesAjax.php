<?php
/**
 * upload_updatesAjax.php
 * Push notifications FIRST (fast), then emails (slow) in background.
 * AJAX gets success response immediately after DB insert + queue.
 */

ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json');

$path = $_SERVER['DOCUMENT_ROOT'];

require_once $path . '/AI_Builders/database/database.php';
require_once $path . '/AI_Builders/database/courseUpdateDetails.php';
require_once $path . '/AI_Builders/config/database.php';

$action = $_REQUEST['action'] ?? null;

// ═══════════════════════════════════════════════════════════════
// ACTION: saveUpdate
// ═══════════════════════════════════════════════════════════════
if ($action === 'saveUpdate') {

    $dbo = new Database();
    $udo = new course_updates();

    $course_id   = (int)($_POST['course_id']     ?? 0);
    $faculty_id  = (int)($_POST['faculty_id']    ?? 0);
    $update_type = trim($_POST['update_type']    ?? '');
    $message     = trim($_POST['update_message'] ?? '');
    $dateText    = trim($_POST['update_date']    ?? '');
    $timeText    = trim($_POST['update_time']    ?? '');

    if (!$course_id || !$faculty_id || $update_type === '' || $message === '') {
        echo json_encode(['status' => 'error', 'error' => 'Missing required fields.']);
        exit;
    }

    $update_date = date('Y-m-d', strtotime($dateText));
    $update_time = $timeText;

    // ── 1. Insert course update ───────────────────────────────────
    try {
        $udo->insertUpdate($dbo, $course_id, $faculty_id, $update_type, $message, $update_date, $update_time);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'error' => 'DB insert failed: ' . $e->getMessage()]);
        exit;
    }

    // ── 2. Queue notification job ─────────────────────────────────
    try {
        $pdo = getDB();
        $pdo->prepare("INSERT INTO notification_queue (course_id, update_type, message, status) VALUES (?, ?, ?, 'pending')")
            ->execute([$course_id, $update_type, $message]);
    } catch (Exception $e) {
        error_log('Queue insert failed: ' . $e->getMessage());
        $pdo = null;
    }

    // ── 3. Send JSON success to browser immediately ───────────────
    echo json_encode(['status' => 'success']);

    // Close the HTTP connection so browser stops waiting
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        // For Apache/LiteSpeed on Hostinger
        header('Connection: close');
        header('Content-Encoding: none');
        if (ob_get_level() > 0) ob_end_flush();
        flush();
    }

    // ── 4. Background: everything below runs after browser is done ─
    ignore_user_abort(true);
    set_time_limit(300);
    session_write_close();

    if (empty($pdo)) {
        try { $pdo = getDB(); } catch (Exception $e) { error_log('DB reconnect failed'); exit; }
    }

    // Fetch pending jobs
    try {
        $jobs = $pdo->query("SELECT * FROM notification_queue WHERE status = 'pending' ORDER BY created_at ASC")
                    ->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log('Queue fetch failed: ' . $e->getMessage());
        exit;
    }

    if (empty($jobs)) exit;

    require_once $path . '/AI_Builders/api/helpers/fcm_helper.php';
    require_once $path . '/AI_Builders/ajaxhandler/sendCourseUpdateEmail.php';

    $dbo2 = new Database();

    foreach ($jobs as $job) {
        $jobId     = $job['id'];
        $jCourseId = (int)$job['course_id'];
        $jType     = $job['update_type'];
        $jMessage  = $job['message'];

        // Mark done immediately to prevent double processing
        try {
            $pdo->prepare("UPDATE notification_queue SET status = 'done' WHERE id = ?")
                ->execute([$jobId]);
        } catch (Exception $e) {
            error_log("Job #$jobId mark-done failed: " . $e->getMessage());
            continue;
        }

        // ── A. PUSH FIRST (fast — just an API call) ───────────────
        try {
            $cStmt = $pdo->prepare("SELECT course_title, course_code FROM course_details WHERE id = ?");
            $cStmt->execute([$jCourseId]);
            $course      = $cStmt->fetch(PDO::FETCH_ASSOC);
            $courseLabel = ($course['course_code'] ?? '') . ' - ' . ($course['course_title'] ?? 'Update');

            $tStmt = $pdo->prepare("
                SELECT ft.id, ft.token
                FROM fcm_tokens ft
                INNER JOIN course_registration cr ON cr.student_id = ft.user_id
                WHERE cr.course_id = ? AND ft.is_active = 1
            ");
            $tStmt->execute([$jCourseId]);
            $tokens = $tStmt->fetchAll(PDO::FETCH_ASSOC);

            error_log("Job #$jobId: pushing to " . count($tokens) . " students");

            $expired = [];
            foreach ($tokens as $row) {
                $res = sendFcmNotification(
                    $row['token'],
                    $courseLabel,
                    '[' . strtoupper($jType) . '] ' . mb_strimwidth($jMessage, 0, 100, '...'),
                    '/AI_Builders/dashboard.php',
                    strtolower($jType)
                );
                error_log("Job #$jobId FCM: " . json_encode($res));
                if (!$res['success'] && ($res['error'] ?? '') === 'TOKEN_EXPIRED') {
                    $expired[] = $row['id'];
                }
            }

            if (!empty($expired)) {
                $ph = implode(',', array_fill(0, count($expired), '?'));
                $pdo->prepare("UPDATE fcm_tokens SET is_active = 0 WHERE id IN ($ph)")->execute($expired);
            }

            error_log("Job #$jobId push done");

        } catch (Exception $e) {
            error_log("Job #$jobId PUSH ERROR: " . $e->getMessage());
        }

        // ── B. EMAILS AFTER (slow — SMTP loop) ───────────────────
        try {
            sendCourseUpdateEmail($dbo2, $jCourseId, $jType, $jMessage);
            error_log("Job #$jobId emails done");
        } catch (Exception $e) {
            error_log("Job #$jobId EMAIL ERROR: " . $e->getMessage());
        }
    }

    exit;
}

// ═══════════════════════════════════════════════════════════════
// ACTION: getUpdates
// ═══════════════════════════════════════════════════════════════
if ($action === 'getUpdates') {
    $dbo       = new Database();
    $udo       = new course_updates();
    $course_id = (int)($_POST['course_id'] ?? 0);
    $updates   = $udo->fetchUpdates($dbo, $course_id);
    echo json_encode($updates);
    exit;
}

echo json_encode(['status' => 'error', 'error' => 'Unknown action.']);
exit;
