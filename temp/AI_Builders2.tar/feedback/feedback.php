<?php
session_start();

// Session timeout (10 minutes)
$timeout = 600;

// Check if user is logged in
if (!isset($_SESSION['current_user'])) {
    header("Location: /AI_Builders/login.php");
    exit();
}
else{
    $stid = $_SESSION["current_user"];
}

// Check inactivity timeout
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: /AI_Builders/login.php");
    exit();
}

// Update last activity time
$_SESSION['LAST_ACTIVITY'] = time();


//Get course slug from URL
if(isset($_GET['course_id'])){
    $course_id = $_GET['course_id'];
} else {
    // Redirect to dashboard if no course specified
    header("Location: /AI_Builders/dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>


   <!-- ================== FAVICONS ================== -->
    <!-- apple device icon (iOS home screen) -->
    <link rel="apple-touch-icon" sizes="180x180" href="/AI_Builders/assests/favicon_io/apple-touch-icon.png">
    <!-- standard favicon for most desktop browsers (32×32) -->
    <link rel="icon" type="image/png" sizes="32x32" href="/AI_Builders/assests/favicon_io/favicon-32x32.png">
    <!-- smaller favicon for older browsers or low-resolution displays -->
    <link rel="icon" type="image/png" sizes="16x16" href="/AI_Builders/assests/favicon_io/favicon-16x16.png">
    <!-- fallback favicon for very old browsers -->
    <link rel="icon" href="/AI_Builders/assests/favicon_io/favicon.ico">
    <!-- web app manifest - helps progressive web app features (PWA) -->
    <link rel="manifest" href="/AI_Builders/assests/favicon_io/site.webmanifest">


    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/AI_Builders/assets/css/feedback.css">
    <script src="/AI_Builders/assets/js/jquery.js"></script>
    <script src="/AI_Builders/assets/js/feedback.js"></script>

</head>
<body>

    <div class="container">
        <div class="form-section">
            <div class="form-header">
                <h1>We Value Your Feedback</h1>
                <p>Help us improve by sharing your thoughts and experiences. Your feedback matters to us!</p>
            </div>

            <form id="feedbackForm" method="post">
                <div class="form-group">
                    <label for="name">
                        Name <span class="required">*</span>
                    </label>
                    <input type="text" id="name" name="name" required placeholder="Enter your full name">
                </div>

                <div class="form-group">
                    <label for="email">
                        Email <span class="required">*</span>
                    </label>
                    <input type="email" id="email" name="email" required placeholder="your email">
                </div>
                <div class="form-group">
                    <label>
                        Feedback For 
                    </label>

                    <!-- Visible (read-only) -->
                    <input type="text" id="categoryText" class="readonly-input" readonly>

                    <!-- Hidden (actual value sent to backend) -->
                    <!-- <input type="hidden" id="category" name="category"> -->
                </div>


                <div class="form-group">
                    <label>
                        Rating <span class="required">*</span>
                    </label>
                    <div class="rating-group">
                        <div class="rating-option">
                            <input type="radio" id="rating1" name="rating" value="1" required>
                            <label for="rating1" class="rating-label">1</label>
                        </div>
                        <div class="rating-option">
                            <input type="radio" id="rating2" name="rating" value="2">
                            <label for="rating2" class="rating-label">2</label>
                        </div>
                        <div class="rating-option">
                            <input type="radio" id="rating3" name="rating" value="3">
                            <label for="rating3" class="rating-label">3</label>
                        </div>
                        <div class="rating-option">
                            <input type="radio" id="rating4" name="rating" value="4">
                            <label for="rating4" class="rating-label">4</label>
                        </div>
                        <div class="rating-option">
                            <input type="radio" id="rating5" name="rating" value="5">
                            <label for="rating5" class="rating-label">5</label>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="message">
                        Your Feedback <span class="required">*</span>
                    </label>
                    <textarea id="message" name="message" required placeholder="Share your thoughts, suggestions, or concerns..."></textarea>
                </div>

                <button type="submit" class="submit-btn">Submit Feedback</button>
                  <button type="button" class="btn" onclick="history.back()">GO Back</button>
            </form>
        </div>

        <div class="image-section">
            <div class="image-container">
                <img src="feedimage.png" alt="Feedback illustration">
            </div>
        </div>
    </div>


</html>