<?php
// Get root folder path
$path = $_SERVER['DOCUMENT_ROOT'];

// Include database connection file
require_once $path . "/AI_Builders/database/database.php";

class student_details {

    // ─────────────────────────────────────────────────────────
    // Get student name + roll_no by their session/user id
    // Called as getStudentInfo() from dashboardAjax.php
    // and leaveAjax.php
    // ─────────────────────────────────────────────────────────
    public function getStudentInfo($dbo, $studentId) {
        $cmd = "SELECT name, roll_no
                FROM student_details
                WHERE id = :studentId
                LIMIT 1";
        $s = $dbo->conn->prepare($cmd);
        try {
            $s->execute([":studentId" => $studentId]);
            return $s->fetch(PDO::FETCH_ASSOC);
        } catch (Throwable $th) {
            return null;
        }
    }

    // ─────────────────────────────────────────────────────────
    // Get student id by roll number
    // Called from leaveAjax.php submitLeave action
    // ─────────────────────────────────────────────────────────
    public function getStudentId($dbo, $rollNumber) {
        $cmd = "SELECT id FROM student_details WHERE roll_no = :roll_no LIMIT 1";
        $s   = $dbo->conn->prepare($cmd);
        try {
            $s->execute([":roll_no" => $rollNumber]);
            $row = $s->fetch(PDO::FETCH_ASSOC);
            return $row ? $row['id'] : null;
        } catch (Throwable $th) {
            return null;
        }
    }
}
?>
