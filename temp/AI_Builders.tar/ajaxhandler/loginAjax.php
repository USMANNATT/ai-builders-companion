<?php
/**
 * loginAjax.php — AI Builders AJAX endpoint
 * Place at: AI_Builders/ajaxhandler/loginAjax.php
 *
 * Handles: verifyUser, changePassword
 * Always returns JSON. Never outputs HTML errors.
 */

/*
 * ob_start() MUST be the very first statement.
 * It buffers ALL output — including PHP warnings, notices, and errors —
 * so nothing corrupt gets prepended to our JSON response.
 * Without this, a single PHP notice ("Undefined variable" etc.) will
 * break JSON.parse() on the client and login silently fails.
 */
ob_start();

/* ── Error reporting ──────────────────────────────────────────────── */
ini_set('display_errors', 0);          /* never send raw PHP errors to browser */
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);                /* log everything to server error log   */

/* ── Always respond with JSON ─────────────────────────────────────── */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');

try {

    /* ── 1. Require action ──────────────────────────────────────────── */
    if (empty($_POST['action'])) {
        throw new Exception('No action specified.');
    }
    $action = trim($_POST['action']);

    /* ── 2. Load dependencies ───────────────────────────────────────── */
    $root = rtrim($_SERVER['DOCUMENT_ROOT'], '/\\');
    $dbFile    = $root . '/AI_Builders/database/database.php';
    $loginFile = $root . '/AI_Builders/database/loginDetails.php';

    if (!file_exists($dbFile)) {
        throw new Exception('database.php not found at: ' . $dbFile);
    }
    if (!file_exists($loginFile)) {
        throw new Exception('loginDetails.php not found at: ' . $loginFile);
    }

    require_once $dbFile;
    require_once $loginFile;

    /* ── 3. Validate POST fields ────────────────────────────────────── */
    if (!isset($_POST['user_name']) || !isset($_POST['password'])) {
        throw new Exception('Username or password missing from request.');
    }

    $un = trim($_POST['user_name']);
    $pw = trim($_POST['password']);

    if ($un === '' || $pw === '') {
        throw new Exception('Username or password is empty.');
    }

    /* ── 4. Instantiate DB + auth classes ───────────────────────────── */
    $dbo = new Database();
    $ldo = new LoginDetails();

    /* ══════════════════════════════════════════════════════════════════
       ACTION: verifyUser
    ══════════════════════════════════════════════════════════════════ */
    if ($action === 'verifyUser') {

        $rv = $ldo->verifyUser($dbo, $un, $pw);

        if (!is_array($rv)) {
            throw new Exception('verifyUser() returned a non-array.');
        }

        /* If credentials correct → start session */
        if (isset($rv['status']) && $rv['status'] === 'ALLOK') {
            if (session_status() === PHP_SESSION_NONE) {
                session_set_cookie_params([
                    'lifetime' => 0,
                    'path'     => '/',
                    'secure'   => isset($_SERVER['HTTPS']),
                    'httponly' => true,
                    'samesite' => 'Lax',
                ]);
                session_start();
            }
            session_regenerate_id(true);
            $_SESSION['current_user'] = $rv['id'];
            $_SESSION['role']         = $rv['role'];
            if ($rv['role'] === 'admin' && isset($rv['name'])) {
                $_SESSION['admin_name'] = $rv['name'];
            }
        }

        /* Discard any buffered warnings before sending JSON */
        ob_clean();
        echo json_encode($rv);
        exit;
    }

    /* ══════════════════════════════════════════════════════════════════
       ACTION: changePassword
    ══════════════════════════════════════════════════════════════════ */
    if ($action === 'changePassword') {

        if (!isset($_POST['new_password'])) {
            throw new Exception('new_password field is missing.');
        }
        $newPw = trim($_POST['new_password']);

        if (strlen($newPw) < 8) {
            ob_clean();
            echo json_encode(['status' => 'ERROR', 'message' => 'New password must be at least 8 characters.']);
            exit;
        }
        if ($pw === $newPw) {
            ob_clean();
            echo json_encode(['status' => 'ERROR', 'message' => 'New password must differ from the current one.']);
            exit;
        }

        $rv = $ldo->changePassword($dbo, $un, $pw, $newPw);
        ob_clean();
        echo json_encode($rv);
        exit;
    }

    /* Unknown action */
    throw new Exception("Unknown action: '{$action}'");

} catch (Throwable $e) {
    /* Log the full details server-side */
    error_log('[loginAjax] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());

    /* Send a clean JSON error — no PHP stack trace leaking to client */
    ob_clean();
    http_response_code(200); /* keep 200 so JS onload fires (not onerror) */
    echo json_encode([
        'status'  => 'ERROR',
        'message' => $e->getMessage(),
    ]);
}
?>
