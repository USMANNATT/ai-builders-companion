<?php
/**
 * process_queue.php
 * ─────────────────────────────────────────────────────────────
 * Called by upload_updatesAjax.php via fire-and-forget cURL.
 * Processes all pending notification_queue rows:
 *   - Sends emails to enrolled students
 *   - Sends FCM push to enrolled students
 * ─────────────────────────────────────────────────────────────
 * Protected by a shared secret so it can't be called publicly.
 * ─────────────────────────────────────────────────────────────
 */

// ── Security: only allow internal calls ──────────────────────
$secret = $_POST['secret'] ?? '';
if ($secret !== 'AI_BUILDERS_QUEUE_SECRET') {
    http_response_code(403);
    exit('Forbidden');
}

ignore_user_abort(true);
set_time_limit(180);
ini_set('display_errors', 0);
error_reporting(E_ALL);

$path = $_SERVER['DOCUMENT_ROOT'];

require_once $path . '/AI_Builders/database/database.php';
require_once $path . '/AI_Builders/ajaxhandler/sendCourseUpdateEmail.php';
require_once $path . '/AI_Builders/api/helpers/fcm_helper.php';
require_once $path . '/AI_Builders/config/database.php';

try {
    $pdo = getDB();

    // ── Fetch all pending jobs ────────────────────────────────────
    $jobs = $pdo->query("
        SELECT * FROM notification_queue
        WHERE status = 'pending'
        ORDER BY created_at ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    if (empty($jobs)) exit;

    $dbo = new Database();

    foreach ($jobs as $job) {
        $jobId       = $job['id'];
        $course_id   = (int)$job['course_id'];
        $update_type = $job['update_type'];
        $message     = $job['message'];

        // Mark as processing immediately to prevent double-sending
        $pdo->prepare("UPDATE notification_queue SET status = 'done' WHERE id = ?")
            ->execute([$jobId]);

        // ── Send emails ───────────────────────────────────────────
        try {
            sendCourseUpdateEmail($dbo, $course_id, $update_type, $message);
        } catch (Exception $e) {
            error_log("Email error for job $jobId: " . $e->getMessage());
        }

        // ── Send push notifications ───────────────────────────────
        try {
            // Get course info
            $cStmt = $pdo->prepare("SELECT course_title, course_code FROM course_details WHERE id = ?");
            $cStmt->execute([$course_id]);
            $course      = $cStmt->fetch(PDO::FETCH_ASSOC);
            $courseLabel = ($course['course_code'] ?? '') . ' - ' . ($course['course_title'] ?? 'Course Update');

            // Get FCM tokens of enrolled students only
            $tStmt = $pdo->prepare("
                SELECT ft.id, ft.token
                FROM fcm_tokens ft
                INNER JOIN course_registration cr ON cr.student_id = ft.user_id
                WHERE cr.course_id = ?
                  AND ft.is_active = 1
            ");
            $tStmt->execute([$course_id]);
            $tokens = $tStmt->fetchAll(PDO::FETCH_ASSOC);

            $notifTitle = $courseLabel;
            $notifBody  = '[' . strtoupper($update_type) . '] ' . mb_strimwidth($message, 0, 100, '...');
            $clickUrl   = '/AI_Builders/dashboard.php';
            $expired    = [];

            foreach ($tokens as $row) {
                $res = sendFcmNotification(
                    $row['token'],
                    $notifTitle,
                    $notifBody,
                    $clickUrl,
                    strtolower($update_type)
                );
                
                error_log('FCM result for token ' . substr($row['token'], 0, 20) . ': ' . json_encode($res));
                if (!$res['success'] && ($res['error'] ?? '') === 'TOKEN_EXPIRED') {
                    $expired[] = $row['id'];
                }
            }

            // Deactivate expired tokens
            if (!empty($expired)) {
                $ph = implode(',', array_fill(0, count($expired), '?'));
                $pdo->prepare("UPDATE fcm_tokens SET is_active = 0 WHERE id IN ($ph)")
                    ->execute($expired);
            }

        } catch (Exception $e) {
            error_log("Push error for job $jobId: " . $e->getMessage());
        }
    }

} catch (Exception $e) {
    error_log('process_queue.php fatal error: ' . $e->getMessage());
}

exit;
