<?php
/**
 * loginDetails.php
 * ─────────────────────────────────────────────────────────────────────────
 * Unified authentication class.
 *
 * Instead of three separate files (facultyDetails, studentDetails,
 * adminDetails) for login, this single class tries each table in order:
 *   1. faculty_details
 *   2. student_details
 *   3. admin_details
 *
 * If the username is found and the bcrypt password matches, the method
 * returns the user's id, role, and a redirect URL.
 *
 * Password storage: ALL passwords must be hashed with PHP's password_hash()
 * using PASSWORD_BCRYPT.  password_verify() is used to check them here.
 * ─────────────────────────────────────────────────────────────────────────
 */

class LoginDetails {

    // ─────────────────────────────────────────────────────────────
    // PUBLIC: Unified login verification
    // ─────────────────────────────────────────────────────────────

    /**
     * Tries to authenticate a user against all three tables.
     *
     * Flow:
     *   • Search faculty_details  → if found verify password → return faculty result
     *   • Search student_details  → if found verify password → return student result
     *   • Search admin_details    → if found verify password → return admin result
     *   • If not found in any table → return "User not found"
     *
     * @param  Database $dbo  PDO wrapper (must expose $dbo->conn)
     * @param  string   $un   Raw username from POST (already trimmed)
     * @param  string   $pw   Raw password from POST (already trimmed)
     * @return array  Keys: status, id, role, redirect
     *                status values: ALLOK | WRONG PASSWORD | User not found | ERROR
     */
    public function verifyUser($dbo, $un, $pw) {

        // Default "not found" response — overwritten if a match is found
        $rv = [
            "status"   => "User not found",   // human-readable result
            "id"       => -1,                 // DB primary key of matched user
            "role"     => "",                 // faculty | student | admin
            "redirect" => ""                  // where to send the browser after login
        ];

        // ── 1. Try faculty_details ────────────────────────────────────
        // Query selects id + hashed password for the given username
        $facultyResult = $this->checkTable(
            $dbo,
            "SELECT id, password FROM faculty_details WHERE user_name = :un",
            $un
        );

        if ($facultyResult !== null) {
            // Username found in faculty table — now verify the password
            if (password_verify($pw, $facultyResult['password'])) {
                // Password matches — build a success response
                $rv = [
                    "status"   => "ALLOK",
                    "id"       => $facultyResult['id'],
                    "role"     => "faculty",
                    "redirect" => "/AI_Builders/FacultyDashboard/Dashboard.php"
                ];
            } else {
                // Username exists but password is wrong — stop searching
                $rv["status"] = "WRONG PASSWORD";
            }
            // Return immediately — username found in this table, no need to check others
            return $rv;
        }

        // ── 2. Try student_details ────────────────────────────────────
        $studentResult = $this->checkTable(
            $dbo,
            "SELECT id, password FROM student_details WHERE user_name = :un",
            $un
        );

        if ($studentResult !== null) {
            // Username found in student table
            if (password_verify($pw, $studentResult['password'])) {
                $rv = [
                    "status"   => "ALLOK",
                    "id"       => $studentResult['id'],
                    "role"     => "student",
                    "redirect" => "/AI_Builders/dashboard.php"
                ];
            } else {
                $rv["status"] = "WRONG PASSWORD";
            }
            return $rv;
        }

        // ── 3. Try admin_details ──────────────────────────────────────
        // Admin table has an extra "name" column we need for the session
        $adminResult = $this->checkTable(
            $dbo,
            "SELECT id, password, name FROM admin_details WHERE user_name = :un",
            $un
        );

        if ($adminResult !== null) {
            // Username found in admin table
            if (password_verify($pw, $adminResult['password'])) {
                $rv = [
                    "status"   => "ALLOK",
                    "id"       => $adminResult['id'],
                    "role"     => "admin",
                    "name"     => $adminResult['name'],   // store admin display name too
                    "redirect" => "/AI_Builders/admin.php"
                ];
            } else {
                $rv["status"] = "WRONG PASSWORD";
            }
            return $rv;
        }

        // Username not found in any of the three tables
        return $rv;   // status is still "User not found"
    }

    // ─────────────────────────────────────────────────────────────
    // PUBLIC: Change / reset password
    // ─────────────────────────────────────────────────────────────

    /**
     * Changes a user's password after verifying their current password.
     *
     * Steps:
     *   1. Locate the user across all three tables using verifyUser().
     *   2. Confirm the current password is correct.
     *   3. Hash the new password with bcrypt.
     *   4. Write the new hash back to the correct table.
     *
     * @param  Database $dbo         PDO wrapper
     * @param  string   $un          Username (trimmed)
     * @param  string   $currentPw   Current (old) password entered by the user
     * @param  string   $newPw       New password to set
     * @return array  { status: "ALLOK"|"WRONG PASSWORD"|"User not found"|"ERROR" }
     */
    public function changePassword($dbo, $un, $currentPw, $newPw) {

        // First, verify the current credentials so we know the user is who they claim
        $auth = $this->verifyUser($dbo, $un, $currentPw);

        // If current password is wrong or user doesn't exist, stop here
        if ($auth['status'] !== 'ALLOK') {
            return ["status" => $auth['status']];  // propagate WRONG PASSWORD / User not found
        }

        // Hash the new password using bcrypt (cost factor 12 — good balance of speed/security)
        $newHash = password_hash($newPw, PASSWORD_BCRYPT, ['cost' => 12]);

        // Map each role to its corresponding table name
        $tableMap = [
            "faculty" => "faculty_details",
            "student" => "student_details",
            "admin"   => "admin_details"
        ];

        // Look up the correct table for this user's role
        $table = $tableMap[$auth['role']];

        // Build the UPDATE statement using a named placeholder for safety
        $sql = "UPDATE {$table} SET password = :newHash WHERE id = :id";

        try {
            // Prepare the statement to prevent SQL injection
            $stmt = $dbo->conn->prepare($sql);

            // Execute with the new hash and the user's primary key
            $stmt->execute([
                ":newHash" => $newHash,
                ":id"      => $auth['id']
            ]);

            // Confirm at least one row was actually updated
            if ($stmt->rowCount() > 0) {
                return ["status" => "ALLOK"];
            } else {
                // rowCount = 0 means nothing changed — shouldn't happen, but handle it
                return ["status" => "ERROR", "message" => "No rows updated."];
            }

        } catch (Throwable $e) {
            // Log the real error server-side; return a generic message to the client
            error_log("changePassword Error: " . $e->getMessage());
            return ["status" => "ERROR", "message" => "Database error while updating password."];
        }
    }

    // ─────────────────────────────────────────────────────────────
    // PRIVATE HELPER: Run a SELECT and return the first matching row
    // ─────────────────────────────────────────────────────────────

    /**
     * Executes a parameterised SELECT query with a single :un binding
     * and returns the first row as an associative array, or null if no
     * rows were returned (username doesn't exist in that table).
     *
     * @param  Database $dbo  PDO wrapper
     * @param  string   $sql  Query string containing :un placeholder
     * @param  string   $un   The username value to bind
     * @return array|null     First row as assoc array, or null if not found
     */
    private function checkTable($dbo, $sql, $un) {
        try {
            // Prepare the statement — prevents SQL injection
            $stmt = $dbo->conn->prepare($sql);

            // Execute with the username bound to the :un placeholder
            $stmt->execute([":un" => $un]);

            // If at least one row matched, return it; otherwise return null
            if ($stmt->rowCount() > 0) {
                return $stmt->fetch(PDO::FETCH_ASSOC);   // returns [ 'id' => ..., 'password' => ..., ... ]
            }

        } catch (Throwable $e) {
            // Log detailed error for the developer; silently return null to the caller
            // so the outer loop continues checking the next table
            error_log("checkTable Error [{$sql}]: " . $e->getMessage());
        }

        // Return null when the user isn't in this table (or an error occurred)
        return null;
    }
}
?>