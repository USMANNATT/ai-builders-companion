// =====================================================
// STEP 1: RUN CODE WHEN DOCUMENT IS READY (jQuery way)
// =====================================================
$(document).ready(function () {

    // =====================================================
    // HAMBURGER MENU FUNCTIONALITY (Mobile)
    // =====================================================
    
    const hamburger = $("#hamburgerBtn");
    const sidebar = $("#sidebar");
    const overlay = $("#sidebarOverlay");
    const closeSidebar = $("#closeSidebar");
    
    // Open sidebar when hamburger is clicked
    hamburger.on("click", function() {
        sidebar.addClass("active");
        overlay.addClass("active");
        hamburger.addClass("active");
        $("body").css("overflow", "hidden"); // Prevent scrolling when sidebar is open
    });
    
    // Close sidebar when close button is clicked
    closeSidebar.on("click", function() {
        sidebar.removeClass("active");
        overlay.removeClass("active");
        hamburger.removeClass("active");
        $("body").css("overflow", "auto");
    });
    
    // Close sidebar when overlay is clicked
    overlay.on("click", function() {
        sidebar.removeClass("active");
        overlay.removeClass("active");
        hamburger.removeClass("active");
        $("body").css("overflow", "auto");
    });
    
    // Close sidebar when a subject link is clicked (mobile only)
    $(".subject-menu a").on("click", function() {
        if (window.innerWidth <= 600) {
            sidebar.removeClass("active");
            overlay.removeClass("active");
            hamburger.removeClass("active");
            $("body").css("overflow", "auto");
        }
    });

    // =====================================================
    // STEP 2: SIDEBAR ACTIVE STATE HANDLING
    // Only one sidebar link should be active at a time
    // =====================================================

    const sidebarLinks = $(".sidebar a");

    sidebarLinks.on("click", function () {
        // Remove active class from all sidebar links
        sidebarLinks.removeClass("active");

        // Add active class to the clicked link only
        $(this).addClass("active");
    });


    // =====================================================
    // STEP 3: SEARCH FILTER FUNCTIONALITY
    // Filters cards, lessons, course rows & notifications
    // =====================================================

    const searchInput = $(".heading input");

    if (searchInput.length) {
        searchInput.on("keyup", function () {

            // Convert user input to lowercase for case-insensitive search
            const value = $(this).val().toLowerCase();

            // Loop through all searchable items
            $(".cards, .lesson, .course-row, .notification").each(function () {

                // Check if element text contains search value
                const isMatch = $(this).text().toLowerCase().includes(value);

                // Show or hide element based on match
                $(this).css("display", isMatch ? "flex" : "none");
            });
        });
    }

    // =====================================================
    // STEP 4: LOGOUT BUTTON CONFIRMATION & REDIRECTION
    // =====================================================

    $("#sbtnLogout").on("click", function () {

        // Ask user before logging out
        if (confirm("Are you sure you want to logout?")) {
            $.ajax({
                url: "/AI_Builders/ajaxhandler/logout_ajax.php", // Absolute path
                type:"POST",
                dataType:"json",
                data:{id:1},
                // This function runs **before the request is sent** to the server
                beforeSend: function(e){
                },
    
                // This function runs **if the request is successful**
                success: function(e){
    
                    // IF THE AJAX CALL WAS SUCCESSFULL AND THE USER IS LOGGED OUT THAN 
                    // REDIRECT THE USER TO LOGIN PAGE
    
                    window.location.href = "/AI_Builders/login.php";
                },
                    
                // IF THE AJAX CALL WAS NOT SUCCESSFULL SHOW ERROR
                error: function (e) {
                    alert("ERROR: SOMETHING WENT WRONG");                
                }
            });
        }

    });










    // =====================================================
    // STEP 5: FUNCTION TO GENERATE COURSE CARDS HTML
    // =====================================================

    function getCourseCardsHTML(rv) {

        let x = ``;
        let innerColor = "";

        // Loop through each course record
        for (let index = 0; index < rv.length; index++) {

            let course = rv[index];
            let attpercen = course['attendance_percentage'];

            // =================================================
            // STEP 5.1: ASSIGN PROGRESS BAR COLOR BASED ON %
            // =================================================

            if (attpercen < 75) {
                innerColor = "seventyfive";
            } else if (attpercen < 80) {
                innerColor = "eighty";
            } else if (attpercen < 85) {
                innerColor = "eightyfive";
            } else if (attpercen < 90) {
                innerColor = "ninty";
            } else {
                innerColor = "hundred";
            }

            // =================================================
            // STEP 5.2: BUILD COURSE CARD HTML
            // =================================================

            x += `
                <div class="cards">
                    <h3>${course['course_name']}   </h3>
                     <span class = "course-code"> (${course['course_code']})  </span>
                     <br>

                    <span class="percentage">${attpercen}%</span>

                    <div class="progress">
                        <div class="${innerColor}" style="width:${attpercen}%"></div>
                    </div>
                </div>
            `;
        }

        // Insert all course cards into container
        $("#coursecards").html(x);

        // =================================================
        // STEP 5.3: PROGRESS BAR ANIMATION ON LOAD
        // =================================================

        // Animate each progress bar to its width
        $(".progress div").each(function () {

            // Get the target width from CSS
            const width = $(this).css("width");

            // Reset width to 0 before animation
            $(this).css("width", "0");

            // Animate to target width after short delay
            // it creates a smooth transition effect
            // it has two attributes transition and width
            // transition: "width 1s ease" means the width will change over 1 second with an easing effect
            // width: width sets the width to the target value
            // 300 milliseconds delay before starting the animation
            setTimeout(() => {
                $(this).css({
                    transition: "width 1s ease",
                    width: width
                });
            }, 300);
        });
    }

    // =====================================================
    // STEP 6: FETCH STUDENT ID FROM HIDDEN INPUT
    // =====================================================

    let studentid = $("#hiddenStId").val();

    // =====================================================
    // STEP 7: AJAX CALL TO FETCH ATTENDANCE DATA
    // =====================================================

    $.ajax({
        url: "/AI_Builders/ajaxhandler/attendanceAJAX.php",
        type: "POST",
        dataType: "json",
        data: {
            studentid: studentid,
            action: "getAttendanceOfOneStudent"
        },
        success: function (rv) {
            // Generate course cards UI
            getCourseCardsHTML(rv);
        },
        error: function (e) {
            alert(JSON.stringify(e));
        }
    });


    // =====================================================
    // STEP 8: LEAVE BUTTON REDIRECTION
    // =====================================================

    $("#btnLeave").on("click", function () {
        window.location.href = "/AI_Builders/leave/leave_submit.php";
    });

    // =====================================================
    // STEP 9: STUDENT NAME & TIME-BASED GREETING
    // =====================================================

    function studentNameHTML(studentName) {

        const welcomeText = $(".welcome h1");

        // Check if welcome text element exists
        // .length returns number of elements in jQuery object
        // in our case it will be either 0 or 1
        if (welcomeText.length) {

            // Get current hour of the day
            const hour = new Date().getHours();
            let greeting = "Welcome";

            if (hour < 12) greeting = "Good Morning";
            else if (hour < 18) greeting = "Good AfterNoon";
            else greeting = "Good Evening";

            welcomeText.text(`${greeting}, ${studentName}`);
        }
    }

    // =====================================================
    // STEP 10: FUNCTION TO DISPLAY LEAVE RECORDS
    // =====================================================

    function leaveRecordsHTML(leaves) {

        let x = ``;

        for (let index = 0; index < leaves.length; index++) {

            let leave = leaves[index];
            let leavestatus = leave['status'];
            let y = ``;

            // =================================================
            // STEP 10.1: STATUS-BASED MESSAGE
            // =================================================

            if (leavestatus === 'approved' || leavestatus === 'rejected') {
                y = `<p class="leave-text">Leave is ${leavestatus} by ${leave['name']}</p>`;
            } else {
                y = `<p class="leave-text">Waiting for ${leave['name']} Approval</p>`;
            }

            // =================================================
            // STEP 10.2: BUILD LEAVE CARD HTML
            // =================================================

            x += `
                <div class="leave-card ${leavestatus}">
                    <div class="leave-top">
                        <span class="leave-code ${leavestatus}-btn">${leave['course_code']}</span>
                        <span class="leave-status ${leavestatus}">${leavestatus}</span>
                    </div>

                    <h3>${leave['course_title']}</h3>
                    <p class="leave-date">📅 ${leave['start_date']} - ${leave['end_date']}</p>

                    <div class="leave-progress">
                        <span class="step step-done"></span>
                        <span class="step step-${leavestatus}"></span>
                    </div>

                    ${y}

                    <button class="leave-btn ${leavestatus}-btn">View Details</button>
                </div>
            `;
        }

        $(".leave-grid").html(x);
    }


    // =====================================================
    // STEP 11: FETCH STUDENT NAME USING AJAX
    // =====================================================

    let studentId = $("#hiddenStId").val();

    $.ajax({
        url: "/AI_Builders/ajaxhandler/dashboardAjax.php",
        type: "POST",
        dataType: "json",
        data: {
            studentId: studentId,
            action: "getStudentName"
        },
        success: function (rv) {
            studentNameHTML(rv.name);
        },
        error: function (xhr, status, e) {
            console.log("Error fetching name:", e);
            console.log(e);
            console.log(xhr.response);
        }
    });


    // =====================================================
    // STEP 12: FETCH LEAVE RECORDS USING AJAX
    // =====================================================

    $.ajax({
        url: "/AI_Builders/ajaxhandler/dashboardAjax.php",
        type: "POST",
        dataType: "json",
        data: {
            studentId: studentId,
            action: "fetchLeaves"
        },
        success: function (rv) {
            leaveRecordsHTML(rv);
        },
        error: function (xhr, status, e) {
            alert("Error fetching leave records");
            console.log(JSON.stringify(e));
            console.log(status);
            console.log(xhr.response);
        }
    });






    // load subjects


        let sid = $("#hiddenStId").val();
        
        $.ajax({
            url: "/AI_Builders/ajaxhandler/dashboardAjax.php",
            type: "POST",
            dataType: "json",
            data: {
                action: "getStudentSubjects",
                student_id: sid
            },
            success: function (response) {
                //alert("success");
                //alert(response);
                //alert(JSON.stringify(response));
    
                let menu = $("#subjectMenu");
                menu.empty();
                menu.addClass("show");

    
                if (response.length === 0) {
                    menu.append("<p>No subjects assigned</p>");
                    return;
                }
    
                $.each(response, function (index, subject) {
                    let link = $("<a>")
                        .attr("href", "subject.php?id=" + subject.id)
                        .text(subject.course_title);
    
                    menu.append(link);
                    console.log(menu.html());

                });
                if (window.innerWidth <= 600) {
                    menu.addClass("show");
                }
            },
            error: function (xhr, status, error) {
                alert("AJAX Error:", error);
                alert(xhr);
                alert(status);
            }
        });

    
});
