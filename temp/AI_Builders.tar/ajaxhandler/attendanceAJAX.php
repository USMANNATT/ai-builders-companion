<?php
// attendanceAJAX.php — handles all AJAX requests for attendance
// Change from original: sectionid is now received and forwarded
// to PHP methods for getStudentList, saveAttendance, CSV/Excel downloads.

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$path = $_SERVER['DOCUMENT_ROOT'];
require_once $path . "/AI_Builders/database/database.php";
require_once $path . "/AI_Builders/database/sessionDetails.php";
require_once $path . "/AI_Builders/database/facultyDetails.php";
require_once $path . "/AI_Builders/database/courseRegistrationDetails.php";
require_once $path . "/AI_Builders/database/attendanceDetails.php";
require_once $path . "/AI_Builders/vendor/autoload.php";

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;

function createCSVReport($list, $filename) {
    $path = $_SERVER['DOCUMENT_ROOT'];
    $finalFileName = $path . $filename;
    try {
        $fp = fopen($finalFileName, "w");
        foreach ($list as $line) { fputcsv($fp, $line); }
        fclose($fp);
    } catch (Exception $e) { /* silent */ }
}

if (isset($_REQUEST['action'])) {
    $action = $_REQUEST['action'];

    // ── 1. Get sessions ───────────────────────────────────────────────
    if ($action == "getSession") {
        $dbo  = new Database();
        $sobj = new SessionDetails();
        $rv   = $sobj->getSessions($dbo);
        echo json_encode($rv);
        exit;
    }

    // ── 2. Get faculty courses ────────────────────────────────────────
    if ($action == "getFacultyCourses") {
        $facid     = $_POST['facid'];
        $sessionid = $_POST['sessionid'];
        $dbo       = new Database();
        $fdo       = new faculty_details();
        $rv        = $fdo->getCoursesInASession($dbo, $sessionid, $facid);
        echo json_encode($rv);
        exit;
    }

    // ── 3. Get student list (NOW filtered by sectionid) ───────────────
    if ($action == "getStudentList") {
        $classid   = $_POST['classid'];
        $sessionid = $_POST['sessionid'];
        $facid     = $_POST['facultyid'];
        $ondate    = $_POST['ondate'];
        $sectionid = isset($_POST['sectionid']) ? $_POST['sectionid'] : null; // ← NEW

        $dbo  = new Database();
        $crgo = new CourseRegistrationDetails();
        $ado  = new attendanceDetails();

        // Pass sectionid so only students in that section are returned
        $allStudents    = $crgo->getRegisteredStudents($dbo, $sessionid, $classid, $sectionid);
        $presentStudents = $ado->getAttendanceOfAClassByFacultyOnADate($dbo, $sessionid, $classid, $facid, $ondate);

        for ($i = 0; $i < count($allStudents); $i++) {
            $allStudents[$i]['status'] = 'NO';
            for ($j = 0; $j < count($presentStudents); $j++) {
                if ($allStudents[$i]['id'] == $presentStudents[$j]['student_id']) {
                    $allStudents[$i]['status'] = 'YES';
                    break;
                }
            }
        }

        echo json_encode($allStudents);
        exit;
    }

    // ── 4. Save attendance ────────────────────────────────────────────
    if ($action == "saveAttendance") {
        $studentid = $_POST['studentid'];
        $courseid  = $_POST['courseid'];
        $facultyid = $_POST['facultyid'];
        $sessionid = $_POST['sessionid'];
        $ondate    = $_POST['ondate'];
        $status    = $_POST['ispresent'];
        // sectionid not needed for attendance_details table (kept for future use)

        $dbo = new Database();
        $ado = new attendanceDetails();
        $rv  = $ado->saveAttendance($dbo, $sessionid, $courseid, $facultyid, $studentid, $ondate, $status);
        echo json_encode($rv);
    }

    // ── 5. Download CSV report (NOW filtered by sectionid) ────────────
    if ($action == "downloadCSVFile") {
        $courseid  = $_POST['classid'];
        $facultyid = $_POST['facultyid'];
        $sessionid = $_POST['sessionid'];
        $sectionid = isset($_POST['sectionid']) ? $_POST['sectionid'] : null; // ← NEW

        $dbo = new Database();
        $ado = new attendanceDetails();

        $list     = $ado->getAttendanceReport($dbo, $sessionid, $courseid, $facultyid, $sectionid);
        $filename = "/AI_Builders/reports/attendance_report.csv";
        createCSVReport($list, $filename);

        echo json_encode(["filename" => $filename]);
        exit;
    }

    // ── 6. Download today's CSV (NOW filtered by sectionid) ───────────
    if ($action == "downloadCurrentDateExcelFile") {
        $sessionid = $_POST['sessionid'];
        $courseid  = $_POST['classid'];
        $facultyid = $_POST['facultyid'];
        $ondate    = $_POST['ondate'];
        $sectionid = isset($_POST['sectionid']) ? $_POST['sectionid'] : null; // ← NEW

        $dbo = new Database();
        $ado = new attendanceDetails();

        $list     = $ado->getAttendanceOfAClassByFacultyOnADateForExcel($dbo, $sessionid, $courseid, $facultyid, $ondate, $sectionid);
        $filename = "/AI_Builders/reports/attendance_{$ondate}.csv";
        createCSVReport($list, $filename);

        echo json_encode(["filename" => $filename]);
        exit;
    }

    // ── 7. One student attendance (unchanged) ─────────────────────────
    if ($action == "getAttendanceOfOneStudent") {
        $studentid = $_POST['studentid'];
        $dbo = new Database();
        $ado = new attendanceDetails();
        $rv  = $ado->getAttendanceOfOneStudent($dbo, $studentid);
        echo json_encode($rv);
        exit;
    }

    // ── 8. LMS Excel report (NOW filtered by sectionid) ───────────────
    if ($action == "downloadLMSExcelReport") {
        header('Content-Type: application/json');
        try {
            if (!isset($_POST['sessionid'], $_POST['classid'], $_POST['facultyid'])) {
                throw new Exception("Missing required parameters.");
            }
            $sessionid = $_POST['sessionid'];
            $courseid  = $_POST['classid'];
            $facultyid = $_POST['facultyid'];
            $sectionid = isset($_POST['sectionid']) ? $_POST['sectionid'] : null; // ← NEW

            $dbo = new Database();
            $ado = new attendanceDetails();

            $filename = $ado->generateLMSExcelReport($dbo, $sessionid, $courseid, $facultyid, $sectionid);

            if (!$filename) throw new Exception("Failed to generate LMS Excel report.");

            echo json_encode(["status" => "success", "filename" => $filename]);
            exit;
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                "status"  => "error",
                "message" => $e->getMessage(),
                "file"    => $e->getFile(),
                "line"    => $e->getLine()
            ]);
            exit;
        }
    }
}
?>
