$(document).ready(function () {

    // Dynamic Date
    $("#date").text(
        new Date().toLocaleDateString('en-US', {
            weekday: 'long',
            month: 'short',
            day: 'numeric'
        })
    );

    // Staggered Animation for Cards
    $('.stat-card').each(function (index) {
        $(this).css('animation-delay', `${index * 0.1}s`);
    });

    // Interactive Search Focus
    $('.search-box input').on('focus', function () {
        $('.search-box').css('border', '1px solid #007bff');
    });

    $('.search-box input').on('blur', function () {
        $('.search-box').css('border', 'none');
    });

    // Get the faculty ID of the logged-in faculty from a hidden input field
    let facultyid = $("#hiddenFacId").val();

    $.ajax({
        url: '/AI_Builders/ajaxhandler/facultydashboardAjax.php',
        method: 'POST',
        data: {
            facid: facultyid,
            action: 'getProfessorName'
        },
        dataType: 'json',
    
        success: function (data) {
            try {
                if (data && data.name) {
                   
                    $('#professor-name').text(data.name);
                } else {
                    console.error('Error: data or data.name is empty', data);

                }
            } catch (e) {
                console.error('Success callback error:', e);

            }
        },
    
        error: function (xhr, status, error) {
            console.error('AJAX Error:', status, error);
            console.error('Response Text:', xhr.responseText);
        }
    });







    $.ajax({
        url: '/AI_Builders/ajaxhandler/facultydashboardAjax.php',
        method: 'POST',
        data: {
            facid: facultyid,
            action: 'getTotalStudents'
        },
        dataType: 'json',
    
        success: function (data) {
 

            try {
                if (data && data.total_students) {
                   
                    $('#totalStudents').text(data.total_students);
                } else {
                    console.error('Error: data or data.name is empty', data);

                }
            } catch (e) {
                console.error('Success callback error:', e);

            }
        },
    
        error: function (xhr, status, error) {
            console.error('AJAX Error:', status, error);
            console.error('Response Text:', xhr.responseText);
        }
    });

    // todays date
    let today = new Date();
    //alert(today.toISOString().split('T')[0]);

    $.ajax({
        url: '/AI_Builders/ajaxhandler/facultydashboardAjax.php',
        method: 'POST',
        data: {
            facid: facultyid,
            date: today.toISOString().split('T')[0],
            action: 'getpresentStudents'
        },
        dataType: 'json',
    
        success: function (data) {
       

            try {
                if (data && data.present_students) {
                    data.present_students = data.present_students; // to exclude faculty count
                   
                    $('#presentStudents').text(data.present_students);
                } else {
                    console.error('Error: data or data.name is empty', data);

                }
            } catch (e) {
                console.error('Success callback error:', e);

            }
        },
    
        error: function (xhr, status, error) {
            console.error('AJAX Error:', status, error);
            console.error('Response Text:', xhr.responseText);
        }
    });

    











    // ============================================
// MOBILE RESPONSIVE HAMBURGER MENU
// responsive.js
// ============================================


    
    // Toggle sidebar on hamburger click
    $('.hamburger').on('click', function(e) {
        e.stopPropagation();
        $(this).toggleClass('active');
        $('.sidebar').toggleClass('active');
        $('.sidebar-overlay').toggleClass('active');
        $('body').toggleClass('no-scroll');
    });

    // Close sidebar when clicking overlay
    $('.sidebar-overlay').on('click', function() {
        closeSidebar();
    });

    // Close sidebar when clicking a nav link on mobile
    $('.sidebar nav a').on('click', function() {
        if (window.innerWidth <= 992) {
            closeSidebar();
        }
    });

    // Function to close sidebar
    function closeSidebar() {
        $('.hamburger').removeClass('active');
        $('.sidebar').removeClass('active');
        $('.sidebar-overlay').removeClass('active');
        $('body').removeClass('no-scroll');
    }

    // Close sidebar on window resize if it's desktop view
    $(window).on('resize', function() {
        if (window.innerWidth > 992) {
            closeSidebar();
        }
    });


});

