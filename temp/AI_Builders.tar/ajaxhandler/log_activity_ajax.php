<?php
session_start();
include __DIR__ . '/../database/database.php';
include __DIR__ . '/../php/activity_log.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit;
}

// Check if user is logged in
if (!isset($_SESSION["current_user"])) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

// Database object
$dbo = new Database();

// Get POST data
$role = $_POST['role'] ?? 'Unknown';   // Role sent from page: Faculty / Student
$user_id = $_SESSION["current_user"];  // ID from session
$module = $_POST['module'] ?? 'Unknown Module';
$action = $_POST['action'] ?? 'Unknown Action';
$status = $_POST['status'] ?? 'Completed';

// Fetch name based on role
$user_name = 'Unknown';
if ($role === 'Faculty') {
    $stmt = $dbo->conn->prepare("SELECT name FROM faculty_details WHERE id = :id");
    $stmt->execute([':id' => $user_id]);
    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $user_name = $row['name'];
    }
} elseif ($role === 'Student') {
    $stmt = $dbo->conn->prepare("SELECT name FROM student_details WHERE id = :id");
    $stmt->execute([':id' => $user_id]);
    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $user_name = $row['name'];
    }
}

// Get IP, User Agent, Location
$ip_address = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'UNKNOWN';
$location_json = @file_get_contents("http://ip-api.com/json/{$ip_address}");
$location_data = json_decode($location_json, true);
$country = $location_data['country'] ?? 'UNKNOWN';
$city = $location_data['city'] ?? 'UNKNOWN';

// Call the logActivity function
logActivity($dbo, $user_id, $user_name, $role, $module, $action, $status);

echo json_encode(['status' => 'success', 'message' => 'Activity logged']);
