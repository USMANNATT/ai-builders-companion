<?php
header('Content-Type: application/json');
session_start();

require_once __DIR__ . '/../config/database.php';

if (empty($_SESSION['current_user'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['token']) || strlen($input['token']) < 100 || strlen($input['token']) > 512) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid token']);
    exit;
}

$token      = trim($input['token']);
$userId = (int) $_SESSION['current_user'];
$deviceType = in_array($input['device_type'] ?? '', ['android','ios','web']) ? $input['device_type'] : 'web';
$browser    = substr($input['browser'] ?? '', 0, 100);

try {
    $pdo = getDB();
    $stmt = $pdo->prepare(
        'INSERT INTO fcm_tokens (user_id, token, device_type, browser, is_active)
         VALUES (:user_id, :token, :device_type, :browser, 1)
         ON DUPLICATE KEY UPDATE
         user_id = :user_id2,
         is_active = 1,
         last_used_at = CURRENT_TIMESTAMP'
    );
    $stmt->execute([
        ':user_id'     => $userId,
        ':token'       => $token,
        ':device_type' => $deviceType,
        ':browser'     => $browser,
        ':user_id2'    => $userId,
    ]);
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    error_log('save_token error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Server error']);
}