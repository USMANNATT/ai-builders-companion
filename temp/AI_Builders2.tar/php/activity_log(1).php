<?php
// Make sure database.php is included in your main files before using this function
function logActivity($dbo, $user_id, $user_name, $role, $module, $action, $status) {
    try {
        // Get IP address
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';

        // Get user agent
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'UNKNOWN';

        // Get location using IP API (ip-api.com)
        $location_json = @file_get_contents("http://ip-api.com/json/{$ip_address}");
        $location_data = json_decode($location_json, true);
        $country = $location_data['country'] ?? 'UNKNOWN';
        $city = $location_data['city'] ?? 'UNKNOWN';

        // Prepare SQL query using PDO
        $stmt = $dbo->conn->prepare("INSERT INTO activity_log
            (user_id, user_name, role, module, action, status, ip_address, country, city, user_agent, created_at)
            VALUES (:user_id, :user_name, :role, :module, :action, :status, :ip_address, :country, :city, :user_agent, NOW())");

        // Bind parameters
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':user_name', $user_name);
        $stmt->bindParam(':role', $role);
        $stmt->bindParam(':module', $module);
        $stmt->bindParam(':action', $action);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':ip_address', $ip_address);
        $stmt->bindParam(':country', $country);
        $stmt->bindParam(':city', $city);
        $stmt->bindParam(':user_agent', $user_agent);

        // Execute
        $stmt->execute();

    } catch (PDOException $e) {
        // Log error (optional)
        error_log("Activity Logging Failed: " . $e->getMessage());
    }
}
?>
