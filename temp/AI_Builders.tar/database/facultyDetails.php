<?php
// Get root folder path
$path = $_SERVER['DOCUMENT_ROOT']; 

// Include database connection file
require_once $path."/AI_Builders/database/database.php";

class faculty_details {


    // Function to verify user login
    public function verifyUser($dbo, $un, $pw){

    
        // make na assocative php array which store user id and password 
        $rv = ["id" => -1, "status" => "ERROR"];   // Default response

        // SQL QUERY TO GET USER ID AND PASSWORD FROM `faculty_details`TABLE 
        // WE HAVE SELECTED ID BECAUSE WE USE IT LATER WHEN WE WANT TO START A SESSION FOR THE USER
        // WE WILL STORE THIS ID IN THE SESSION TO IDENTIFY THE LOGGED-IN USER
        // THIS ID WILL BE USED THROUGHOUT THE APPLICATION TO FETCH USER-SPECIFIC DATA
        // FOR EXAMPLE, WHEN THE USER LOGS IN, WE CAN USE THIS ID TO RETRIEVE THEIR PROFILE INFORMATION, COURSES, ETC.
        // THIS APPROACH ENSURES THAT WE HAVE A UNIQUE IDENTIFIER FOR EACH USER, MAKING IT EASIER TO MANAGE USER SESSIONS AND DATA.
        // ALSO, STORING THE ID IN THE SESSION RATHER THAN THE USERNAME OR OTHER SENSITIVE INFORMATION ENHANCES SECURITY.
        // IT IS A COMMON PRACTICE IN WEB APPLICATIONS TO USE A UNIQUE IDENTIFIER LIKE USER ID FOR SESSION MANAGEMENT.
        // THIS WAY, EVEN IF THE USERNAME CHANGES, THE SESSION REMAINS VALID AS IT IS TIED TO THE USER ID.
        // THIS IS ESPECIALLY IMPORTANT IN APPLICATIONS WHERE USERS MAY HAVE THE ABILITY TO UPDATE THEIR PROFILE INFORMATION.
        // OVERALL, SELECTING THE ID DURING LOGIN VERIFICATION IS A BEST PRACTICE THAT AIDS IN EFFECTIVE USER MANAGEMENT AND SECURITY.
        $c = "SELECT id, password FROM faculty_details WHERE user_name = :un"; // :un PLACHOLDER FOR USERNAME

        // Prepare query
        $s = $dbo->conn->prepare($c);

        try {
            // Execute query with username
            $s->execute([":un" => $un]);

            // Check if user exists
            if ($s->rowCount() > 0) {

                // Fetch user data
                $result = $s->fetch(PDO::FETCH_ASSOC);

                // Verify entered password with hashed password
                if (password_verify($pw, $result['password'])) {

                    // Login successful
                    $rv = ["id" => $result['id'], "status" => "ALLOK"];

                } else {
                    // Password is wrong
                    $rv = ["id" => $result['id'], "status" => "WRONG PASSWORD"];
                }

            } else {
                // Username not found
                $rv = ["id" => -1, "status" => "Username does not exist"];
            }

        } catch (Throwable $th) {
            // Error handling (optional)
        }

        return $rv;
    }
    // function to get faculty name using faculty id
    public function getFacultyName($dbo, $facid){
        $name= "";
        $c = "select name from faculty_details where id=:facid";
        $s = $dbo->conn->prepare($c);
        try {
            $s->execute([":facid"=>$facid]);
            // 
            $result = $s->fetch(PDO::FETCH_ASSOC);
            $name= $result['name'];

        }

        catch (Exception $e) {
            error_log("getFacultyName Error: " . $e->getMessage());
        }
        
        echo json_encode(['name' => $name]);
        exit();
    }


    // function get courses in a session for the user who is logged-in
    /**
     * Retrieves a list of courses assigned to a specific faculty member for a given session.
     *
     * This method queries the database to fetch course details including the course ID,
     * course code, and course title for courses that are allotted to a faculty member
     * identified by the faculty ID in a specific session identified by the session ID.
     *
     * PDO $dbo The database connection object.
     * $sessionid The ID of the session for which courses are to be retrieved.
     * $facid The ID of the faculty member whose courses are to be fetched.
     * An associative array containing course details (id,course_code,course_title).
     * Returns an empty array if no courses are found or an error occurs.
     */

    public function getCoursesInASession($dbo,$sessionid,$facid){
        $rv= [];
        // SQL QUERY TO GET COURSES ALLOTTED TO A FACULTY IN A SESSION
        // WE ARE JOINING TWO TABLES: course_allotment (ca) AND course_details (cd)
        // THE JOIN IS BASED ON THE CONDITION THAT THE course_id IN course_allotment MATCHES THE id IN course_details
        // THIS ALLOWS US TO RETRIEVE DETAILED INFORMATION ABOUT THE COURSES ALLOTTED TO THE FACULTY
        // WE ARE FILTERING THE RESULTS BASED ON THE faculty_id AND session_id TO GET COURSES SPECIFIC TO THE FACULTY AND SESSION
        // THE SELECTED FIELDS ARE cd.id, cd.course_code, AND cd.course_title WHICH PROVIDE ESSENTIAL INFORMATION ABOUT EACH COURSE
        // THIS QUERY IS USEFUL FOR DISPLAYING THE COURSES A FACULTY MEMBER IS RESPONSIBLE FOR IN A PARTICULAR ACADEMIC SESSION
        // THIS FUNCTION RETURNS AN ASSOCIATIVE ARRAY OF COURSES THAT CAN BE USED IN THE APPLICATION FOR VARIOUS PURPOSES SUCH AS ATTENDANCE TRACKING, SYLLABUS MANAGEMENT, ETC.
        // IT IS IMPORTANT TO HANDLE ANY POTENTIAL ERRORS DURING QUERY EXECUTION TO ENSURE THE APPLICATION REMAINS STABLE AND PROVIDES FEEDBACK IF SOMETHING GOES WRONG.
        // OVERALL, THIS FUNCTION IS A CRUCIAL PART OF FACULTY MANAGEMENT IN AN ACADEMIC SYSTEM.
        $c = "select cd.id,cd.course_code,cd.course_title
        from course_allotment as ca,
        course_details as cd
        where ca.course_id=cd.id 
        and faculty_id=:facid
        and session_id =:sessionid";

        // Prepare query
        $s = $dbo->conn->prepare($c);

        // Execute query and fetch results
        try {
            $s->execute([":facid"=>$facid, ":sessionid"=>$sessionid]);
            $rv = $s->fetchAll(PDO::FETCH_ASSOC);

        }

        catch (Exception $e) {
            error_log("getCoursesInASession Error: " . $e->getMessage());
        }
        

        return $rv;
    }
}
?>
