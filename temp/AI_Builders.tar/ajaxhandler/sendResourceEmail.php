<?php
/**
 * sendResourceEmail.php
 * Functions only — no top-level executable code.
 * PHPMailer autoloaded by the calling script.
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendResourceEmail($dbo, int $course_id, string $resource_type, string $title, string $description): array
{
    try {
        $stmt = $dbo->conn->prepare("
            SELECT sd.name, sd.email, c.course_title, c.course_code
            FROM course_registration cr
            JOIN student_details sd ON sd.id = cr.student_id
            JOIN course_details   c  ON c.id  = cr.course_id
            WHERE cr.course_id = :course_id
              AND sd.email IS NOT NULL AND sd.email <> ''
        ");
        $stmt->execute([':course_id' => $course_id]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return ['sent' => 0, 'failed' => 0, 'errors' => ['DB: ' . $e->getMessage()]];
    }

    if (empty($students)) {
        return ['sent' => 0, 'failed' => 0, 'errors' => ['No enrolled students']];
    }

    $courseTitle = $students[0]['course_title'] ?? 'Course';
    $courseCode  = $students[0]['course_code']  ?? '';
    $subject     = $courseCode . ' — New ' . strtoupper($resource_type) . ': ' . $title;

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host          = 'smtp.hostinger.com';
        $mail->SMTPAuth      = true;
        $mail->Username      = 'admin@aibuilderss.com';
        $mail->Password      = '!AvG2Ae5';
        $mail->SMTPSecure    = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port          = 587;
        $mail->Timeout       = 10;
        $mail->SMTPKeepAlive = true;
        $mail->SMTPDebug     = 0;
        $mail->setFrom('admin@aibuilderss.com', 'AI Builders');
        $mail->isHTML(true);
    } catch (Exception $e) {
        return ['sent' => 0, 'failed' => 0, 'errors' => ['SMTP setup: ' . $e->getMessage()]];
    }

    $sent = 0; $failed = 0; $errors = [];

    foreach ($students as $student) {
        $htmlBody = buildResourceEmailBody(
            $student['name'], $courseCode, $courseTitle,
            $resource_type, $title, $description
        );
        try {
            $mail->clearAddresses();
            $mail->addAddress(trim($student['email']), trim($student['name']));
            $mail->Subject = $subject;
            $mail->Body    = $htmlBody;
            $mail->AltBody = strip_tags(str_replace('<br>', "\n", $htmlBody));
            $mail->send();
            $sent++;
        } catch (Exception $e) {
            $failed++;
            $errors[] = $student['email'] . ': ' . $mail->ErrorInfo;
        }
    }

    $mail->smtpClose();
    return ['sent' => $sent, 'failed' => $failed, 'errors' => $errors];
}

function buildResourceEmailBody(
    string $studentName, string $courseCode, string $courseTitle,
    string $resourceType, string $resourceTitle, string $resourceDesc
): string {
    $s  = fn($v) => htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
    $desc = $resourceDesc ? nl2br($s($resourceDesc)) : 'No description provided.';
    $date = date('d M Y, h:i A');

    return <<<HTML
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><style>
body{font-family:Arial,sans-serif;background:#f4f4f4;margin:0;padding:0}
.w{max-width:600px;margin:30px auto;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.1)}
.h{background:#1a1a2e;color:#fff;padding:24px 32px}
.h h1{margin:0;font-size:20px}
.h p{margin:4px 0 0;font-size:13px;opacity:.8}
.badge{display:inline-block;background:#e94560;color:#fff;border-radius:4px;padding:4px 12px;font-size:12px;font-weight:bold;text-transform:uppercase}
.b{padding:28px 32px;color:#333;line-height:1.7}
.box{background:#f8f8f8;border-left:4px solid #1a1a2e;border-radius:4px;padding:16px 20px;margin:16px 0}
.box h2{margin:0 0 6px;font-size:16px;color:#1a1a2e}
.box p{margin:0;font-size:14px;color:#555}
.cta{display:inline-block;margin-top:20px;padding:10px 24px;background:#1a1a2e;color:#fff;border-radius:5px;text-decoration:none;font-size:14px;font-weight:bold}
.f{padding:16px 32px;background:#f0f0f0;font-size:12px;color:#888;text-align:center}
</style></head><body>
<div class="w">
  <div class="h"><h1>AI Builders — New Resource</h1><p>{$s($courseCode)} · {$s($courseTitle)}</p></div>
  <div class="b">
    <p>Dear <strong>{$s($studentName)}</strong>,</p>
    <p>Your instructor has uploaded a new resource:</p>
    <span class="badge">{$s(strtoupper($resourceType))}</span>
    <div class="box"><h2>{$s($resourceTitle)}</h2><p>{$desc}</p></div>
    <p>Log in to view and download this resource.</p>
    <a href="https://aibuilderss.com/AI_Builders/dashboard.php" class="cta">Go to Portal →</a>
    <p style="margin-top:24px">Best regards,<br><strong>AI Builders Team</strong></p>
  </div>
  <div class="f">Sent on {$date} · Automated notification — do not reply.</div>
</div>
</body></html>
HTML;
}
