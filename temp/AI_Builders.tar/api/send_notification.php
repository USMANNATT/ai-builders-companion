<?php
header('Content-Type: application/json');
session_start();

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/helpers/fcm_helper.php';

if (empty($_SESSION['admin_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Forbidden']);
    exit;
}

$input       = json_decode(file_get_contents('php://input'), true);
$title       = trim($input['title'] ?? '');
$body        = trim($input['body'] ?? '');
$url         = trim($input['url'] ?? '/AI_Builders/');
$type        = $input['type'] ?? 'announcement';
$targetType  = $input['target_type'] ?? 'all';
$targetValue = $input['target_value'] ?? null;

if (!$title || !$body) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Title and body required']);
    exit;
}

try {
    $pdo = getDB();

    if ($targetType === 'single' && $targetValue) {
        $stmt = $pdo->prepare('SELECT id, token FROM fcm_tokens WHERE user_id = ? AND is_active = 1');
        $stmt->execute([(int)$targetValue]);
    } elseif ($targetType === 'group' && $targetValue) {
        $ids = array_map('intval', explode(',', $targetValue));
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("SELECT id, token FROM fcm_tokens WHERE user_id IN ($placeholders) AND is_active = 1");
        $stmt->execute($ids);
    } else {
        $stmt = $pdo->query('SELECT id, token FROM fcm_tokens WHERE is_active = 1');
    }

    $tokens = $stmt->fetchAll();

    if (empty($tokens)) {
        echo json_encode(['success' => true, 'message' => 'No active tokens', 'sent' => 0]);
        exit;
    }

    $sentCount = 0;
    $failedCount = 0;
    $expiredIds = [];

    foreach ($tokens as $row) {
        $result = sendFcmNotification($row['token'], $title, $body, $url, $type);
        if ($result['success']) {
            $sentCount++;
        } else {
            $failedCount++;
            if ($result['error'] === 'TOKEN_EXPIRED') {
                $expiredIds[] = $row['id'];
            }
        }
    }

    if (!empty($expiredIds)) {
        $ph = implode(',', array_fill(0, count($expiredIds), '?'));
        $pdo->prepare("UPDATE fcm_tokens SET is_active = 0 WHERE id IN ($ph)")->execute($expiredIds);
    }

    echo json_encode(['success' => true, 'sent' => $sentCount, 'failed' => $failedCount]);

} catch (Exception $e) {
    error_log('send_notification error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Server error']);
}