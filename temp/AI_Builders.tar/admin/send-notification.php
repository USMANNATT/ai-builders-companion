<?php
$secret     = $_POST['secret'] ?? '';
$isInternal = ($secret === 'AI_BUILDERS_QUEUE_SECRET');

if (!$isInternal) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
    session_start();
    if (isset($_SESSION["current_user"])) {
        $facid = $_SESSION["current_user"];
    } else {
        header("Location: /AI_Builders/login.php");
        die();
    }
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/helpers/fcm_helper.php';

$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $body  = trim($_POST['body']);
    $url   = trim($_POST['url']) ?: '/AI_Builders/dashboard.php';
    $type  = $_POST['type'] ?? 'announcement';
    $target = $_POST['target'] ?? 'all';
    $userId = $_POST['user_id'] ?? null;

    $pdo = getDB();

    if ($target === 'single' && $userId) {
        $stmt = $pdo->prepare('SELECT id, token FROM fcm_tokens WHERE user_id = ? AND is_active = 1');
        $stmt->execute([(int)$userId]);
    } else {
        $stmt = $pdo->query('SELECT id, token FROM fcm_tokens WHERE is_active = 1');
    }

    $tokens = $stmt->fetchAll();
    $sent = 0; $failed = 0; $expired = [];

    foreach ($tokens as $row) {
        $res = sendFcmNotification($row['token'], $title, $body, $url, $type);
        if ($res['success']) {
            $sent++;
        } else {
            $failed++;
            if ($res['error'] === 'TOKEN_EXPIRED') $expired[] = $row['id'];
        }
    }

    if (!empty($expired)) {
        $ph = implode(',', array_fill(0, count($expired), '?'));
        $pdo->prepare("UPDATE fcm_tokens SET is_active=0 WHERE id IN ($ph)")->execute($expired);
    }

    $result = "✅ Sent: $sent | ❌ Failed: $failed";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Send Notification</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: Arial; max-width: 600px; margin: 40px auto; padding: 20px; }
        input, select, textarea { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; }
        button { background: #1A56DB; color: white; padding: 12px 30px; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; }
        .result { background: #d4edda; padding: 15px; border-radius: 6px; margin-bottom: 20px; font-size: 18px; }
    </style>
</head>
<body>
    <h2>📢 Send Push Notification</h2>
    <?php if ($result): ?>
        <div class="result"><?= $result ?></div>
    <?php endif; ?>
    <form method="POST">
        <label>Title</label>
        <input type="text" name="title" required placeholder="e.g. New Announcement">
        
        <label>Message</label>
        <textarea name="body" required rows="3" placeholder="Notification message..."></textarea>
        
        <label>Type</label>
        <select name="type">
            <option value="announcement">Announcement</option>
            <option value="test_reminder">Test Reminder</option>
            <option value="result">Result Upload</option>
            <option value="alert">Important Alert</option>
        </select>
        
        <label>Click URL</label>
        <input type="text" name="url" placeholder="https://aibuilderss.com/AI_Builders/dashboard.php">
        
        <label>Send To</label>
        <select name="target" onchange="document.getElementById('uid').style.display=this.value==='single'?'block':'none'">
            <option value="all">All Users</option>
            <option value="single">Single User</option>
        </select>
        
        <input type="number" name="user_id" id="uid" placeholder="Enter User ID" style="display:none">
        
        <button type="submit">🚀 Send Notification</button>
    </form>
</body>
</html>