<?php
session_start();

header("Content-Type: application/json");

require_once(__DIR__ . "/../database/database.php");
require_once(__DIR__ . "/../database/resultDetails.php");

$dbo = new Database();
$rbo = new result_details();

$action = $_POST['action'] ?? '';

if($action === "getStudentResults"){

    $student_id = $_POST['student_id'] ?? '';
    $course_id  = $_POST['course_id'] ?? '';

    if(empty($student_id) || empty($course_id)){
        echo json_encode([
            "status" => "ERROR",
            "message" => "Invalid request"
        ]);
        exit;
    }

    try{

        $data = $rbo->getStudentFullResults($dbo, $student_id, $course_id);

        echo json_encode([
            "status" => "ALLOK",
            "course" => $data['course'],
            "session" => $data['session'],
            "results" => $data['results'],
            "overall" => $data['overall']
        ]);
        exit;

    } catch(Exception $e){

        echo json_encode([
            "status" => "ERROR",
            "message" => $e->getMessage()
        ]);
        exit;
    }
}

echo json_encode([
    "status" => "ERROR",
    "message" => "Invalid Action"
]);
exit;
