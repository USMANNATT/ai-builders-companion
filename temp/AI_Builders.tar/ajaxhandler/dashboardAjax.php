<?php
// ===============================
// TURN OFF ERROR DISPLAY FOR AJAX
// Errors must NEVER mix into JSON output
// ===============================
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

// Always return JSON content type
header('Content-Type: application/json');

// ===============================
// INCLUDE DATABASE CONNECTION
// ===============================
require_once(__DIR__ . "/../database/database.php");
require_once(__DIR__ . "/../database/LeaveDetails.php");
require_once(__DIR__ . "/../database/studentDetails.php");
require_once(__DIR__ . "/../database/courseRegistrationDetails.php");

// Get action sent from frontend
$action = $_REQUEST["action"] ?? '';

if (empty($action)) {
    echo json_encode(["status" => "error", "message" => "No action provided."]);
    exit;
}

$dbo = new Database();

// ===============================
// ACTION: getStudentName
// ===============================
if ($action == "getStudentName") {
    $studentId = $_POST["studentId"] ?? '';
    $sdo = new student_details();
    $rv  = $sdo->getStudentInfo($dbo, $studentId);   // ← was getStudentName, fixed to getStudentInfo
    echo json_encode($rv ?: ["status" => "error", "message" => "Student not found."]);
    exit;
}

// ===============================
// ACTION: fetchLeaves
// ===============================
if ($action == "fetchLeaves") {
    $studentId = $_POST["studentId"] ?? '';
    $lro = new leave_requests();
    $rv  = $lro->fetchLeaves($dbo, $studentId);
    echo json_encode($rv);
    exit;
}

// ===============================
// ACTION: getStudentSubjects
// ===============================
if ($action === "getStudentSubjects") {
    $student_id = $_POST['student_id'] ?? '';
    $crgo    = new CourseRegistrationDetails();
    $subjects = $crgo->getSubjectsByStudent($dbo, $student_id);
    echo json_encode($subjects);
    exit;
}

// ===============================
// ACTION: getSubjectName
// ===============================
if ($action === "getSubjectName") {
    $course_id   = $_POST['course_id'] ?? '';
    $crgo        = new CourseRegistrationDetails();
    $subjectName = $crgo->getSubjectName($dbo, $course_id);
    echo json_encode($subjectName);
    exit;
}

// Fallback
echo json_encode(["status" => "error", "message" => "Unknown action: $action"]);
?>