/**
 * login.js — AI Builders Login (jQuery version)
 * ─────────────────────────────────────────────
 * Requires: jQuery loaded via assets/js/jquery.js BEFORE this file.
 * Place at: AI_Builders/assets/js/login.js
 *
 * DEBUG: Open DevTools → Console tab.
 * Every step prints [LOGIN] messages so you can trace exactly where it fails.
 */

$(function () {

    /* ══════════════════════════════════════════════════════
       CONFIG — update if your paths ever change
    ══════════════════════════════════════════════════════ */
    var AJAX_URL         = 'ajaxhandler/loginAjax.php'; // relative to login.php (AI_Builders root)
    var REDIRECT_DEFAULT = '/AI_Builders/dashboard.php';

    /* ══════════════════════════════════════════════════════
       CACHE ELEMENTS
    ══════════════════════════════════════════════════════ */
    var $un       = $('#txtUsername');
    var $pw       = $('#txtPassword');
    var $btn      = $('#btnLogin');
    var $eye      = $('#togglePassword');
    var $loader   = $('#loginLoader');
    var $status   = $('#loaderStatus');
    var $feedback = $('#loginFeedback');

    /* ══════════════════════════════════════════════════════
       STARTUP DIAGNOSTICS — always visible in console
    ══════════════════════════════════════════════════════ */
    console.log('[LOGIN] jQuery:', $.fn.jquery);
    console.log('[LOGIN] #txtUsername :', $un.length      ? 'FOUND' : 'MISSING ⚠');
    console.log('[LOGIN] #txtPassword :', $pw.length      ? 'FOUND' : 'MISSING ⚠');
    console.log('[LOGIN] #btnLogin    :', $btn.length     ? 'FOUND' : 'MISSING ⚠');
    console.log('[LOGIN] #loginFeedback:', $feedback.length ? 'FOUND' : 'MISSING ⚠');
    console.log('[LOGIN] #loginLoader :', $loader.length  ? 'FOUND' : 'MISSING ⚠');
    console.log('[LOGIN] AJAX target  :', AJAX_URL);

    /* If any critical element is missing, stop here and say so */
    if (!$un.length || !$pw.length || !$btn.length) {
        console.error('[LOGIN ERROR] One or more required elements not found. Aborting init.');
        return;
    }

    /* ══════════════════════════════════════════════════════
       VISUAL STATE — colour only, NEVER set disabled attr
    ══════════════════════════════════════════════════════ */
    function updateBtn() {
        /* Use native .value — jQuery .val() can miss autofilled content */
        var ready = $un[0].value.trim() !== '' && $pw[0].value.trim() !== '';
        $btn.toggleClass('activecolor',   ready)
            .toggleClass('inactivecolor', !ready);
        /* disabled is intentionally NOT set — it blocks all click events */
    }

    /* ══════════════════════════════════════════════════════
       AUTOFILL POLL — catches browser autofill at any timing
    ══════════════════════════════════════════════════════ */
    var ticks = 0;
    var poll  = setInterval(function () {
        updateBtn();
        if (++ticks >= 25) clearInterval(poll); // 5 seconds
    }, 200);

    /* ══════════════════════════════════════════════════════
       FIELD EVENTS
    ══════════════════════════════════════════════════════ */
    $un.add($pw).on('keyup keydown input change paste cut', function () {
        clearMsg();
        updateBtn();
    });

    /* Chrome/Safari autofill CSS-animation detection */
    $un.add($pw).on('animationstart webkitAnimationStart', function (e) {
        var name = (e.originalEvent || e).animationName;
        if (name === 'onAutoFillStart') {
            console.log('[LOGIN] Autofill detected —', this.id);
            setTimeout(updateBtn, 50);
        }
    });

    /* Enter key in either field submits */
    $un.add($pw).on('keypress', function (e) {
        if (e.which === 13) { e.preventDefault(); handleLogin(); }
    });

    /* ══════════════════════════════════════════════════════
       LOGIN BUTTON — the one that was "not working"
    ══════════════════════════════════════════════════════ */
    $btn.on('click', function (e) {
        e.preventDefault();
        console.log('[LOGIN] Button clicked ✓');
        handleLogin();
    });

    /* ══════════════════════════════════════════════════════
       PASSWORD EYE TOGGLE
    ══════════════════════════════════════════════════════ */
    $eye.on('click', function () {
        var hidden = $pw.attr('type') === 'password';
        $pw.attr('type', hidden ? 'text' : 'password');
        $eye.html(hidden ? iconEyeClosed : iconEyeOpen);
    });

    var iconEyeOpen = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none">'
        + '<path d="M10 4.16667C5.83333 4.16667 2.27499 6.73333 0.833328 10.4167C2.27499 14.1 5.83333'
        + ' 16.6667 10 16.6667C14.1667 16.6667 17.725 14.1 19.1667 10.4167C17.725 6.73333 14.1667'
        + ' 4.16667 10 4.16667ZM10 14.5833C7.69999 14.5833 5.83333 12.7167 5.83333 10.4167C5.83333'
        + ' 8.11667 7.69999 6.25 10 6.25C12.3 6.25 14.1667 8.11667 14.1667 10.4167C14.1667 12.7167'
        + ' 12.3 14.5833 10 14.5833ZM10 7.91667C8.61666 7.91667 7.49999 9.03333 7.49999 10.4167'
        + 'C7.49999 11.8 8.61666 12.9167 10 12.9167C11.3833 12.9167 12.5 11.8 12.5 10.4167'
        + 'C12.5 9.03333 11.3833 7.91667 10 7.91667Z" fill="#9CA3AF"/></svg>';

    var iconEyeClosed = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none">'
        + '<path d="M2.5 2.5L17.5 17.5M8.232 8.232A2.5 2.5 0 0010 7.5a2.5 2.5 0 012.5 2.5'
        + 'c0 .663-.257 1.265-.674 1.712M6.326 6.326A4.167 4.167 0 006.25 8.333a3.75 3.75 0'
        + ' 003.75 3.75c.741 0 1.432-.21 2.02-.574m2.43-2.43A3.74 3.74 0 0013.75 8.333a3.75'
        + ' 3.75 0 00-3.75-3.75c-.543 0-1.059.115-1.526.323M4.167 4.167C2.558 5.338 1.22 6.73'
        + ' .417 8.333c1.667 3.333 5 5.833 9.583 5.833a11.6 11.6 0 003.75-.625M8.333 3.75'
        + 'A9.35 9.35 0 0110 3.583c4.583 0 7.917 2.5 9.583 5.833-.5 1-1.25 1.917-2.167 2.667"'
        + ' stroke="#9CA3AF" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

    /* ══════════════════════════════════════════════════════
       FORGOT PASSWORD LINK
    ══════════════════════════════════════════════════════ */
    $('.forgot-password').on('click', function (e) {
        e.preventDefault();
        window.location.href = 'php/changePassword.php';
    });

    /* ══════════════════════════════════════════════════════
       HANDLE LOGIN — validate then send
    ══════════════════════════════════════════════════════ */
    function handleLogin() {
        var username = $un[0].value.trim();
        var password = $pw[0].value.trim();

        console.log('[LOGIN] Username:', username || '(empty)');
        console.log('[LOGIN] Password:', password ? '••••••' : '(empty)');

        if (!username && !password) {
            showMsg('error', 'Please enter your username and password.');
            $un.focus(); return;
        }
        if (!username) {
            showMsg('error', 'Please enter your username.');
            $un.focus(); return;
        }
        if (!password) {
            showMsg('error', 'Please enter your password.');
            $pw.focus(); return;
        }

        doLogin(username, password);
    }

    /* ══════════════════════════════════════════════════════
       JQUERY $.ajax REQUEST
    ══════════════════════════════════════════════════════ */
    function doLogin(username, password) {
        var savedLabel = $btn.text().trim();

        /* Lock button visually during request */
        $btn.removeClass('activecolor')
            .addClass('inactivecolor')
            .css('pointer-events', 'none')
            .text('Signing in…');

        clearMsg();
        showLoader('Verifying credentials…');

        console.log('[LOGIN] Sending POST →', AJAX_URL);

        $.ajax({
            url:      AJAX_URL,
            type:     'POST',
            dataType: 'json',
            timeout:  15000,
            data: {
                action:    'verifyUser',
                user_name: username,
                password:  password
            },

            success: function (res) {
                console.log('[LOGIN] Response received:', res);

                if (res && res.status === 'ALLOK') {
                    var dest = res.redirect || REDIRECT_DEFAULT;
                    console.log('[LOGIN] ✓ Login OK — role:', res.role, '— going to:', dest);
                    setLoaderText('Login successful! Redirecting…');
                    $loader.addClass('is-success');
                    setTimeout(function () {
                        window.location.replace(dest);
                    }, 900);

                } else {
                    var errMsg = (res && res.status)  ? res.status
                               : (res && res.message) ? res.message
                               : 'Login failed. Please check your credentials.';
                    console.warn('[LOGIN] Rejected:', errMsg);
                    hideLoader();
                    showMsg('error', errMsg);
                    restoreBtn(savedLabel);
                }
            },

            error: function (xhr, textStatus) {
                console.error('[LOGIN ERROR] AJAX error — textStatus:', textStatus);
                console.error('[LOGIN ERROR] HTTP status:', xhr.status);
                console.error('[LOGIN ERROR] Raw response:', xhr.responseText);

                var errMsg;
                switch (true) {
                    case textStatus === 'timeout':
                        errMsg = 'Request timed out. Please try again.'; break;
                    case xhr.status === 404:
                        errMsg = 'Login handler not found (404). Check that ajaxhandler/loginAjax.php exists.'; break;
                    case xhr.status === 500:
                        errMsg = 'Server error (500). Check PHP error logs.'; break;
                    case xhr.status === 0:
                        errMsg = 'Cannot reach server. Check your connection.'; break;
                    default:
                        errMsg = 'Error (' + xhr.status + '). See console for details.';
                }

                /* Try to get a cleaner message from PHP JSON error */
                try {
                    var p = JSON.parse(xhr.responseText);
                    if (p && p.message) errMsg = p.message;
                } catch (ignore) {}

                hideLoader();
                showMsg('error', errMsg);
                restoreBtn(savedLabel);
            }
        });
    }

    /* ══════════════════════════════════════════════════════
       LOADER
    ══════════════════════════════════════════════════════ */
    function showLoader(txt) {
        $status.text(txt || 'Please wait…');
        $loader.removeClass('is-success').addClass('is-visible');
    }
    function hideLoader() {
        $loader.removeClass('is-visible is-success');
    }
    function setLoaderText(txt) { $status.text(txt); }

    /* ══════════════════════════════════════════════════════
       FEEDBACK
    ══════════════════════════════════════════════════════ */
    function showMsg(type, text) {
        $feedback
            .removeClass('feedback-error feedback-success feedback-info')
            .addClass('feedback-' + type)
            .text(text)
            .show();
        try { $feedback[0].scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }
        catch (e) {}
    }
    function clearMsg() {
        $feedback.hide().text('').removeClass('feedback-error feedback-success feedback-info');
    }

    /* ══════════════════════════════════════════════════════
       BUTTON RESTORE
    ══════════════════════════════════════════════════════ */
    function restoreBtn(label) {
        $btn.css('pointer-events', '').text(label || 'Login');
        updateBtn();
    }

    /* ══════════════════════════════════════════════════════
       PUBLIC API
    ══════════════════════════════════════════════════════ */
    window.LoginPage = {
        clearForm: function () {
            $un.val(''); $pw.val('');
            clearMsg(); updateBtn();
        }
    };

    console.log('[LOGIN] Ready ✓ — all events bound, button is clickable');
});