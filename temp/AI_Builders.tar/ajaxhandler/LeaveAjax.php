<?php
// ===============================
// DISPLAY ALL ERRORS FOR TESTING
// ===============================
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Going to root directory
$path = $_SERVER['DOCUMENT_ROOT'];

// ===============================
// INCLUDE DATABASE CONNECTION
// ===============================
require_once $path . "/AI_Builders/database/database.php";
require_once $path . "/AI_Builders/database/courseRegistrationDetails.php";
require_once $path . "/AI_Builders/database/LeaveDetails.php";       // ← lowercase 'l', match your actual filename
require_once $path . "/AI_Builders/database/studentDetails.php";

$action = $_REQUEST['action'] ?? '';

if (empty($action)) {
    echo json_encode(["status" => "error", "message" => "No action provided."]);
    exit;
}

$dbo = new Database();

// ================================================
// ACTION: getStudentInfo
// Returns name and roll_no for the logged-in student
// ================================================
if ($action === 'getStudentInfo') {

    $studentId = $_POST['studentId'] ?? '';

    if (empty($studentId)) {
        echo json_encode(["status" => "error", "message" => "No student ID provided."]);
        exit;
    }

    $sdo  = new student_details();
    $info = $sdo->getStudentInfo($dbo, $studentId);

    echo json_encode($info ?: ["status" => "error", "message" => "Student not found."]);
    exit;
}

// ================================================
// ACTION: getStudentSubjects
// Returns all registered subjects for the student
// including teacher info (name, email)
// ================================================
if ($action === 'getStudentSubjects') {

    $studentId = $_POST['studentId'] ?? '';

    if (empty($studentId)) {
        echo json_encode(["status" => "error", "message" => "No student ID provided."]);
        exit;
    }

    $crd      = new CourseRegistrationDetails();
    $subjects = $crd->getRegisteredSubjectsWithTeacher($dbo, $studentId);

    echo json_encode($subjects ?: []);
    exit;
}

// ================================================
// ACTION: getleaveDetails  (Faculty dashboard)
// ================================================
if ($action === 'getleaveDetails') {

    $facid = $_POST['facid'] ?? '';

    $leaveDetailsObject = new leave_requests();
    $leaveDetails       = $leaveDetailsObject->getLeaveDetails($dbo, $facid);
    echo json_encode($leaveDetails);
    exit;
}

// ================================================
// ACTION: submitLeave
// Submits leave for each selected course
// ================================================
if ($action === 'submitLeave') {

    $rollNumber        = $_POST['rollNumber']       ?? '';
    $leaveReason       = $_POST['leaveReason']      ?? '';
    $startDate         = $_POST['startDate']        ?? '';
    $endDate           = $_POST['endDate']          ?? '';
    $hospitalName      = $_POST['hospitalName']     ?? '';
    $description       = $_POST['description']      ?? '';
    $selectedCourseIds = json_decode($_POST['selectedCourseIds'] ?? '[]', true);

    if (empty($selectedCourseIds)) {
        echo json_encode(["status" => "error", "message" => "No subjects selected."]);
        exit;
    }

    // Get student ID from roll number
    $sdo       = new student_details();
    $studentId = $sdo->getStudentId($dbo, $rollNumber);

    if (!$studentId) {
        echo json_encode(["status" => "error", "message" => "Student not found for roll number: $rollNumber"]);
        exit;
    }

    // Calculate total days
    $totalDays = (strtotime($endDate) - strtotime($startDate)) / (60 * 60 * 24) + 1;

    // Handle file upload
    $fileName = null;
    if (!empty($_FILES['fileAttachment']['name'])) {
        $fileName  = time() . "_" . basename($_FILES['fileAttachment']['name']);
        $tmpName   = $_FILES['fileAttachment']['tmp_name'];
        $uploadDir = __DIR__ . "/../uploads/";
        move_uploaded_file($tmpName, $uploadDir . $fileName);
    }

    try {
        $ldo = new leave_requests();

        foreach ($selectedCourseIds as $courseId) {
            $ldo->insertSingleLeaveById(
                $dbo,
                (int)$courseId,
                (int)$studentId,
                $leaveReason,
                $startDate,
                $endDate,
                (int)$totalDays,
                $hospitalName,
                $description,
                $fileName
            );
        }

        echo json_encode([
            "status"  => "success",
            "message" => "Leave request submitted successfully for " . count($selectedCourseIds) . " subject(s)."
        ]);

    } catch (Exception $e) {
        echo json_encode([
            "status"  => "error",
            "message" => "Leave submission failed.",
            "error"   => $e->getMessage()
        ]);
    }
    exit;
}

// Fallback
echo json_encode(["status" => "error", "message" => "Unknown action: $action"]);
?>