<?php
/**
 * sendExamResultEmail.php
 * ─────────────────────────────────────────────────────────────
 * Reusable helper: after exam results are bulk-inserted, emails
 * each student their individual marks using PHPMailer + Hostinger.
 *
 * IMPORTANT: This file contains ONLY function definitions.
 * No top-level executable code — prevents accidental output
 * before headers are sent in the calling script.
 *
 * Usage (in upload_results_Ajax.php):
 *   require_once 'sendExamResultEmail.php';
 *   $result = sendExamResultEmail($dbo, $rows, $course_id, $exam_type, $total_marks);
 *   // $result = ['sent' => n, 'failed' => n, 'errors' => [...]]
 *
 * $rows = Excel rows array: each row has ['A' => student_id or roll_no, 'B' => marks]
 * ─────────────────────────────────────────────────────────────
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Email every student in $rows their individual exam result.
 *
 * @param  object $dbo         Active Database object (uses $dbo->conn)
 * @param  array  $rows        Excel rows: [['A' => student_id/roll_no, 'B' => marks], ...]
 * @param  int    $course_id   The course whose results were uploaded
 * @param  string $exam_type   e.g. "Midterm", "Final", "Quiz"
 * @param  int    $total_marks Total marks for the exam
 * @return array  ['sent' => int, 'failed' => int, 'errors' => string[]]
 */
function sendExamResultEmail($dbo, array $rows, int $course_id, string $exam_type, int $total_marks): array
{
    // ── Increase execution time for bulk email sending ──────────────────────
    set_time_limit(300); // 5 minutes — enough for ~100 emails

    // ── 1. Fetch course info ─────────────────────────────────────────────────
    try {
        $courseStmt = $dbo->conn->prepare("
            SELECT course_title, course_code
            FROM   course_details
            WHERE  id = :course_id
            LIMIT  1
        ");
        $courseStmt->execute([':course_id' => $course_id]);
        $course = $courseStmt->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        return [
            'sent'   => 0,
            'failed' => 0,
            'errors' => ['DB error (course fetch): ' . $e->getMessage()],
        ];
    }

    $courseTitle = $course['course_title'] ?? 'Course';
    $courseCode  = $course['course_code']  ?? '';

    // ── 2. Shared SMTP config ────────────────────────────────────────────────
    $smtpHost    = 'smtp.hostinger.com';
    $smtpUser    = 'admin@aibuilderss.com';
    $smtpPass    = '!AvG2Ae5';   // ← your real SMTP password
    $smtpPort    = 587;
    $fromAddress = 'admin@aibuilderss.com';
    $fromName    = 'AI Builders';

    $sent   = 0;
    $failed = 0;
    $errors = [];

    // Email subject: "CS101 - Linear Algebra Results"
    $subject = $courseCode . ' - ' . $courseTitle . ' Results';

    // ── 3. Create ONE reusable PHPMailer instance ────────────────────────────
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host          = $smtpHost;
        $mail->SMTPAuth      = true;
        $mail->Username      = $smtpUser;
        $mail->Password      = $smtpPass;
        $mail->SMTPSecure    = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port          = $smtpPort;
        $mail->Timeout       = 10;           // reduced from 30 to 10 seconds
        $mail->SMTPKeepAlive = true;         // ← CRITICAL: reuse connection for all emails
        $mail->SMTPDebug     = 0;

        $mail->setFrom($fromAddress, $fromName);
        $mail->isHTML(true);

    } catch (Exception $e) {
        return [
            'sent'   => 0,
            'failed' => 0,
            'errors' => ['SMTP setup failed: ' . $e->getMessage()],
        ];
    }

    // ── 4. Loop through Excel rows, look up each student, send email ─────────
    foreach ($rows as $row) {

        $colA  = trim($row['A'] ?? '');
        $marks = trim($row['B'] ?? '');

        if ($colA === '' || $marks === '') {
            continue;
        }

        // ── Fetch student by id (numeric) OR roll_no (string) ────────────────
        // Excel column A may contain either:
        //   • Numeric student id  e.g. 1, 2, 3      → matched on sd.id
        //   • Roll number string  e.g. 2025-AI-61   → matched on sd.roll_no
        try {
            if (is_numeric($colA)) {
                // Column A is a number — match against student id
                $studentStmt = $dbo->conn->prepare("
                    SELECT sd.id, sd.name, sd.email, sd.roll_no
                    FROM   student_details sd
                    WHERE  sd.id = :col_a
                      AND  sd.email IS NOT NULL
                      AND  sd.email <> ''
                    LIMIT  1
                ");
                $studentStmt->execute([':col_a' => (int) $colA]);
            } else {
                // Column A is a string — match against roll_no
                $studentStmt = $dbo->conn->prepare("
                    SELECT sd.id, sd.name, sd.email, sd.roll_no
                    FROM   student_details sd
                    WHERE  sd.roll_no = :col_a
                      AND  sd.email   IS NOT NULL
                      AND  sd.email   <> ''
                    LIMIT  1
                ");
                $studentStmt->execute([':col_a' => $colA]);
            }

            $student = $studentStmt->fetch(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {
            $errors[] = "DB error for [{$colA}]: " . $e->getMessage();
            $failed++;
            continue;
        }

        if (!$student) {
            $errors[] = "No student found / no email for [{$colA}] — skipped.";
            $failed++;
            continue;
        }

        // ── Check if student is enrolled in this course ──────────────────────
        try {
            $enrollStmt = $dbo->conn->prepare("
                SELECT 1
                FROM   course_registration
                WHERE  student_id = :student_id
                  AND  course_id  = :course_id
                LIMIT  1
            ");
            $enrollStmt->execute([
                ':student_id' => $student['id'],
                ':course_id'  => $course_id,
            ]);
            $isEnrolled = $enrollStmt->fetch();

        } catch (PDOException $e) {
            $errors[] = "Enrollment check error for [{$colA}]: " . $e->getMessage();
            $failed++;
            continue;
        }

        if (!$isEnrolled) {
            $errors[] = "Student [{$colA}] not enrolled in this course — skipped.";
            $failed++;
            continue;
        }

        $recipientEmail = trim($student['email']);
        $recipientName  = trim($student['name']);
        $rollNo         = trim($student['roll_no']);

        $htmlBody = buildExamEmailBody(
            $recipientName,
            $rollNo,
            $courseCode,
            $courseTitle,
            $exam_type,
            (int) $marks,
            $total_marks
        );

        // ── Send using the shared $mail instance ─────────────────────────────
        try {
            $mail->clearAddresses();
            $mail->clearAttachments();
            
            $mail->addAddress($recipientEmail, $recipientName);
            $mail->Subject = $subject;
            $mail->Body    = $htmlBody;
            $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>'], "\n", $htmlBody));

            $mail->send();
            $sent++;

        } catch (Exception $e) {
            $failed++;
            $errors[] = "Failed [{$recipientEmail}]: " . $mail->ErrorInfo;
        }
    }

    // ── Close SMTP connection after all emails ───────────────────────────────
    $mail->smtpClose();

    return [
        'sent'   => $sent,
        'failed' => $failed,
        'errors' => $errors,
    ];
}


/**
 * Builds a clean, branded HTML exam result email body.
 */
function buildExamEmailBody(
    string $studentName,
    string $rollNo,
    string $courseCode,
    string $courseTitle,
    string $examType,
    int    $marks,
    int    $totalMarks
): string {

    $safeStudent = htmlspecialchars($studentName, ENT_QUOTES, 'UTF-8');
    $safeRollNo  = htmlspecialchars($rollNo,      ENT_QUOTES, 'UTF-8');
    $safeCode    = htmlspecialchars($courseCode,  ENT_QUOTES, 'UTF-8');
    $safeTitle   = htmlspecialchars($courseTitle, ENT_QUOTES, 'UTF-8');
    $safeType    = htmlspecialchars($examType,    ENT_QUOTES, 'UTF-8');
    $date        = date('d M Y, h:i A');

    $percentage = $totalMarks > 0 ? round(($marks / $totalMarks) * 100, 1) : 0;

    if ($percentage >= 85) {
        $perfLabel = 'Excellent';
        $perfColor = '#27ae60';
    } elseif ($percentage >= 70) {
        $perfLabel = 'Good';
        $perfColor = '#2980b9';
    } elseif ($percentage >= 50) {
        $perfLabel = 'Satisfactory';
        $perfColor = '#f39c12';
    } else {
        $perfLabel = 'Needs Improvement';
        $perfColor = '#e74c3c';
    }

    return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <style>
    body       { font-family: Arial, sans-serif; background:#f4f4f4; margin:0; padding:0; }
    .wrapper   { max-width:600px; margin:30px auto; background:#fff; border-radius:8px;
                 overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,.1); }
    .header    { background:#1a1a2e; color:#fff; padding:24px 32px; }
    .header h1 { margin:0; font-size:20px; }
    .header p  { margin:4px 0 0; font-size:13px; opacity:.8; }
    .badge     { display:inline-block; background:#e94560; color:#fff; border-radius:4px;
                 padding:4px 12px; font-size:12px; font-weight:bold; text-transform:uppercase; }
    .body      { padding:28px 32px; color:#333; line-height:1.7; }
    .meta      { font-size:13px; color:#888; margin-bottom:12px; }
    .result-box{ background:#f8f8f8; border-left:4px solid #1a1a2e; border-radius:4px;
                 padding:18px 22px; margin:16px 0; }
    .score     { font-size:28px; font-weight:bold; color:#1a1a2e; }
    .out       { font-size:14px; color:#666; margin-left:4px; }
    .perf      { display:inline-block; margin-top:8px; padding:4px 14px; border-radius:20px;
                 font-size:12px; font-weight:bold; color:#fff; background:{$perfColor}; }
    .footer    { padding:16px 32px; background:#f0f0f0; font-size:12px; color:#888;
                 text-align:center; }
  </style>
</head>
<body>
  <div class="wrapper">

    <div class="header">
      <h1>AI Builders — Exam Results</h1>
      <p>{$safeCode} &nbsp;·&nbsp; {$safeTitle}</p>
    </div>

    <div class="body">
      <p>Dear <strong>{$safeStudent}</strong>,</p>
      <p class="meta">Roll No: <strong>{$safeRollNo}</strong></p>
      <p>Your results for the following exam have been published:</p>

      <span class="badge">{$safeType}</span>

      <div class="result-box">
        <div>
          <span class="score">{$marks}</span>
          <span class="out">/ {$totalMarks} &nbsp;({$percentage}%)</span>
        </div>
        <span class="perf">{$perfLabel}</span>
      </div>
      <p>Log in to the portal to view Result in Detail.</p>
      <a href="https://aibuilderss.com" class="cta">Go to Portal →</a>
      <p>Best regards,<br><strong>AI Builders Team</strong></p>
    </div>

    <div class="footer">
      Sent on {$date} &nbsp;|&nbsp; This is an automated notification — please do not reply.
    </div>

  </div>
</body>
</html>
HTML;
}