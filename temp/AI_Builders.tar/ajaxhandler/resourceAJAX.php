<?php
if ($action === 'uploadResource') {
    header('Content-Type: application/json');
    
    // Test getDB
    try {
        $pdo = getDB();
        ob_end_clean();
        echo json_encode(['status' => 'test', 'db' => 'getDB OK']);
    } catch (Exception $e) {
        ob_end_clean();
        echo json_encode(['status' => 'test', 'db_error' => $e->getMessage()]);
    }
    exit;
}
ob_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);

$base = dirname(__DIR__);
$path = $_SERVER['DOCUMENT_ROOT'];

require_once $base . '/vendor/autoload.php';
require_once $base . '/database/database.php';
require_once $base . '/database/syllabusDetails.php';
require_once $base . '/config/database.php';

$action = $_POST['action'] ?? '';

// ═══════════════════════════════════════════════════════════════
// ACTION: getCourses
// ═══════════════════════════════════════════════════════════════
if ($action === 'getCourses') {
    $dbo   = new Database();
    $facid = $_POST['facid'] ?? '';
    $sdo   = new syllabus_details();
    ob_end_clean();
    echo json_encode($sdo->getCoursesOfAFaculty($dbo, $facid));
    exit;
}

// ═══════════════════════════════════════════════════════════════
// ACTION: uploadResource — responds instantly, notifies in background
// ═══════════════════════════════════════════════════════════════
if ($action === 'uploadResource') {

    header('Content-Type: application/json');
    $dbo = new Database();
    $sdo = new syllabus_details();

    try {
        $fileName = null;
        if (!empty($_FILES['resource_file']['name'])) {
            $fileName = time() . '_' . $_FILES['resource_file']['name'];
            move_uploaded_file(
                $_FILES['resource_file']['tmp_name'],
                $base . '/uploads/' . $fileName
            );
        }

        $course_id     = (int)($_POST['course_id']    ?? 0);
        $faculty_id    = (int)($_POST['faculty_id']   ?? 0);
        $resource_type = trim($_POST['resource_type'] ?? '');
        $title         = trim($_POST['title']         ?? '');
        $description   = trim($_POST['description']   ?? '');
        $external_link = trim($_POST['external_link'] ?? '');
        $visibility    = trim($_POST['visibility']    ?? 'PUBLISHED');

        // 1. Insert resource into DB
        $sdo->insertResource(
            $dbo, $course_id, $faculty_id, $resource_type,
            $title, $description, $fileName, $external_link, $visibility
        );

        // 2. Queue push+email job (only if published)
        $pdo = null;
        if ($visibility === 'PUBLISHED') {
            try {
                $pdo = getDB();
                $pdo->prepare("
                    INSERT INTO notification_queue (course_id, update_type, message, status)
                    VALUES (?, ?, ?, 'pending')
                ")->execute([
                    $course_id,
                    'resource_' . $resource_type,
                    $title . '||' . $description
                ]);
            } catch (Exception $e) {
                error_log('Resource queue insert failed: ' . $e->getMessage());
                $pdo = null;
            }
        }

        // 3. Respond to browser INSTANTLY
        $json = json_encode(['status' => 'success', 'message' => 'Resource uploaded successfully.']);
        ob_end_clean();
        echo $json;

        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        } else {
            header('Connection: close');
            header('Content-Encoding: none');
            if (ob_get_level() > 0) ob_end_flush();
            flush();
        }

        // 4. Background: Push FIRST, then Email
        ignore_user_abort(true);
        set_time_limit(300);
        session_write_close();

        if ($visibility !== 'PUBLISHED') exit; // no notifications for drafts

        if (empty($pdo)) {
            try { $pdo = getDB(); } catch (Exception $e) { error_log('DB reconnect failed'); exit; }
        }

        $jobs = $pdo->query("
            SELECT * FROM notification_queue
            WHERE status = 'pending' AND update_type LIKE 'resource_%'
            ORDER BY created_at ASC
        ")->fetchAll(PDO::FETCH_ASSOC);

        if (empty($jobs)) exit;

        require_once $base . '/api/helpers/fcm_helper.php';
        require_once __DIR__ . '/sendResourceEmail.php';

        $dbo2 = new Database();

        foreach ($jobs as $job) {
            $jobId     = $job['id'];
            $jCourseId = (int)$job['course_id'];
            $jType     = $job['update_type'];
            $jMessage  = $job['message'];

            $parts    = explode('||', $jMessage, 2);
            $jTitle   = $parts[0] ?? $jMessage;
            $jDesc    = $parts[1] ?? '';
            $jResType = strtoupper(str_replace('resource_', '', $jType));

            $pdo->prepare("UPDATE notification_queue SET status = 'done' WHERE id = ?")
                ->execute([$jobId]);

            // A. PUSH FIRST (fast)
            try {
                $cStmt = $pdo->prepare("SELECT course_title, course_code FROM course_details WHERE id = ?");
                $cStmt->execute([$jCourseId]);
                $course      = $cStmt->fetch(PDO::FETCH_ASSOC);
                $courseLabel = ($course['course_code'] ?? '') . ' - ' . ($course['course_title'] ?? 'Course');

                $tStmt = $pdo->prepare("
                    SELECT ft.id, ft.token
                    FROM fcm_tokens ft
                    INNER JOIN course_registration cr ON cr.student_id = ft.user_id
                    WHERE cr.course_id = ? AND ft.is_active = 1
                ");
                $tStmt->execute([$jCourseId]);
                $tokens = $tStmt->fetchAll(PDO::FETCH_ASSOC);

                error_log("Resource job #$jobId: pushing to " . count($tokens) . " students");

                $expired = [];
                foreach ($tokens as $row) {
                    $res = sendFcmNotification(
                        $row['token'],
                        $courseLabel . ' — New ' . $jResType,
                        '[' . $jResType . '] ' . mb_strimwidth($jTitle, 0, 100, '...'),
                        '/AI_Builders/dashboard.php',
                        'resource'
                    );
                    error_log("Resource job #$jobId FCM: " . json_encode($res));
                    if (!$res['success'] && ($res['error'] ?? '') === 'TOKEN_EXPIRED') {
                        $expired[] = $row['id'];
                    }
                }

                if (!empty($expired)) {
                    $ph = implode(',', array_fill(0, count($expired), '?'));
                    $pdo->prepare("UPDATE fcm_tokens SET is_active = 0 WHERE id IN ($ph)")->execute($expired);
                }

            } catch (Exception $e) {
                error_log("Resource job #$jobId PUSH ERROR: " . $e->getMessage());
            }

            // B. EMAIL AFTER (slow SMTP)
            try {
                sendResourceEmail($dbo2, $jCourseId, $jResType, $jTitle, $jDesc);
                error_log("Resource job #$jobId emails done");
            } catch (Exception $e) {
                error_log("Resource job #$jobId EMAIL ERROR: " . $e->getMessage());
            }
        }

        exit;

    } catch (Throwable $e) {
        ob_end_clean();
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        exit;
    }
}

// ═══════════════════════════════════════════════════════════════
// ACTION: getSubjectResources
// ═══════════════════════════════════════════════════════════════
if ($action === 'getSubjectResources') {

    header('Content-Type: application/json; charset=utf-8');

    try {
        $dbo = new Database();

        if (empty($_POST['course_id'])) {
            throw new Exception("course_id is missing");
        }

        $course_id = (int)$_POST['course_id'];
        $sdo       = new syllabus_details();
        $data      = $sdo->getCourseResources($dbo, $course_id);

        ob_end_clean();
        echo json_encode(['success' => true, 'data' => $data]);
        exit;

    } catch (Throwable $e) {
        ob_end_clean();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// ═══════════════════════════════════════════════════════════════
// ACTION: getFacultyResources
// ═══════════════════════════════════════════════════════════════
if ($action === 'getFacultyResources') {

    header('Content-Type: application/json; charset=utf-8');

    try {
        $dbo        = new Database();
        $faculty_id = (int)($_POST['faculty_id'] ?? 0);

        if (!$faculty_id) throw new Exception("faculty_id missing");

        $stmt = $dbo->conn->prepare("
            SELECT r.resource_id, r.course_id, r.resource_type, r.title,
                   r.visibility, r.uploaded_at,
                   c.course_code, c.course_title
            FROM   course_resources r
            JOIN   course_details   c ON c.id = r.course_id
            WHERE  r.faculty_id = :faculty_id
            ORDER  BY r.uploaded_at DESC
        ");
        $stmt->execute([':faculty_id' => $faculty_id]);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        ob_end_clean();
        echo json_encode(['success' => true, 'data' => $data]);
        exit;

    } catch (Throwable $e) {
        ob_end_clean();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// ═══════════════════════════════════════════════════════════════
// ACTION: deleteResource
// ═══════════════════════════════════════════════════════════════
if ($action === 'deleteResource') {

    header('Content-Type: application/json; charset=utf-8');

    try {
        $dbo         = new Database();
        $resource_id = (int)($_POST['resource_id'] ?? 0);
        $faculty_id  = (int)($_POST['faculty_id']  ?? 0);

        if (!$resource_id || !$faculty_id) throw new Exception("Missing parameters");

        $sel = $dbo->conn->prepare("
            SELECT file_path FROM course_resources
            WHERE resource_id = :rid AND faculty_id = :fid
        ");
        $sel->execute([':rid' => $resource_id, ':fid' => $faculty_id]);
        $row = $sel->fetch(PDO::FETCH_ASSOC);

        if (!$row) throw new Exception("Resource not found or access denied");

        if (!empty($row['file_path'])) {
            $filePath = $base . '/uploads/' . $row['file_path'];
            if (file_exists($filePath)) unlink($filePath);
        }

        $dbo->conn->prepare("
            DELETE FROM course_resources
            WHERE resource_id = :rid AND faculty_id = :fid
        ")->execute([':rid' => $resource_id, ':fid' => $faculty_id]);

        ob_end_clean();
        echo json_encode(['success' => true]);
        exit;

    } catch (Throwable $e) {
        ob_end_clean();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

ob_end_clean();
echo json_encode(['status' => 'error', 'message' => 'Unknown action.']);
exit;